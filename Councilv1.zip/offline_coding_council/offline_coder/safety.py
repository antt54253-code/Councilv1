"""Host-enforced write policy. Generated code is never executed by this module."""
from __future__ import annotations
import ast
import hashlib
import json
import os
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Mapping

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MANAGED_DIR_NAME = ".council"
IGNORED_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "env", "node_modules", "__pycache__",
    ".idea", "site-packages", "dist", "build", "target", ".next", ".turbo",
}
BLOCKED_NAMES = {
    ".env", ".env.local", ".env.production", "id_rsa", "id_ed25519", "authorized_keys",
    "credentials", "credentials.json", "secrets.json", "secrets.yaml", "secrets.yml",
    "known_hosts", "master.key", "server.key", "client.key",
}
BLOCKED_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".keystore", ".sqlite", ".sqlite3", ".db"}
TEXT_SUFFIXES = {
    ".py", ".pyi", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".html", ".htm", ".css",
    ".scss", ".sass", ".less", ".json", ".jsonc", ".json5", ".md", ".txt", ".rst", ".toml",
    ".ini", ".cfg", ".yaml", ".yml", ".xml", ".svg", ".sql", ".sh", ".bash", ".zsh", ".ps1",
    ".bat", ".cmd", ".rs", ".go", ".java", ".kt", ".kts", ".cs", ".cpp", ".c", ".h", ".hpp",
    ".swift", ".m", ".mm", ".rb", ".php", ".vue", ".svelte", ".dart", ".ex", ".exs", ".erl",
    ".hs", ".lua", ".pl", ".r", ".R", ".jl", ".tf", ".hcl", ".gradle", ".properties", ".make",
    ".mk", ".dockerfile", ".gitignore", ".editorconfig", ".lock", ".graphql", ".proto",
}
# Safety-critical agent files require manual review if this workspace is this application's source tree.
SELF_EDIT_MANUAL_FILES = {
    "offline_coder/safety.py", "offline_coder/workspace.py", "offline_coder/council.py",
    "offline_coder/config.py", "offline_coder/model_backend.py", "main.py", "offline_coder/app.py",
}
SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
]
RISK_PATTERNS = [
    ("dynamic code execution", re.compile(r"\b(?:eval|exec)\s*\(")),
    ("shell execution", re.compile(r"\b(?:os\.system|subprocess\.(?:run|Popen|call|check_output))\s*\(")),
    ("shell=True", re.compile(r"\bshell\s*=\s*True\b")),
    ("recursive deletion", re.compile(r"\b(?:shutil\.rmtree|Path\([^\n]*\)\.rmdir)\s*\(")),
    ("network access", re.compile(r"\b(?:requests\.(?:get|post|put|delete)|urllib\.request|socket\.socket|httpx\.)")),
]


@dataclass
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    hashes_before: dict[str, str | None] = field(default_factory=dict)
    hashes_after: dict[str, str] = field(default_factory=dict)
    self_edit_targets: list[str] = field(default_factory=list)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False




def ensure_managed_directory(workspace: Path, *parts: str) -> Path:
    """Create a path under .council while refusing symlinks in the managed tree."""
    root = workspace.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("Workspace does not exist or is not a directory.")
    cursor = root
    for part in (MANAGED_DIR_NAME, *parts):
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError(f"Refusing to use a symlink in the audit/backup area: {cursor}")
        if cursor.exists() and not cursor.is_dir():
            raise ValueError(f"Managed audit/backup path is not a directory: {cursor}")
        cursor.mkdir(exist_ok=True)
        if not is_within(cursor, root):
            raise ValueError(f"Managed audit/backup path escaped the workspace: {cursor}")
    return cursor

def is_secret_path(relative: str) -> bool:
    p = Path(relative)
    parts = [part.lower() for part in p.parts]
    name = p.name.lower()
    if name in BLOCKED_NAMES or name.startswith(".env"):
        return True
    if p.suffix.lower() in BLOCKED_SUFFIXES:
        return True
    if any(part in {".ssh", ".aws", ".azure", ".gnupg", ".kube", "secrets", "credentials"} or part.startswith(".env") for part in parts):
        return True
    if any(term in name for term in ("password", "passwd", "secret", "credential", "private_key", "apikey")):
        return True
    return False


def validate_proposed_files(workspace: Path, files: Mapping[str, str], allow_self_edit: bool = False) -> ValidationResult:
    root = workspace.expanduser().resolve()
    result = ValidationResult(ok=True)
    if not files:
        return result
    if not root.exists() or not root.is_dir():
        return ValidationResult(False, ["Workspace does not exist or is not a directory."])
    for raw, content in files.items():
        if not isinstance(raw, str) or not isinstance(content, str):
            result.errors.append("Every proposed file must have a string path and string contents.")
            continue
        rel = raw.replace("\\", "/").strip()
        p = Path(rel)
        # Validation and the actual writer must interpret a path identically on every OS.
        # The writer uses mapping keys, so non-canonical aliases (backslashes, surrounding
        # whitespace, repeated separators, or ./ segments) must be rejected rather than
        # validated as one path and then written as another.
        if raw != raw.strip() or "\\" in raw or (rel and p.as_posix() != rel):
            result.errors.append(f"Blocked non-canonical path: {raw!r}. Use a clean relative path with forward slashes.")
            continue
        if not rel or p.is_absolute() or re.match(r"^[A-Za-z]:", rel) or ".." in p.parts:
            result.errors.append(f"Blocked unsafe path: {raw!r}")
            continue
        if rel.startswith("/") or any(part in IGNORED_DIRS for part in p.parts):
            result.errors.append(f"Blocked path inside a private, generated, or dependency directory: {rel}")
            continue
        if p.parts and p.parts[0] == MANAGED_DIR_NAME:
            result.errors.append(f"The assistant's audit, settings, and backup area is protected: {rel}")
            continue
        if is_secret_path(rel):
            result.errors.append(f"Blocked sensitive file path: {rel}")
            continue
        if p.suffix.lower() not in TEXT_SUFFIXES and p.name.lower() not in {"makefile", "dockerfile", ".gitignore", ".editorconfig"}:
            result.errors.append(f"Only recognized text/source files can be written automatically: {rel}")
            continue
        if len(content.encode("utf-8")) > 1_000_000:
            result.errors.append(f"File is over the 1 MB automatic-write limit: {rel}")
            continue
        target = root / p
        if not is_within(target, root):
            result.errors.append(f"Blocked path that escapes the workspace: {rel}")
            continue
        # Existing symlinks could redirect writes outside the workspace.
        cursor = root
        unsafe_link = False
        for part in p.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                unsafe_link = True
                break
        if unsafe_link:
            result.errors.append(f"Blocked symlink target: {rel}")
            continue
        existing = target.read_text(encoding="utf-8", errors="replace") if target.is_file() else None
        result.hashes_before[rel] = sha256_text(existing) if existing is not None else None
        result.hashes_after[rel] = sha256_text(content)
        if is_within(target, PROJECT_ROOT):
            result.self_edit_targets.append(rel)
            normalized = rel.replace("\\", "/")
            if not allow_self_edit:
                result.errors.append(f"Self-editing is off; turn it on in the UI to propose application-source changes: {rel}")
            elif normalized in SELF_EDIT_MANUAL_FILES:
                result.errors.append(f"Safety-critical self-edit requires manual review and cannot be auto-applied: {rel}")
        for pattern in SECRET_PATTERNS:
            if pattern.search(content):
                result.errors.append(f"Possible credential/private-key material found in proposed file: {rel}")
                break
        for label, pattern in RISK_PATTERNS:
            if pattern.search(content):
                result.warnings.append(f"{rel}: contains {label}; inspect this code carefully before applying or running it.")
        suffix = p.suffix.lower()
        if suffix == ".py":
            try:
                ast.parse(content, filename=rel)
            except SyntaxError as exc:
                result.errors.append(f"Python syntax error in {rel}, line {exc.lineno}: {exc.msg}")
        elif suffix == ".json":
            try:
                json.loads(content)
            except json.JSONDecodeError as exc:
                result.errors.append(f"Invalid JSON in {rel}, line {exc.lineno}, column {exc.colno}: {exc.msg}")
    result.ok = not result.errors
    return result


def apply_files(workspace: Path, files: Mapping[str, str], expected_hashes: Mapping[str, str | None],
                allow_self_edit: bool = False) -> Path:
    """Write after user approval. Existing files are backed up; no code is executed."""
    root = workspace.expanduser().resolve()
    validation = validate_proposed_files(root, files, allow_self_edit=allow_self_edit)
    if not validation.ok:
        raise ValueError("Safety checks blocked apply:\n- " + "\n- ".join(validation.errors))
    # Recheck original file hashes immediately before any write, preventing stale proposals.
    for rel in files:
        path = root / rel
        current = path.read_text(encoding="utf-8", errors="replace") if path.is_file() else None
        current_hash = sha256_text(current) if current is not None else None
        if current_hash != expected_hashes.get(rel):
            raise ValueError(f"{rel} changed after review. Run the council again so it reviews the current file.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_root = ensure_managed_directory(root, "backups", stamp)
    manifest_targets = []
    for rel in files:
        path = root / rel
        existed = path.is_file()
        manifest_targets.append({"path": rel.replace("\\", "/"), "existed": existed})
        if existed:
            backup = backup_root / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
    # The manifest records newly created paths too, allowing safe one-click rollback.
    (backup_root / "manifest.json").write_text(json.dumps({"targets": manifest_targets, "created_at": datetime.now().isoformat()}, indent=2), encoding="utf-8")
    # Stage all text first, then replace atomically one by one. Roll back from backups if a write fails.
    staged: list[tuple[Path, Path]] = []
    try:
        for rel, content in files.items():
            dest = root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            temp = dest.with_name(dest.name + f".council-tmp-{stamp}")
            temp.write_text(content, encoding="utf-8", newline="")
            staged.append((temp, dest))
        for temp, dest in staged:
            os.replace(temp, dest)
    except Exception:
        for temp, _ in staged:
            try:
                temp.unlink(missing_ok=True)
            except OSError:
                pass
        # Restore all existing originals for any target that was changed.
        for rel in files:
            backup = backup_root / rel
            dest = root / rel
            try:
                if backup.exists():
                    shutil.copy2(backup, dest)
                elif dest.exists() and expected_hashes.get(rel) is None:
                    dest.unlink()
            except OSError:
                pass
        raise
    return backup_root


def inspect_generated_code(files: Mapping[str, str]) -> list[str]:
    """Advisory risk flags; this never executes or imports generated code."""
    findings: list[str] = []
    for rel, content in files.items():
        for label, pattern in RISK_PATTERNS:
            if pattern.search(content):
                findings.append(f"{rel}: {label}")
    return findings
