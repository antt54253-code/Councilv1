"""Optional Docker-isolated smoke tests for Python proposals.

The host never executes generated code directly. If Docker and the exact local image
are already installed, run tests in a no-network, resource-limited disposable container.
If the isolation runtime is unavailable, report SKIPPED rather than pretending tests ran.
"""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Mapping, Any
from .safety import is_secret_path

IGNORED = {'.git', '.venv', 'venv', 'env', 'node_modules', '__pycache__', '.council', 'dist', 'build', 'target'}
MAX_COPY_BYTES = 30 * 1024 * 1024
MAX_COPY_FILES = 20_000
MAX_COPY_DIRS = 8_000


def _copy_workspace(root: Path, dest: Path) -> None:
    copied = 0
    visited_files = 0
    visited_dirs = 0
    for base, dirs, files in os.walk(root, followlinks=False):
        visited_dirs += 1
        if visited_dirs > MAX_COPY_DIRS:
            raise ValueError(f"Workspace has more than {MAX_COPY_DIRS:,} directories; automatic tests were skipped.")
        bp = Path(base)
        dirs[:] = sorted(d for d in dirs if d not in IGNORED and not (bp / d).is_symlink() and not is_secret_path((bp / d).relative_to(root).as_posix()))
        for name in sorted(files):
            visited_files += 1
            if visited_files > MAX_COPY_FILES:
                raise ValueError(f"Workspace has more than {MAX_COPY_FILES:,} files; automatic tests were skipped.")
            src = bp / name
            if src.is_symlink() or src.suffix.lower() in {'.sqlite', '.sqlite3', '.db', '.pem', '.key', '.p12', '.pfx'}:
                continue
            try:
                rel = src.relative_to(root)
                if is_secret_path(rel.as_posix()):
                    continue
                if not src.is_file() or src.stat().st_size > 1_000_000:
                    continue
                copied += src.stat().st_size
                if copied > MAX_COPY_BYTES:
                    raise ValueError('Workspace test snapshot exceeds 30 MB; automatic tests were skipped.')
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, target)
            except OSError:
                continue


def run_isolated_python_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Test a candidate in a disposable Docker container with network disabled.

    Only runs if a Python file exists and Docker plus python:3.12-slim are already
    available locally. Never pulls an image automatically. Tests can still be buggy;
    the container limits risk but is not a formally verified sandbox.
    """
    if not any(Path(name).suffix.lower() == '.py' for name in proposed_files):
        return {'status': 'NOT_APPLICABLE', 'summary': 'No proposed Python files; no Python test run was needed.', 'output': ''}
    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; generated code was not executed.', 'output': ''}
    image = 'python:3.12-slim'
    inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
    if inspect.returncode != 0:
        return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no code was executed.', 'output': ''}

    root = Path(workspace).expanduser().resolve()
    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-test-') as td:
            snapshot = Path(td) / 'workspace'
            snapshot.mkdir()
            _copy_workspace(root, snapshot)
            for raw, content in proposed_files.items():
                rel = Path(raw.replace('\\', '/'))
                if rel.is_absolute() or '..' in rel.parts or not rel.parts:
                    return {'status': 'FAILED', 'summary': f'Unsafe proposed path refused by test runner: {raw}', 'output': ''}
                target = snapshot / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding='utf-8')
            for directory, subdirs, files in os.walk(snapshot):
                try:
                    Path(directory).chmod(0o777)
                except OSError:
                    pass
                for filename in files:
                    try:
                        (Path(directory) / filename).chmod(0o666)
                    except OSError:
                        pass
            runner_script = (
                'import compileall, pathlib, sys, unittest; '
                'root=pathlib.Path("/workspace"); '
                'ok=compileall.compile_dir(str(root), quiet=1, force=True); '
                'print("PYTHON_COMPILE:", "PASS" if ok else "FAIL"); '
                'sys.exit(2) if not ok else None; '
                'tests=root/"tests"; '
                'suite=unittest.defaultTestLoader.discover(str(tests), top_level_dir=str(root)) if tests.is_dir() else unittest.TestSuite(); '
                'print("UNITTEST_DISCOVERY:", "tests found" if suite.countTestCases() else "no unittest tests discovered"); '
                'result=unittest.TextTestRunner(verbosity=2).run(suite); '
                'sys.exit(0 if result.wasSuccessful() else 1)'
            )
            cmd = [docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                   '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                   '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:rw', '-w', '/workspace',
                   '--user', '65534:65534', image, 'python', '-c', runner_script]
            try:
                run = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            except subprocess.TimeoutExpired as exc:
                out = (exc.stdout or '') + '\n' + (exc.stderr or '')
                return {'status': 'FAILED', 'summary': f'Isolated Python checks exceeded {timeout} seconds and were stopped.', 'output': out[-12000:]}
            output = ((run.stdout or '') + '\n' + (run.stderr or '')).strip()[-12000:]
            # A successful empty unittest suite is not evidence that behavior was tested.
            no_tests = 'UNITTEST_DISCOVERY: no unittest tests discovered' in output
            if run.returncode != 0:
                status = 'FAILED'
                summary = f'Isolated Python checks failed (exit code {run.returncode}).'
            elif no_tests:
                status = 'NO_TESTS'
                summary = 'Python compilation passed, but no unittest tests were discovered; behavior is not verified.'
            else:
                status = 'PASSED'
                summary = 'Python compilation and discovered unittest checks passed in a disposable no-network Docker container.'
            return {'status': status, 'summary': summary, 'output': output, 'exit_code': run.returncode}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Isolated testing could not start safely: {exc}', 'output': ''}


def run_isolated_node_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Run JavaScript syntax checks and built-in node:test suites in a preinstalled offline image."""
    relevant = {name: content for name, content in proposed_files.items()
                if Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} or Path(name).name.lower() == 'package.json'}
    if not relevant:
        return {'status': 'NOT_APPLICABLE', 'summary': 'No JavaScript/Node files were proposed.', 'output': ''}
    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; JavaScript was not executed.', 'output': ''}
    image = 'node:22-alpine'
    try:
        inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
    except (OSError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Could not inspect the preinstalled Node image: {exc}', 'output': ''}
    if inspect.returncode != 0:
        return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no code was executed.', 'output': ''}

    root = Path(workspace).expanduser().resolve()
    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-node-') as td:
            snapshot = Path(td) / 'workspace'
            snapshot.mkdir()
            _copy_workspace(root, snapshot)
            for raw, content in proposed_files.items():
                rel = Path(raw.replace('\\', '/'))
                if rel.is_absolute() or '..' in rel.parts or not rel.parts:
                    return {'status': 'FAILED', 'summary': f'Unsafe proposed path refused by Node test runner: {raw}', 'output': ''}
                target = snapshot / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding='utf-8')
            source_files = []
            test_files = []
            for base, dirs, files in os.walk(snapshot, followlinks=False):
                dirs[:] = sorted(d for d in dirs if d not in IGNORED and not (Path(base) / d).is_symlink())
                for filename in sorted(files):
                    path = Path(base) / filename
                    rel = path.relative_to(snapshot).as_posix()
                    if path.suffix.lower() not in {'.js', '.mjs', '.cjs'}:
                        continue
                    source_files.append(rel)
                    lower = rel.lower()
                    if ('.test.' in lower or '.spec.' in lower or lower.startswith('test/') or '/test/' in lower or lower.startswith('tests/') or '/tests/' in lower):
                        test_files.append(rel)
            if not source_files:
                return {'status': 'NO_TESTS', 'summary': 'Node project files were changed, but no JavaScript files were available for syntax/runtime verification.', 'output': ''}
            # All paths are relative paths discovered inside the isolated snapshot, never shell-interpolated.
            syntax = subprocess.run([docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                                     '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                                     '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:ro', '-w', '/workspace',
                                     '--user', '65534:65534', image, 'node', '--check', *source_files],
                                    capture_output=True, text=True, timeout=timeout)
            output = ((syntax.stdout or '') + '\n' + (syntax.stderr or '')).strip()[-12000:]
            if syntax.returncode != 0:
                return {'status': 'FAILED', 'summary': 'Isolated Node.js syntax check failed.', 'output': output, 'exit_code': syntax.returncode}
            if not test_files:
                return {'status': 'NO_TESTS', 'summary': 'JavaScript syntax checks passed, but no Node test files were discovered; behavior is not verified.', 'output': output}
            tests = subprocess.run([docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                                    '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128',
                                    '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:ro', '-w', '/workspace',
                                    '--user', '65534:65534', image, 'node', '--test', *test_files],
                                   capture_output=True, text=True, timeout=timeout)
            test_output = ((tests.stdout or '') + '\n' + (tests.stderr or '')).strip()[-12000:]
            combined = (output + '\n' + test_output).strip()[-12000:]
            if tests.returncode != 0:
                return {'status': 'FAILED', 'summary': f'Isolated Node.js tests failed (exit code {tests.returncode}).', 'output': combined, 'exit_code': tests.returncode}
            if 'ℹ tests 0' in test_output or 'tests 0' in test_output:
                return {'status': 'NO_TESTS', 'summary': 'Node test command found no tests; behavior is not verified.', 'output': combined, 'exit_code': tests.returncode}
            return {'status': 'PASSED', 'summary': 'JavaScript syntax checks and discovered built-in Node.js tests passed in a disposable no-network Docker container.', 'output': combined, 'exit_code': tests.returncode}
    except subprocess.TimeoutExpired as exc:
        out = ((exc.stdout or '') + '\n' + (exc.stderr or '')) if isinstance(exc.stdout, str) else 'Node test output was unavailable.'
        return {'status': 'FAILED', 'summary': f'Isolated Node.js checks exceeded {timeout} seconds and were stopped.', 'output': out[-12000:]}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Isolated Node.js testing could not start safely: {exc}', 'output': ''}



def run_project_simulations(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 20) -> dict[str, Any]:
    """Run explicitly configured Python/Node smoke or end-to-end scenarios in offline Docker.

    Manifest: council.simulations.json at the workspace root. Example:
    {"scenarios":[{"name":"CLI help", "runtime":"python", "script":"main.py", "args":["--help"], "expect_exit_code":0, "expect_output_contains":"usage"}]}
    Scenarios execute only inside disposable, no-network containers. Commands are argv arrays,
    never shell strings; only Python or Node entry scripts inside the copied workspace are allowed.
    """
    manifest_name = 'council.simulations.json'
    root = Path(workspace).expanduser().resolve()
    proposed_manifest = next((v for k, v in proposed_files.items() if k.replace('\\', '/').strip('/') == manifest_name), None)
    manifest_path = root / manifest_name
    if proposed_manifest is None and not manifest_path.is_file():
        return {'status': 'NOT_APPLICABLE', 'summary': 'No council.simulations.json manifest configured; explicit runtime simulations were not requested.', 'output': '', 'scenarios': []}
    try:
        manifest_text = proposed_manifest if proposed_manifest is not None else manifest_path.read_text(encoding='utf-8')
        manifest = json.loads(manifest_text)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return {'status': 'FAILED', 'summary': f'Simulation manifest is unreadable or invalid JSON: {exc}', 'output': '', 'scenarios': []}
    scenarios = manifest.get('scenarios') if isinstance(manifest, dict) else None
    if not isinstance(scenarios, list) or not scenarios:
        return {'status': 'NO_TESTS', 'summary': 'Simulation manifest must contain a non-empty scenarios list.', 'output': '', 'scenarios': []}
    if len(scenarios) > 10:
        return {'status': 'FAILED', 'summary': 'At most 10 simulation scenarios are allowed per run.', 'output': '', 'scenarios': []}
    validated: list[dict[str, Any]] = []
    images: set[str] = set()
    for index, raw in enumerate(scenarios):
        if not isinstance(raw, dict):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} must be an object.', 'output': '', 'scenarios': []}
        runtime = str(raw.get('runtime', '')).lower()
        script = str(raw.get('script', '')).replace('\\', '/')
        rel = Path(script)
        args = raw.get('args', [])
        if runtime not in {'python', 'node'} or not script or rel.is_absolute() or '..' in rel.parts or not rel.parts or not isinstance(args, list) or len(args) > 20 or any(not isinstance(a, (str, int, float)) for a in args):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has an unsafe runtime, script path, or arguments.', 'output': '', 'scenarios': []}
        if (runtime == 'python' and rel.suffix.lower() != '.py') or (runtime == 'node' and rel.suffix.lower() not in {'.js', '.mjs', '.cjs'}):
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} script extension does not match runtime.', 'output': '', 'scenarios': []}
        expected_exit = raw.get('expect_exit_code', 0)
        if not isinstance(expected_exit, int) or expected_exit < 0 or expected_exit > 255:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has an invalid expected exit code.', 'output': '', 'scenarios': []}
        expected_text = raw.get('expect_output_contains', '')
        if not isinstance(expected_text, str) or len(expected_text) > 500:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} has invalid output assertion.', 'output': '', 'scenarios': []}
        timeout_s = raw.get('timeout_seconds', timeout)
        if not isinstance(timeout_s, int) or timeout_s < 1 or timeout_s > 30:
            return {'status': 'FAILED', 'summary': f'Simulation scenario {index + 1} timeout must be 1–30 seconds.', 'output': '', 'scenarios': []}
        image = 'python:3.12-slim' if runtime == 'python' else 'node:22-alpine'
        images.add(image)
        validated.append({'name': str(raw.get('name', f'Scenario {index + 1}'))[:120], 'runtime': runtime, 'script': rel.as_posix(), 'args': [str(a)[:500] for a in args], 'expect_exit_code': expected_exit, 'expect_output_contains': expected_text, 'timeout_seconds': timeout_s, 'image': image})

    docker = shutil.which('docker')
    if not docker:
        return {'status': 'SKIPPED', 'summary': 'Docker is not installed; configured simulations were not executed.', 'output': '', 'scenarios': []}

    for image in sorted(images):
        try:
            inspect = subprocess.run([docker, 'image', 'inspect', image], capture_output=True, text=True, timeout=8)
        except (OSError, subprocess.SubprocessError) as exc:
            return {'status': 'SKIPPED', 'summary': f'Could not inspect local simulation image {image}: {exc}', 'output': '', 'scenarios': []}
        if inspect.returncode != 0:
            return {'status': 'SKIPPED', 'summary': f'Docker image {image} is not already installed; no image was downloaded and no simulations ran.', 'output': '', 'scenarios': []}

    try:
        with tempfile.TemporaryDirectory(prefix='coding-council-sim-') as td:
            snapshot = Path(td) / 'workspace'; snapshot.mkdir()
            _copy_workspace(root, snapshot)
            for raw, content in proposed_files.items():
                rel = Path(raw.replace('\\', '/'))
                if rel.is_absolute() or '..' in rel.parts or not rel.parts:
                    return {'status': 'FAILED', 'summary': f'Unsafe proposed path refused by simulation runner: {raw}', 'output': '', 'scenarios': []}
                target = snapshot / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding='utf-8')
            # Let the unprivileged container user write only inside this disposable snapshot.
            for directory, _subdirs, files in os.walk(snapshot):
                try:
                    Path(directory).chmod(0o777)
                except OSError:
                    pass
                for filename in files:
                    try:
                        (Path(directory) / filename).chmod(0o666)
                    except OSError:
                        pass
            reports = []
            for scenario in validated:
                script_path = snapshot / scenario['script']
                if not script_path.is_file() or script_path.is_symlink():
                    reports.append({'name': scenario['name'], 'status': 'FAILED', 'summary': f"Scenario script not found in isolated workspace: {scenario['script']}", 'output': ''})
                    continue
                runtime_cmd = 'python' if scenario['runtime'] == 'python' else 'node'
                cmd = [docker, 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--memory', '512m', '--cpus', '1', '--pids-limit', '128', '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m', '-v', f'{snapshot}:/workspace:rw', '-w', '/workspace', '--user', '65534:65534', scenario['image'], runtime_cmd, '/workspace/' + scenario['script'], *scenario['args']]
                try:
                    run = subprocess.run(cmd, capture_output=True, text=True, timeout=scenario['timeout_seconds'])
                    output = ((run.stdout or '') + '\n' + (run.stderr or '')).strip()[-6000:]
                    ok = run.returncode == scenario['expect_exit_code'] and (scenario['expect_output_contains'] in output if scenario['expect_output_contains'] else True)
                    reports.append({'name': scenario['name'], 'status': 'PASSED' if ok else 'FAILED', 'summary': 'Scenario assertions passed.' if ok else f"Expected exit {scenario['expect_exit_code']}, got {run.returncode}, or expected output assertion was absent.", 'exit_code': run.returncode, 'output': output})
                except subprocess.TimeoutExpired as exc:
                    out = exc.stdout if isinstance(exc.stdout, str) else 'No output captured before timeout.'
                    reports.append({'name': scenario['name'], 'status': 'FAILED', 'summary': f"Scenario exceeded {scenario['timeout_seconds']} seconds and was stopped.", 'output': out[-6000:]})
            statuses = [item['status'] for item in reports]
            status = 'FAILED' if 'FAILED' in statuses else 'PASSED'
            output = '\n\n'.join(f"[{item['name']}] {item['status']}\n{item.get('output', '')}" for item in reports)[-16000:]
            return {'status': status, 'summary': f"{sum(x == 'PASSED' for x in statuses)}/{len(statuses)} configured simulation scenarios passed in offline containers.", 'output': output, 'scenarios': reports}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return {'status': 'SKIPPED', 'summary': f'Simulations could not start safely: {exc}', 'output': '', 'scenarios': []}

def run_project_checks(workspace: Path, proposed_files: Mapping[str, str], timeout: int = 45) -> dict[str, Any]:
    """Run isolated language checks plus optional user-defined end-to-end simulations."""
    reports: dict[str, dict[str, Any]] = {}
    if any(Path(name).suffix.lower() == '.py' for name in proposed_files):
        reports['python'] = run_isolated_python_checks(workspace, proposed_files, timeout=timeout)
    if any(Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} or Path(name).name.lower() == 'package.json' for name in proposed_files):
        reports['node'] = run_isolated_node_checks(workspace, proposed_files, timeout=timeout)
    simulation = run_project_simulations(workspace, proposed_files, timeout=min(timeout, 30))
    if simulation.get('status') != 'NOT_APPLICABLE':
        reports['simulation'] = simulation
    # Real-browser rendering and interaction checks for web-facing changes.
    web_change = any(Path(name).suffix.lower() in {'.html', '.htm', '.css'} or Path(name).name == 'council.visual.json' for name in proposed_files)
    workspace_root = Path(workspace).expanduser().resolve()
    existing_visual_manifest = (workspace_root / 'council.visual.json').is_file()
    existing_web_entry = any((workspace_root / name).is_file() for name in ('index.html', 'main.html', 'app.html'))
    js_change = any(Path(name).suffix.lower() in {'.js', '.mjs', '.cjs'} for name in proposed_files)
    if web_change or (existing_visual_manifest and (bool(proposed_files) or not reports)) or (js_change and existing_web_entry):
        from .visual_simulation import run_visual_browser_checks
        visual = run_visual_browser_checks(workspace, proposed_files, timeout=min(timeout, 30))
        if visual.get('status') != 'NOT_APPLICABLE':
            reports['visual'] = visual
    if not reports:
        return {'status': 'NOT_APPLICABLE', 'summary': 'No supported runtime checks or configured simulations apply to this proposal.', 'output': '', 'checks': reports}
    statuses = [report.get('status') for report in reports.values()]
    if all(status == 'PASSED' for status in statuses):
        status = 'PASSED'
    elif 'FAILED' in statuses:
        status = 'FAILED'
    elif 'NO_TESTS' in statuses:
        status = 'NO_TESTS'
    elif 'SKIPPED' in statuses:
        status = 'SKIPPED'
    else:
        status = 'NOT_RUN'
    summary = ' | '.join(f'{name}: {report.get("summary", report.get("status", "unknown"))}' for name, report in reports.items())
    output = '\n\n'.join(f'[{name.upper()}]\n{report.get("output", "")}' for name, report in reports.items())[-16000:]
    return {'status': status, 'summary': summary, 'output': output, 'checks': reports}
