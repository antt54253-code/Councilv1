from __future__ import annotations
import json
import queue
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path
from datetime import datetime

from .config import load_settings, save_settings
from .model_backend import LocalModel, LocalServerModel, LocalModelError
from .knowledge import KnowledgeStore
from .learning import LearningStore
from .council import CouncilRunner, AGENTS, apply_approved_result, can_autonomously_apply
from .project_tools import analyze_project, format_project_report, compile_acceptance_checklist, TaskJournal, restore_backup, create_starter_template
from .web_search import search_web, format_search_context
from .visual_simulation import run_visual_browser_checks


class CodingCouncilApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Offline Coding Council — Four Equal AI Peers")
        self.root.geometry("1180x850")
        self.root.minsize(900, 680)
        self.settings = load_settings()
        self.knowledge = KnowledgeStore()
        self.learning = LearningStore()
        self.model = None
        self.model_signature = None
        self.current_result = None
        self.events: queue.Queue = queue.Queue()
        self.running = False
        self.visual_running = False
        self._build_ui()
        self._refresh_source_count()
        self.root.after(150, self._drain_events)
        self._log("Ready. Model inference is local; optional public web search uses an external search provider. Pick a local GGUF model and workspace to begin.")

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)

        title = ttk.Label(outer, text="OFFLINE CODING COUNCIL", font=("TkDefaultFont", 18, "bold"))
        title.pack(anchor="w")
        subtitle = ttk.Label(outer, text="Four peer agents · local model · shared reviews · unanimous approval · you control Apply")
        subtitle.pack(anchor="w", pady=(2, 10))

        paths = ttk.LabelFrame(outer, text="Local setup", padding=8)
        paths.pack(fill="x", pady=(0, 8))
        self.model_var = tk.StringVar(value=str(self.settings.get("model_path", "")))
        self.workspace_var = tk.StringVar(value=str(self.settings.get("workspace_path", "")))
        ttk.Label(paths, text="Local GGUF model (GGUF mode):").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(paths, textvariable=self.model_var).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Button(paths, text="Choose model…", command=self._choose_model).grid(row=0, column=2, padx=(8, 0), pady=4)
        ttk.Label(paths, text="Workspace folder (only project folder AI may read/write):").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(paths, textvariable=self.workspace_var).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Button(paths, text="Choose folder…", command=self._choose_workspace).grid(row=1, column=2, padx=(8, 0), pady=4)
        paths.columnconfigure(1, weight=1)

        settings_frame = ttk.Frame(paths)
        settings_frame.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(7, 0))
        self.n_ctx_var = tk.StringVar(value=str(self.settings.get("n_ctx", 16384)))
        self.threads_var = tk.StringVar(value=str(self.settings.get("n_threads", 4)))
        self.gpu_var = tk.StringVar(value=str(self.settings.get("n_gpu_layers", 0)))
        self.tokens_var = tk.StringVar(value=str(self.settings.get("max_tokens", 4096)))
        self.rounds_var = tk.StringVar(value=str(self.settings.get("review_rounds", 1)))
        self.backend_var = tk.StringVar(value=str(self.settings.get("model_backend", "gguf")))
        self.server_url_var = tk.StringVar(value=str(self.settings.get("local_server_url", "http://127.0.0.1:8080/v1")))
        self.server_model_var = tk.StringVar(value=str(self.settings.get("local_server_model", "")))
        for col, (label, var, width) in enumerate([
            ("Context", self.n_ctx_var, 8), ("CPU threads", self.threads_var, 6),
            ("GPU layers (0=CPU)", self.gpu_var, 8), ("Max output tokens", self.tokens_var, 8),
            ("Revision rounds (0–2)", self.rounds_var, 5),
        ]):
            ttk.Label(settings_frame, text=label).grid(row=0, column=col * 2, sticky="w", padx=(0, 5))
            ttk.Entry(settings_frame, textvariable=var, width=width).grid(row=0, column=col * 2 + 1, sticky="w", padx=(0, 12))
        ttk.Label(settings_frame, text="Backend").grid(row=1, column=0, sticky="w", pady=(7, 0))
        ttk.Combobox(settings_frame, textvariable=self.backend_var, values=("gguf", "local-server"), state="readonly", width=13).grid(row=1, column=1, sticky="w", pady=(7, 0), padx=(0, 12))
        ttk.Label(settings_frame, text="Loopback server URL").grid(row=1, column=2, sticky="w", pady=(7, 0))
        ttk.Entry(settings_frame, textvariable=self.server_url_var, width=34).grid(row=1, column=3, sticky="ew", pady=(7, 0), padx=(0, 12))
        ttk.Label(settings_frame, text="Model ID (optional)").grid(row=1, column=4, sticky="w", pady=(7, 0))
        ttk.Entry(settings_frame, textvariable=self.server_model_var, width=20).grid(row=1, column=5, columnspan=3, sticky="ew", pady=(7, 0))
        settings_frame.columnconfigure(3, weight=1)
        self.self_edit_var = tk.BooleanVar(value=bool(self.settings.get("allow_self_edit", False)))
        ttk.Checkbutton(paths, text="Allow proposing edits to this app's own non-protected source files (extra caution)", variable=self.self_edit_var).grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 0))

        controls = ttk.Frame(outer)
        controls.pack(fill="x", pady=(0, 8))
        self.run_button = ttk.Button(controls, text="Run the 4-peer council", command=self._run_council)
        self.run_button.pack(side="left")
        self.web_search_button = ttk.Button(controls, text="Search web…", command=self._search_web)
        self.web_search_button.pack(side="left", padx=(8, 0))
        self.apply_button = ttk.Button(controls, text="Apply unanimously approved proposal…", command=self._apply_result, state="disabled")
        self.apply_button.pack(side="left", padx=(8, 0))
        self.auto_apply_var = tk.BooleanVar(value=bool(self.settings.get("auto_apply_approved", False)))
        self.auto_apply_button = ttk.Button(controls, text="Autonomous edits: " + ("ON" if self.auto_apply_var.get() else "OFF"), command=self._toggle_auto_apply)
        self.auto_apply_button.pack(side="left", padx=(8, 0))
        self.web_research_var = tk.BooleanVar(value=bool(self.settings.get("autonomous_web_research", True)))
        ttk.Checkbutton(controls, text="Autonomous web research", variable=self.web_research_var, command=self._save_settings).pack(side="left", padx=(8, 0))
        ttk.Button(controls, text="Import local knowledge…", command=self._import_source).pack(side="left", padx=(16, 0))
        ttk.Button(controls, text="Review / verify knowledge…", command=self._manage_sources).pack(side="left", padx=(8, 0))
        ttk.Button(controls, text="Learn from a successful run…", command=self._learn_from_result).pack(side="left", padx=(8, 0))
        ttk.Button(controls, text="Export training data…", command=self._export_training_data).pack(side="left", padx=(8, 0))
        self.source_count_var = tk.StringVar(value="Verified sources: 0")
        ttk.Label(controls, textvariable=self.source_count_var).pack(side="right")

        task_frame = ttk.LabelFrame(outer, text="What should the council build, fix, or explain?", padding=8)
        task_frame.pack(fill="x", pady=(0, 8))
        self.task_text = tk.Text(task_frame, height=4, wrap="word", undo=True)
        self.task_text.pack(fill="x", expand=False)
        self.task_text.insert("1.0", "Describe the feature, bug, or project goal. Tell the council any constraints and how you will know the result is correct.")
        self.task_text.bind("<FocusIn>", self._clear_placeholder)

        project_tools = ttk.LabelFrame(outer, text="Project intelligence & control", padding=7)
        project_tools.pack(fill="x", pady=(0, 8))
        ttk.Button(project_tools, text="Analyze whole project", command=self._analyze_project).pack(side="left", padx=(0, 6), pady=2)
        ttk.Button(project_tools, text="Acceptance checklist", command=self._make_acceptance_checklist).pack(side="left", padx=6, pady=2)
        ttk.Button(project_tools, text="Task history", command=self._show_task_history).pack(side="left", padx=6, pady=2)
        ttk.Button(project_tools, text="Restore backup…", command=self._restore_workspace_backup).pack(side="left", padx=6, pady=2)
        ttk.Button(project_tools, text="Create starter template…", command=self._create_starter_template).pack(side="left", padx=6, pady=2)
        self.visual_button = ttk.Button(project_tools, text="Visual simulate project…", command=self._visual_simulate_project)
        self.visual_button.pack(side="left", padx=6, pady=2)

        self.status_var = tk.StringVar(value="Status: Ready")
        ttk.Label(outer, textvariable=self.status_var, font=("TkDefaultFont", 10, "bold")).pack(anchor="w", pady=(0, 5))

        self.tabs = ttk.Notebook(outer)
        self.tabs.pack(fill="both", expand=True)
        self.answer_box = self._new_text_tab("Final answer")
        self.analysis_box = self._new_text_tab("Analyses & cross-review")
        self.code_box = self._new_text_tab("Proposed code")
        self.review_box = self._new_text_tab("Reviews & votes")
        self.safety_box = self._new_text_tab("Safety & audit")
        self.activity_box = self._new_text_tab("Activity log")

    def _workspace_root(self) -> Path:
        raw = self.workspace_var.get().strip()
        if not raw:
            raise ValueError("Choose a workspace folder first.")
        root = Path(raw).expanduser().resolve()
        if not root.is_dir():
            raise ValueError("Choose an existing workspace folder first.")
        return root

    def _show_tool_report(self, title: str, content: str, save_name: str | None = None, checklist: bool = False):
        window = tk.Toplevel(self.root)
        window.title(title)
        window.geometry("900x650")
        window.minsize(600, 400)
        frame = ttk.Frame(window, padding=10)
        frame.pack(fill="both", expand=True)
        body = tk.Text(frame, wrap="word", font=("TkFixedFont", 10), undo=checklist)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=body.yview)
        body.configure(yscrollcommand=scroll.set)
        body.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        body.insert("1.0", content)
        buttons = ttk.Frame(window, padding=(10, 0, 10, 10)); buttons.pack(fill="x")
        def current_text(): return body.get("1.0", "end-1c")
        def save_report():
            path = filedialog.asksaveasfilename(parent=window, title="Save report", defaultextension=".md", initialfile=save_name or "council-report.md", filetypes=[("Markdown", "*.md"), ("Text", "*.txt"), ("All files", "*.*")])
            if path:
                try:
                    Path(path).write_text(current_text(), encoding="utf-8")
                    messagebox.showinfo("Saved", f"Saved report to:\n{path}", parent=window)
                except OSError as exc:
                    messagebox.showerror("Save failed", str(exc), parent=window)
        ttk.Button(buttons, text="Save report…", command=save_report).pack(side="left")
        if checklist:
            def use_checklist():
                existing = self.task_text.get("1.0", "end-1c").strip()
                self.task_text.delete("1.0", "end")
                self.task_text.insert("1.0", existing + "\n\nAcceptance criteria and verification plan:\n" + current_text())
                window.destroy()
                self._log("Acceptance checklist appended to the current task prompt.")
            ttk.Button(buttons, text="Add checklist to task", command=use_checklist).pack(side="left", padx=8)
        ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right")

    def _analyze_project(self):
        try:
            root = self._workspace_root()
            report = analyze_project(root)
            text = format_project_report(report)
            self._show_tool_report("Project Intelligence", text, "project-intelligence.md")
            self._log(f"Project inventory completed: {report['file_count']} supported files indexed; scan truncated={report['truncated']}.")
        except Exception as exc:
            messagebox.showerror("Project analysis failed", str(exc), parent=self.root)

    def _make_acceptance_checklist(self):
        task = self.task_text.get("1.0", "end-1c").strip()
        if not task or task.startswith("Describe the feature, bug, or project goal."):
            messagebox.showwarning("Task required", "Enter a task first so the checklist has something to compile.", parent=self.root)
            return
        try:
            content = compile_acceptance_checklist(task)
            self._show_tool_report("Acceptance Checklist — review before use", content, "acceptance-checklist.md", checklist=True)
        except Exception as exc:
            messagebox.showerror("Checklist failed", str(exc), parent=self.root)

    def _show_task_history(self):
        try:
            journal = TaskJournal(self._workspace_root())
            items = journal.list_recent(100)
            if not items:
                content = "# Task History\n\nNo completed council tasks have been recorded in this workspace yet."
            else:
                lines = ["# Recent Task History", "", "Most recent first. This journal stores task text and summaries, not source files.", ""]
                for item in reversed(items):
                    lines += [f"## {item.get('timestamp', 'unknown time')} — {item.get('status', 'unknown status')}", f"- Run ID: {item.get('run_id', '')}", f"- Task: {item.get('task', '')}", f"- Summary: {item.get('summary', '')}", f"- Report: {item.get('report_path', '')}", ""]
                content = "\n".join(lines)
            self._show_tool_report("Task History", content, "council-task-history.md")
        except Exception as exc:
            messagebox.showerror("Could not read task history", str(exc), parent=self.root)

    def _create_starter_template(self):
        kind = simpledialog.askstring(
            "Starter template",
            "Choose a template type:\nwebsite\nbrowser-game\nweb-simulation\npython-cli",
            parent=self.root,
        )
        if kind is None:
            return
        kind = kind.strip().lower()
        folder = filedialog.askdirectory(parent=self.root, title="Choose a new or empty destination folder", mustexist=False)
        if not folder:
            return
        try:
            written = create_starter_template(Path(folder), kind)
            self._log(f"Created {kind} starter template with {len(written)} files at {Path(folder).resolve()}.")
            messagebox.showinfo("Starter template created", "Created files:\n" + "\n".join(written) + "\n\nNo code was executed.", parent=self.root)
        except Exception as exc:
            messagebox.showerror("Could not create template", str(exc), parent=self.root)

    def _restore_workspace_backup(self):
        try:
            root = self._workspace_root()
            backup_root = root / ".council" / "backups"
            if not backup_root.is_dir():
                messagebox.showinfo("No backups", "No .council/backups folder exists for this workspace yet.", parent=self.root)
                return
            chosen = filedialog.askdirectory(parent=self.root, title="Choose a backup folder to restore", initialdir=str(backup_root), mustexist=True)
            if not chosen:
                return
            backup = Path(chosen).resolve()
            if not messagebox.askyesno("Confirm rollback", f"Restore files from this backup?\n\n{backup}\n\nCurrent versions will be snapshotted first. This changes workspace files.", parent=self.root):
                return
            changed = restore_backup(root, backup)
            self._log(f"Rollback restored {len(changed)} file(s) from {backup}.")
            messagebox.showinfo("Rollback complete", "Restored files:\n" + "\n".join(changed[:40]) + ("\n…" if len(changed) > 40 else ""), parent=self.root)
        except Exception as exc:
            messagebox.showerror("Rollback failed", str(exc), parent=self.root)

    def _new_text_tab(self, name: str) -> tk.Text:
        frame = ttk.Frame(self.tabs, padding=5)
        box = tk.Text(frame, wrap="word", font=("TkFixedFont", 10), undo=False)
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        box.configure(yscrollcommand=yscroll.set)
        box.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")
        box.insert("1.0", f"{name}\n\nResults will appear here.")
        box.configure(state="disabled")
        self.tabs.add(frame, text=name)
        return box

    def _set_box(self, box: tk.Text, content: str):
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", content)
        box.configure(state="disabled")

    def _append_box(self, box: tk.Text, content: str):
        box.configure(state="normal")
        box.insert("end", content + "\n")
        box.see("end")
        box.configure(state="disabled")

    def _log(self, message: str):
        stamp = datetime.now().strftime("%H:%M:%S")
        self._append_box(self.activity_box, f"[{stamp}] {message}")

    def _clear_placeholder(self, _event=None):
        current = self.task_text.get("1.0", "end-1c")
        if current.strip().startswith("Describe the feature, bug, or project goal."):
            self.task_text.delete("1.0", "end")
        self.task_text.unbind("<FocusIn>")

    def _choose_model(self):
        path = filedialog.askopenfilename(title="Choose a local GGUF model file", filetypes=[("GGUF model", "*.gguf"), ("All files", "*.*")])
        if path:
            self.model_var.set(path)
            self.model = None
            self.model_signature = None
            self._save_settings()

    def _choose_workspace(self):
        path = filedialog.askdirectory(title="Choose the only workspace the AI may edit")
        if path:
            self.workspace_var.set(path)
            self._save_settings()

    def _read_numeric(self, var, label, low, high):
        try:
            value = int(var.get().strip())
        except ValueError as exc:
            raise ValueError(f"{label} must be an integer.") from exc
        if not low <= value <= high:
            raise ValueError(f"{label} must be between {low} and {high}.")
        return value

    def _collect_settings(self):
        return {
            "model_path": self.model_var.get().strip(),
            "model_backend": self.backend_var.get().strip(),
            "local_server_url": self.server_url_var.get().strip(),
            "local_server_model": self.server_model_var.get().strip(),
            "workspace_path": self.workspace_var.get().strip(),
            "n_ctx": self._read_numeric(self.n_ctx_var, "Context", 2048, 131072),
            "n_threads": self._read_numeric(self.threads_var, "CPU threads", 1, 512),
            "n_gpu_layers": self._read_numeric(self.gpu_var, "GPU layers", -1, 999),
            "max_tokens": self._read_numeric(self.tokens_var, "Max output tokens", 256, 32768),
            "review_rounds": self._read_numeric(self.rounds_var, "Revision rounds", 0, 2),
            "allow_self_edit": bool(self.self_edit_var.get()),
            "autonomous_web_research": bool(self.web_research_var.get()),
            "max_context_chars": int(self.settings.get("max_context_chars", 24000)),
        }

    def _save_settings(self):
        try:
            self.settings.update(self._collect_settings())
            save_settings(self.settings)
        except ValueError:
            # In-progress typing is allowed; input is fully validated when starting a run.
            pass

    def _toggle_auto_apply(self):
        """Explicit user opt-in to apply only fully approved proposals without per-run confirmation."""
        enabled = not bool(self.auto_apply_var.get())
        if enabled:
            message = (
                "Enable autonomous workspace edits?\n\n"
                "The council may write changes without asking each time, but ONLY when all four peers approve, "
                "host safety checks pass, and the proposal stays inside the selected workspace. "
                "Existing files are backed up. Proposed code may run only in disposable test containers or a local headless browser; it is not run directly against the live workspace app. "
                "You can switch this off at any time."
            )
            if not messagebox.askyesno("Enable autonomous edits", message):
                return
        self.auto_apply_var.set(enabled)
        self.settings["auto_apply_approved"] = enabled
        save_settings(self.settings)
        self.auto_apply_button.configure(text="Autonomous edits: " + ("ON" if enabled else "OFF"))
        self._log("Autonomous workspace edits " + ("ENABLED" if enabled else "DISABLED") + ".")

    def _visual_simulate_project(self):
        """Open the current workspace in headless Chromium, exercise optional UI steps, and save a screenshot."""
        if self.running or self.visual_running:
            messagebox.showinfo("Council busy", "Wait for the current coding or visual simulation to finish before starting another run.")
            return
        try:
            workspace = self._workspace_root()
        except ValueError as exc:
            messagebox.showwarning("Choose a workspace", str(exc))
            return
        self.visual_button.configure(state="disabled")
        self.visual_running = True
        self.status_var.set("Status: Rendering project in headless Chromium…")
        self._log(f"Starting visual simulation for workspace: {workspace}")
        threading.Thread(target=self._visual_simulation_worker, args=(workspace,), daemon=True).start()

    def _visual_simulation_worker(self, workspace: Path):
        try:
            report = run_visual_browser_checks(workspace, {})
            self.events.put(("visual_done", report))
        except Exception as exc:
            self.events.put(("visual_error", str(exc)))

    def _search_web(self):
        """Search public web pages without blocking the Tkinter UI."""
        query = simpledialog.askstring(
            "Search the web", "What should the council research?", parent=self.root
        )
        if query is None:
            return
        query = query.strip()
        if not query:
            messagebox.showwarning("Search query required", "Enter a topic or question to search.")
            return
        self.web_search_button.configure(state="disabled")
        self.status_var.set("Status: Searching public web results…")
        self._log("Starting public web search: " + query[:300])
        threading.Thread(target=self._web_search_worker, args=(query,), daemon=True).start()

    def _web_search_worker(self, query: str):
        try:
            results = search_web(query, limit=6, timeout=10)
            self.events.put(("web_search_done", (query, results)))
        except Exception as exc:
            self.events.put(("web_search_error", str(exc)))

    def _run_council(self):
        if self.running or self.visual_running:
            return
        task = self.task_text.get("1.0", "end-1c").strip()
        if not task or task.startswith("Describe the feature, bug, or project goal."):
            messagebox.showwarning("Task required", "Describe what you want the coding council to do.")
            return
        try:
            settings = self._collect_settings()
        except ValueError as exc:
            messagebox.showerror("Check settings", str(exc))
            return
        if settings["model_backend"] == "gguf" and not settings["model_path"]:
            messagebox.showwarning("Choose a local model", "Choose a local .gguf model file, or select local-server and start an OpenAI-compatible server on this computer.")
            return
        workspace = Path(settings["workspace_path"]).expanduser()
        workspace.mkdir(parents=True, exist_ok=True)
        settings["workspace_path"] = str(workspace.resolve())
        self.settings.update(settings)
        save_settings(self.settings)
        self.current_result = None
        self.apply_button.configure(state="disabled")
        self.running = True
        self.run_button.configure(state="disabled")
        self.status_var.set("Status: Running local model; all four peers will review the same task…")
        self._set_box(self.answer_box, "Council is running. See Activity log for the current phase.")
        self._set_box(self.analysis_box, "Waiting for peer analyses…")
        self._set_box(self.code_box, "Waiting for candidate code…")
        self._set_box(self.review_box, "Waiting for independent reviews and final votes…")
        self._set_box(self.safety_box, "The host will check every proposed file before anything can be applied.")
        model_label = settings["model_path"] if settings["model_backend"] == "gguf" else f"{settings['local_server_url']} (model={settings['local_server_model'] or 'auto-detect'})"
        self._append_box(self.activity_box, "\n" + "=" * 70 + f"\nTask: {task}\nWorkspace: {settings['workspace_path']}\nBackend: {settings['model_backend']}\nModel: {model_label}\n")
        threading.Thread(target=self._worker, args=(settings, task), daemon=True).start()

    def _worker(self, settings: dict, task: str):
        try:
            signature = (settings.get("model_backend", "gguf"), settings["model_path"], settings.get("local_server_url", ""), settings.get("local_server_model", ""), settings["n_ctx"], settings["n_threads"], settings["n_gpu_layers"], settings["max_tokens"], settings.get("temperature", 0.2))
            if self.model is None or self.model_signature != signature:
                if settings.get("model_backend", "gguf") == "local-server":
                    self.events.put(("log", "Verifying the loopback model server and checking its available model IDs…"))
                    self.model = LocalServerModel(settings.get("local_server_url", "http://127.0.0.1:8080/v1"), settings.get("local_server_model", ""), max_tokens=settings["max_tokens"], temperature=float(settings.get("temperature", 0.2)))
                    self.events.put(("log", f"Local server verified. Selected model ID: {self.model.model}"))
                else:
                    self.events.put(("log", "Loading the local GGUF model into this process. First load may take a while…"))
                    self.model = LocalModel(
                        settings["model_path"], n_ctx=settings["n_ctx"], n_threads=settings["n_threads"],
                        n_gpu_layers=settings["n_gpu_layers"], max_tokens=settings["max_tokens"],
                        temperature=float(settings.get("temperature", 0.2)),
                    )
                self.model_signature = signature
            runner = CouncilRunner(
                self.model, Path(settings["workspace_path"]), allow_self_edit=settings["allow_self_edit"],
                max_context_chars=settings.get("max_context_chars", 24000),
                review_rounds=settings["review_rounds"], knowledge=self.knowledge,
                logger=lambda msg: self.events.put(("log", msg)), max_tokens=settings["max_tokens"],
                web_research_enabled=settings.get("autonomous_web_research", True),
            )
            result = runner.run_task(task)
            self.events.put(("done", result))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _drain_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "done":
                    self._show_result(payload)
                elif kind == "web_search_done":
                    self.web_search_button.configure(state="normal")
                    query, results = payload
                    content = format_search_context(query, results)
                    self._show_tool_report("Web search results", content, save_name="web-research.md")
                    self._log(f"Web search returned {len(results)} result(s) for: {query}")
                    if messagebox.askyesno("Add web research to task?", "Append these search results and source URLs to the council task context? Review the snippets first if they may be unreliable."):
                        current = self.task_text.get("1.0", "end-1c").strip()
                        self.task_text.delete("1.0", "end")
                        self.task_text.insert("1.0", (current + "\n\n" + content).strip())
                        self._log("Web search results appended to task context as untrusted source material.")
                elif kind == "web_search_error":
                    self.web_search_button.configure(state="normal")
                    self._log("Web search failed: " + payload)
                    messagebox.showerror("Web search failed", payload)
                elif kind == "visual_done":
                    self.visual_running = False
                    self.visual_button.configure(state="normal")
                    report = payload
                    self.status_var.set("Status: Visual simulation " + report.get("status", "UNKNOWN"))
                    content = report.get("summary", "No visual summary.") + "\n\n" + report.get("output", "")
                    if report.get("screenshot"):
                        content += "\n\nScreenshot: " + report["screenshot"]
                    if report.get("report"):
                        content += "\nSaved report: " + report["report"]
                    self._show_tool_report("Visual simulation report", content, save_name="visual-simulation.md")
                    self._log("Visual simulation: " + report.get("status", "UNKNOWN") + " — " + report.get("summary", ""))
                    if report.get("screenshot") and messagebox.askyesno("Open screenshot?", "Visual simulation finished. Open the saved screenshot now?"):
                        try:
                            webbrowser.open(Path(report["screenshot"]).resolve().as_uri())
                        except Exception as exc:
                            messagebox.showwarning("Could not open screenshot", str(exc))
                elif kind == "visual_error":
                    self.visual_running = False
                    self.visual_button.configure(state="normal")
                    self.status_var.set("Status: Visual simulation failed")
                    self._log("Visual simulation error: " + payload)
                    messagebox.showerror("Visual simulation failed", payload)
                elif kind == "error":
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.status_var.set("Status: Error — no proposal applied")
                    self._log("ERROR: " + payload)
                    messagebox.showerror("Council error", payload)
        except queue.Empty:
            pass
        self.root.after(150, self._drain_events)

    def _show_result(self, result):
        self.running = False
        try:
            TaskJournal(Path(result.workspace)).record(result.task, result.final_status, result.summary or result.answer, result.run_id, result.report_path)
        except Exception as exc:
            self._log("Task history could not be recorded: " + str(exc))
        self.run_button.configure(state="normal")
        self.current_result = result
        self.status_var.set("Status: " + result.final_status)
        plan_text = json.dumps(result.task_plan, indent=2, ensure_ascii=False) if getattr(result, "task_plan", None) else "No structured task plan was recorded."
        research = getattr(result, "web_research", {}) or {}
        research_text = json.dumps({key: research.get(key) for key in ("status", "queries", "sources", "iterations", "scope", "reason", "error") if key in research}, indent=2, ensure_ascii=False) if research else "No web research report was recorded."
        answer_view = (result.answer or result.summary or "No answer returned.") + "\n\nTASK PLAN / ACCEPTANCE CONTRACT\n" + plan_text + "\n\nSTATUS\n" + result.final_status
        self._set_box(self.answer_box, answer_view)
        analyses = []
        for agent in AGENTS:
            analyses.append("=" * 70 + f"\n{agent.name}\nINDEPENDENT ANALYSIS\n" + result.analyses.get(agent.name, "") + "\n\nCROSS-REVIEW\n" + result.cross_reviews.get(agent.name, ""))
        analyses.insert(0, "STRUCTURED TASK PLAN\n" + plan_text + "\n\nWEB RESEARCH TRACE\n" + research_text)
        self._set_box(self.analysis_box, "\n\n".join(analyses))
        if result.proposed_files:
            code = []
            for name, content in result.proposed_files.items():
                code.append(f"{'=' * 76}\nFILE: {name}\n{'=' * 76}\n{content}")
            code.insert(0, f"SUMMARY\n{result.summary}\n\nNOTES\n{result.notes}\n\nFiles proposed: {len(result.proposed_files)}\n")
            self._set_box(self.code_box, "\n\n".join(code))
        else:
            self._set_box(self.code_box, "No file changes were proposed.\n\n" + result.summary + "\n" + result.notes)
        revs = []
        for review in result.reviews:
            revs.append(f"{review.get('agent')} — {review.get('vote')}\n{review.get('reason','')}\nFindings: {review.get('findings', review.get('remaining_blockers', []))}\nStrengths: {review.get('strengths', [])}")
        revs.append("\nFINAL PEER VOTES\n")
        for vote in result.votes:
            revs.append(f"{vote.get('agent')} — {vote.get('vote')}\nReason: {vote.get('reason','')}\nUnresolved blockers: {vote.get('remaining_blockers', [])}")
        self._set_box(self.review_box, "\n\n".join(revs) if revs else "No code-review phase was needed.")
        safety_text = [f"Status: {result.final_status}", f"Workspace: {result.workspace}", f"Run ID: {result.run_id}", f"Report: {result.report_path}", f"Candidate: {result.candidate_path}", "", "HOST SAFETY / APPROVAL-GATE ERRORS:"]
        safety_text += ["- " + e for e in result.safety_errors] or ["None"]
        safety_text += ["", "RISK WARNINGS:"]
        safety_text += ["- " + e for e in result.safety_warnings] or ["None"]
        safety_text += ["", "ISOLATED TEST REPORT:", json.dumps(result.test_report, indent=2, ensure_ascii=False) if result.test_report else "No isolated test report."]
        safety_text += ["", "WEB RESEARCH TRACE:", research_text]
        safety_text += ["", f"Can apply: {result.can_apply}", "Proposed code may have been executed in disposable test containers or a local headless browser; it was not run directly against the live workspace application."]
        self._set_box(self.safety_box, "\n".join(safety_text))
        if result.can_apply:
            self.apply_button.configure(state="normal")
            if self.auto_apply_var.get():
                if can_autonomously_apply(result):
                    self._log("Unanimous review and actual isolated runtime tests passed; autonomous mode will apply this proposal with a backup.")
                    self.root.after(50, self._apply_result)
                else:
                    status = (result.test_report or {}).get("status", "NO_REPORT")
                    self._log(f"AUTONOMOUS APPLY BLOCKED: runtime tests must actually pass (reported status: {status}). Manual Apply remains available after review.")
                    messagebox.showwarning("Automatic apply blocked", f"The council received peer approval, but unattended changes require actual isolated runtime tests to pass. Current test status: {status}.\n\nNo files were changed. Review the proposal and use Apply manually if you accept the risk.")
            else:
                messagebox.showinfo("Unanimous review complete", "All four peers approved this exact proposal and host checks passed. Review the code and Safety & audit tab, then use Apply if you approve the changes.")
        else:
            self.apply_button.configure(state="disabled")
        self._log(result.final_status)
        self._log(f"Saved audit report: {result.report_path}")

    def _apply_result(self):
        result = self.current_result
        if not result or not result.can_apply:
            messagebox.showwarning("Not eligible", "A unanimous peer vote and passing host checks are required before Apply is available.")
            return
        summary = f"Apply {len(result.proposed_files)} reviewed file(s) to:\n{result.workspace}\n\n{result.summary}\n\nThe current versions of overwritten files will be backed up under .council/backups. No generated code will be run."
        if result.safety_warnings:
            summary += "\n\nRISK WARNINGS:\n- " + "\n- ".join(result.safety_warnings)
        auto_apply = bool(self.auto_apply_var.get())
        if auto_apply and not can_autonomously_apply(result):
            status = (result.test_report or {}).get("status", "NO_REPORT")
            self._log(f"Autonomous apply blocked at final write gate: runtime tests status is {status}.")
            messagebox.showwarning("Automatic apply blocked", f"Unattended writes require actual isolated runtime tests to pass. Current status: {status}.\n\nNo files were changed. Turn off autonomous mode to review and approve this proposal manually.")
            return
        if not auto_apply and not messagebox.askyesno("Your approval required", summary + "\n\nDo you approve writing these exact files?"):
            self._log("User declined Apply. No workspace changes were made.")
            return
        if auto_apply:
            self._log("Autonomous apply requested. Rechecking approval state and workspace safety before writing.")
        try:
            # The core apply function revalidates unanimous approval, host safety checks, protected paths, and workspace boundaries.
            backup = apply_approved_result(result, allow_self_edit=bool(self.self_edit_var.get()))
            self.apply_button.configure(state="disabled")
            self.status_var.set("Status: Applied autonomously after approved review" if auto_apply else "Status: Applied after user approval")
            self._log(f"User approved and applied proposal. Backup: {backup}")
            self._set_box(self.safety_box, self.safety_box.get("1.0", "end-1c") + f"\n\nAPPLIED {'AUTONOMOUSLY AFTER EXPLICIT OPT-IN' if auto_apply else 'BY USER'}\nBackup location: {backup}")
            if auto_apply:
                self._log(f"Autonomous apply complete. Backup created at: {backup}")
            else:
                messagebox.showinfo("Applied", f"Changes applied. Backup created at:\n{backup}")
        except Exception as exc:
            self._log("Apply blocked: " + str(exc))
            messagebox.showerror("Could not apply proposal", str(exc))

    def _learn_from_result(self):
        result = self.current_result
        if not result:
            messagebox.showinfo("No run to learn from", "Run the council first, then verify the result in your project before saving it as a training example.")
            return
        if not messagebox.askyesno("Confirm successful result", "Have you independently checked the proposed answer/code and confirmed it solved the task? Only save examples you verified. This does not update model weights yet."):
            return
        feedback = simpledialog.askstring("What made it correct?", "Optional: describe what worked, tests you ran, or what to avoid next time:", parent=self.root) or ""
        answer = (result.answer or result.summary or "")
        if result.proposed_files:
            answer += "\n\nProposed files (reviewed by user):\n" + json.dumps(result.proposed_files, ensure_ascii=False)
        try:
            item_id = self.learning.add_confirmed(result.task, answer, feedback, result.run_id)
            self._log(f"Saved user-confirmed learning example #{item_id}. Relevant examples can inform future tasks.")
            messagebox.showinfo("Learning example saved", "Saved locally. Future runs may retrieve this example when relevant. For actual weight fine-tuning, export the dataset and use the optional training script on compatible hardware.")
        except Exception as exc:
            messagebox.showerror("Could not save example", str(exc))

    def _export_training_data(self):
        path = filedialog.asksaveasfilename(title="Export confirmed training examples", defaultextension=".jsonl", filetypes=[("JSON Lines", "*.jsonl")], initialfile="council-training.jsonl")
        if not path:
            return
        try:
            count = self.learning.export_jsonl(Path(path))
            self._log(f"Exported {count} user-confirmed training example(s) to {path}")
            messagebox.showinfo("Training data exported", f"Exported {count} examples. An empty or tiny dataset will not meaningfully fine-tune a model.")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def _import_source(self):
        path = filedialog.askopenfilename(
            title="Import a local documentation/source file",
            filetypes=[("Docs and source", "*.txt *.md *.rst *.py *.js *.ts *.html *.htm *.css *.json *.toml *.yaml *.yml *.xml *.sql *.sh *.rs *.go *.java *.cs *.cpp *.c *.h *.pdf"), ("All files", "*.*")]
        )
        if not path:
            return
        title = simpledialog.askstring("Source title", "Enter a title for this source:", initialvalue=Path(path).name, parent=self.root)
        if title is None:
            return
        origin = simpledialog.askstring("Provenance", "Where did this source come from? Example: official Python docs, URL, project manual:", initialvalue="Local file; origin not yet verified", parent=self.root)
        if origin is None:
            return
        try:
            source_id = self.knowledge.add_file(Path(path), title, origin, verified=False)
            self._refresh_source_count()
            self._log(f"Imported knowledge source #{source_id} as UNVERIFIED. It will not influence answers until you review and verify it.")
            messagebox.showinfo("Imported as unverified", f"Source ID: {source_id}\n\nIt will not be used in answers until you review it and explicitly mark it verified.")
        except Exception as exc:
            messagebox.showerror("Import failed", str(exc))

    def _refresh_source_count(self):
        sources = self.knowledge.list_sources()
        verified = sum(1 for s in sources if s["verified"])
        self.source_count_var.set(f"Sources: {len(sources)} total / {verified} verified")

    def _manage_sources(self):
        sources = self.knowledge.list_sources()
        if not sources:
            messagebox.showinfo("Knowledge notebook", "No sources yet. Import local documentation or code first.")
            return
        choices = []
        for s in sources:
            label = "VERIFIED" if s["verified"] else "UNVERIFIED"
            choices.append(f"#{s['id']} [{label}] {s['title']} — {s['origin']}\n  File: {s['file_path']}\n  SHA-256: {s['sha256']}")
        picked = simpledialog.askinteger("Choose source", "Review each source's title, origin, and file before trusting it.\n\n" + "\n\n".join(choices) + "\n\nEnter source ID to inspect:", parent=self.root, minvalue=1)
        if picked is None:
            return
        source = self.knowledge.get_source(picked)
        if not source:
            messagebox.showerror("Not found", "That source ID does not exist.")
            return
        body = source["body"][:3000]
        info = f"Title: {source['title']}\nOrigin: {source['origin']}\nPath: {source['file_path']}\nSHA-256: {source['sha256']}\nAlready verified: {bool(source['verified'])}\n\nCONTENT PREVIEW\n{'-'*60}\n{body}"
        if messagebox.askyesno("Review source", info + "\n\nHave you independently checked that this source and its origin are trustworthy and that the content is appropriate for your project? Mark verified?"):
            try:
                self.knowledge.verify_source(picked)
                self._refresh_source_count()
                self._log(f"Knowledge source #{picked} explicitly marked verified by the user.")
            except Exception as exc:
                messagebox.showerror("Could not verify source", str(exc))


def launch_app():
    root = tk.Tk()
    CodingCouncilApp(root)
    root.mainloop()
