"""Bounded project intelligence, acceptance-checklist compilation, and local task history.

All analysis is read-only. No project commands are executed and Git is queried only
with read-only status/log commands when available.
"""
from __future__ import annotations
import json
import os
import re
import shutil
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .safety import IGNORED_DIRS, TEXT_SUFFIXES, is_secret_path, is_within, ensure_managed_directory

MAX_FILES = 20_000
MAX_DIRS = 8_000
MAX_FILE_BYTES = 160_000
MAX_TOTAL_BYTES = 30 * 1024 * 1024
MANIFEST_NAMES = {"package.json", "pyproject.toml", "requirements.txt", "requirements-dev.txt", "cargo.toml", "go.mod", "pom.xml", "build.gradle", "build.gradle.kts", "composer.json", "gemfile", "pubspec.yaml", "dockerfile", "makefile"}
ENTRY_NAMES = {"main.py", "app.py", "main.js", "main.ts", "index.js", "index.ts", "index.html", "server.py", "server.js", "manage.py", "program.cs", "main.go", "main.rs"}


def analyze_project(root: Path) -> dict[str, Any]:
    """Build a bounded inventory and evidence-based architecture hint report."""
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("Choose an existing project folder first.")
    files: list[Path] = []
    scanned_files = scanned_dirs = total_bytes = 0
    truncated = False
    for base, dirs, names in os.walk(root, followlinks=False):
        scanned_dirs += 1
        if scanned_dirs > MAX_DIRS:
            truncated = True
            break
        bp = Path(base)
        dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS and d != ".council" and not (bp / d).is_symlink() and not is_secret_path((bp / d).relative_to(root).as_posix()))
        for name in sorted(names):
            scanned_files += 1
            if scanned_files > MAX_FILES:
                truncated = True
                break
            p = bp / name
            if p.is_symlink() or not is_within(p, root):
                continue
            rel = p.relative_to(root).as_posix()
            if is_secret_path(rel):
                continue
            try:
                size = p.stat().st_size
            except OSError:
                continue
            if size > MAX_FILE_BYTES or total_bytes + size > MAX_TOTAL_BYTES:
                continue
            if p.suffix.lower() in TEXT_SUFFIXES or name.lower() in MANIFEST_NAMES or name.lower() in {"makefile", "dockerfile", ".gitignore", ".editorconfig"}:
                files.append(p)
                total_bytes += size
        if scanned_files > MAX_FILES:
            break
    ext = Counter((p.suffix.lower() or "[no extension]") for p in files)
    manifests = [p.relative_to(root).as_posix() for p in files if p.name.lower() in MANIFEST_NAMES]
    entry_points = [p.relative_to(root).as_posix() for p in files if p.name.lower() in ENTRY_NAMES or p.name.lower().startswith("index.")]
    tests = [p.relative_to(root).as_posix() for p in files if re.search(r"(^|/)(tests?|specs?)(/|$)|(^|[._-])(test|spec)[._-]", p.relative_to(root).as_posix(), re.I)]
    readmes = [p.relative_to(root).as_posix() for p in files if p.name.lower().startswith("readme")]
    todos = []
    for p in files:
        try:
            body = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line in enumerate(body.splitlines(), 1):
            if re.search(r"\b(TODO|FIXME|HACK|XXX)\b", line, re.I):
                todos.append(f"{p.relative_to(root).as_posix()}:{lineno}: {line.strip()[:180]}")
                if len(todos) >= 100:
                    break
        if len(todos) >= 100:
            break
    security_flags: list[str] = []
    accessibility_flags: list[str] = []
    performance_flags: list[str] = []
    dependency_hints: list[str] = []
    for p in files:
        rel = p.relative_to(root).as_posix()
        try:
            body = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if re.search(r"(?i)(api[_-]?key|secret|password|access[_-]?token)\s*[:=]\s*['\"](?!(?:your_|change_me|example|placeholder))[^'\"]{8,}['\"]", body):
            security_flags.append(f"{rel}: possible hard-coded credential-like value; verify manually (may be a false positive)")
        if re.search(r"\beval\s*\(|new Function\s*\(|innerHTML\s*=", body):
            security_flags.append(f"{rel}: dynamic code/HTML construction pattern; inspect input sanitization and trust boundaries")
        if p.suffix.lower() in {".html", ".htm", ".jsx", ".tsx", ".vue", ".svelte"}:
            for match in re.finditer(r"<img\b(?![^>]*\balt\s*=)[^>]*>", body, re.I):
                accessibility_flags.append(f"{rel}: image appears to lack alt text near character {match.start()}")
            for match in re.finditer(r"<input\b(?![^>]*\baria-label\s*=)(?![^>]*\bid\s*=)[^>]*>", body, re.I):
                accessibility_flags.append(f"{rel}: input appears to lack an id/aria-label near character {match.start()}")
        if re.search(r"setInterval\s*\([^,]+,\s*[0-9]{1,2}\s*\)", body):
            performance_flags.append(f"{rel}: very frequent interval may create avoidable CPU load; measure before changing")
        if p.name.lower() == "package.json":
            try:
                pkg = json.loads(body)
                for section in ("dependencies", "devDependencies", "optionalDependencies"):
                    values = pkg.get(section, {}) if isinstance(pkg, dict) else {}
                    if isinstance(values, dict):
                        dependency_hints.extend(f"{name}@{version} ({section})" for name, version in values.items())
            except json.JSONDecodeError:
                security_flags.append(f"{rel}: package manifest is invalid JSON")
        elif p.name.lower() in {"requirements.txt", "requirements-dev.txt"}:
            dependency_hints.extend(line.strip() for line in body.splitlines() if line.strip() and not line.lstrip().startswith("#") and len(dependency_hints) < 500)
    security_flags = list(dict.fromkeys(security_flags))[:100]
    accessibility_flags = list(dict.fromkeys(accessibility_flags))[:100]
    performance_flags = list(dict.fromkeys(performance_flags))[:100]
    dependency_hints = list(dict.fromkeys(dependency_hints))[:300]
    git_summary = "Git not detected or this is not a Git repository."
    git = shutil.which("git")
    if git:
        try:
            result = subprocess.run([git, "-C", str(root), "status", "--short", "--branch"], capture_output=True, text=True, timeout=3, check=False)
            if result.returncode == 0:
                git_summary = result.stdout.strip()[:4000] or "Git repository is clean (status output empty)."
        except (OSError, subprocess.SubprocessError):
            git_summary = "Git status unavailable (timed out or failed); no changes made."
    return {
        "root": str(root), "created_at": datetime.now(timezone.utc).isoformat(),
        "file_count": len(files), "scanned_files": min(scanned_files, MAX_FILES), "scanned_dirs": min(scanned_dirs, MAX_DIRS),
        "bytes_included": total_bytes, "truncated": truncated,
        "extensions": ext.most_common(20), "manifests": sorted(manifests),
        "entry_points": sorted(entry_points)[:100], "test_paths": sorted(tests)[:200],
        "readmes": sorted(readmes)[:50], "todos": todos, "git_status": git_summary,
        "security_flags": security_flags, "accessibility_flags": accessibility_flags,
        "performance_flags": performance_flags, "dependency_hints": dependency_hints,
        "file_inventory": sorted(p.relative_to(root).as_posix() for p in files)[:MAX_FILES],
    }


def format_project_report(report: dict[str, Any]) -> str:
    lines = ["# Coding Council — Project Intelligence Report", "", f"- Workspace: `{report['root']}`", f"- Created: {report['created_at']}", f"- Readable source/config files indexed: {report['file_count']}", f"- Approximate bytes included: {report['bytes_included']:,}", f"- Scan capped/truncated: {'YES — report may be incomplete' if report['truncated'] else 'No'}", "", "## File types"]
    lines += [f"- `{ext}`: {count}" for ext, count in report["extensions"]] or ["- No supported text/source files found."]
    for title, key in [("Project manifests / dependencies", "manifests"), ("Likely entry points", "entry_points"), ("Detected test paths", "test_paths"), ("Readme files", "readmes")]:
        lines += ["", f"## {title}"] + ([f"- `{x}`" for x in report[key]] if report[key] else ["- None detected by filename heuristics."])
    lines += ["", "## TODO / FIXME markers"] + ([f"- {x}" for x in report["todos"]] if report["todos"] else ["- None detected in scanned text files."])
    for title, key in [("Static security flags (advisory)", "security_flags"), ("Accessibility hints (advisory)", "accessibility_flags"), ("Performance hints (advisory)", "performance_flags"), ("Dependency declarations (not vulnerability-checked)", "dependency_hints")]:
        lines += ["", f"## {title}"] + ([f"- {x}" for x in report[key]] if report[key] else ["- None detected by current heuristics."])
    lines += ["", "## Git status (read-only)", "```text", report["git_status"], "```", "", "## File inventory"] + [f"- `{x}`" for x in report["file_inventory"]]
    lines += ["", "## Limitations", "This report uses bounded filename/extension heuristics. It does not prove the runtime architecture, resolve all dependencies, execute code, verify tests, or guarantee all files were indexed. Secret-like paths, symlinks, ignored folders, large files, and unsupported binary files are omitted."]
    return "\n".join(lines)


def compile_acceptance_checklist(task: str) -> str:
    """Turn a natural-language task into a reviewable, editable checklist (heuristic, not AI proof)."""
    task = str(task or "").strip()
    if not task:
        raise ValueError("Enter a task or project goal first.")
    if len(task) > 20_000:
        raise ValueError("Task text is too long (20,000 characters maximum).")
    normalized = task.replace("\r\n", "\n")
    raw_items: list[str] = []
    for line in normalized.splitlines():
        line = re.sub(r"^\s*(?:[-*•]+|\d+[.)])\s*", "", line).strip()
        if not line:
            continue
        # Preserve explicit bullets; split prose sentences only when they look like separate requests.
        pieces = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", line) if len(line) > 180 else [line]
        raw_items.extend(piece.strip() for piece in pieces if piece.strip())
    if not raw_items:
        raw_items = [task]
    unique: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        key = re.sub(r"\W+", " ", item.casefold()).strip()
        if key and key not in seen:
            unique.append(item[:500]); seen.add(key)
        if len(unique) >= 40:
            break
    lines = ["# Acceptance Checklist", "", "> Drafted by deterministic text heuristics. Review and edit these criteria before treating them as complete.", "", "## Requirements"]
    lines += [f"- [ ] {item}" for item in unique]
    lines += ["", "## Verification plan", "- [ ] Confirm the application starts using the project's documented command.", "- [ ] Run the existing test suite; record the exact command and output.", "- [ ] Add or update tests for every changed behavior and important edge case.", "- [ ] Exercise the primary user flow end to end in the intended runtime.", "- [ ] Check invalid inputs, empty states, failure paths, and recovery behavior.", "- [ ] Check responsive layout on a small phone, tablet, and desktop if UI is involved.", "- [ ] Check accessibility basics: keyboard use, labels, focus visibility, and contrast if UI is involved.", "- [ ] Review dependency changes, secrets handling, and unsafe file/network/command operations.", "- [ ] Record tests not run and remaining uncertainty; do not claim unperformed verification.", "", "## Release decision", "- [ ] No unresolved critical/high-severity findings.", "- [ ] Back up or commit the current working state before applying changes.", "- [ ] Confirm rollback instructions are available."]
    return "\n".join(lines)


class TaskJournal:
    """Append-only local JSONL task journal; stores summaries, not source files or secrets."""
    def __init__(self, workspace: Path):
        self.root = Path(workspace).expanduser().resolve()
        self.path = ensure_managed_directory(self.root) / "task_history.jsonl"

    def record(self, task: str, status: str, summary: str = "", run_id: str = "", report_path: str = "") -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        entry = {"timestamp": datetime.now(timezone.utc).isoformat(), "task": str(task)[:4000], "status": str(status)[:100], "summary": str(summary)[:4000], "run_id": str(run_id)[:200], "report_path": str(report_path)[:1000]}
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def list_recent(self, limit: int = 100) -> list[dict[str, Any]]:
        if not self.path.is_file():
            return []
        entries = []
        try:
            # Read only a bounded tail to avoid loading an unbounded journal.
            with self.path.open("rb") as f:
                f.seek(0, os.SEEK_END); end = f.tell(); f.seek(max(0, end - 2_000_000))
                if f.tell():
                    f.readline()
                data = f.read().decode("utf-8", errors="replace")
            for line in data.splitlines()[-max(1, min(int(limit), 500)):]:
                try:
                    item = json.loads(line)
                    if isinstance(item, dict): entries.append(item)
                except json.JSONDecodeError:
                    continue
        except OSError:
            return []
        return entries


def restore_backup(workspace: Path, backup_dir: Path) -> list[str]:
    """Restore a backup made by apply_files; refuses paths outside workspace."""
    from .safety import is_within
    root = Path(workspace).expanduser().resolve()
    backup = Path(backup_dir).expanduser().resolve()
    managed = ensure_managed_directory(root, "backups")
    if not is_within(backup, managed) or not backup.is_dir():
        raise ValueError("Choose a valid backup folder inside this workspace's .council/backups directory.")
    manifest_path = backup / "manifest.json"
    if not manifest_path.is_file():
        raise ValueError("This backup has no rollback manifest. Older backups can be inspected manually, but automatic rollback is unavailable.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    targets = manifest.get("targets")
    if not isinstance(targets, list) or len(targets) > 500:
        raise ValueError("Backup manifest is invalid or too large.")
    # Snapshot the current state before restoring, so the rollback itself can be undone manually.
    rollback_stamp = datetime.now().strftime("rollback_%Y%m%d_%H%M%S_%f")
    current_backup = managed / rollback_stamp
    current_backup.mkdir(parents=True, exist_ok=False)
    changed: list[str] = []
    current_targets: list[dict[str, Any]] = []
    for item in targets:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise ValueError("Backup manifest contains an invalid path entry.")
        rel = item["path"].replace("\\", "/")
        p = Path(rel)
        dest = (root / p).resolve()
        if p.is_absolute() or ".." in p.parts or not is_within(dest, root) or ".council" in p.parts:
            raise ValueError(f"Unsafe rollback path refused: {rel}")
        existed = bool(item.get("existed"))
        backup_file = (backup / p).resolve()
        if existed and (not is_within(backup_file, backup) or not backup_file.is_file()):
            raise ValueError(f"Required original file is missing from backup: {rel}")
        current_existed = dest.is_file()
        if dest.exists() and not dest.is_file():
            raise ValueError(f"Cannot replace a directory during rollback: {rel}")
        if current_existed:
            now_file = current_backup / p
            now_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, now_file)
        current_targets.append({"path": rel, "existed": current_existed})
        changed.append(rel)
    # All paths validated first. Apply restore in a second pass.
    for item in targets:
        rel = item["path"].replace("\\", "/"); p = Path(rel); dest = root / p
        if item.get("existed"):
            dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(backup / p, dest)
        elif dest.is_file():
            dest.unlink()
    (current_backup / "manifest.json").write_text(json.dumps({"targets": current_targets, "note": "Pre-rollback current-state snapshot."}, indent=2), encoding="utf-8")
    return changed


def create_starter_template(destination: Path, kind: str) -> list[str]:
    """Create a small starter project only inside a new or empty destination folder."""
    dest = Path(destination).expanduser().resolve()
    templates: dict[str, dict[str, str]] = {
        "website": {
            "index.html": "<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Starter Website</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><main><h1>Starter Website</h1><p>Edit this accessible, responsive starting point.</p><button id=\"action\" type=\"button\">Try interaction</button><p id=\"status\" aria-live=\"polite\"></p></main><script src=\"app.js\"></script></body></html>\n",
            "style.css": "*{box-sizing:border-box}body{margin:0;font:1rem/1.5 system-ui,sans-serif;background:#f4f7fb;color:#152238}main{width:min(100% - 2rem,60rem);margin:10vh auto;padding:clamp(1rem,4vw,3rem);background:white;border-radius:1rem}button{min-height:44px;padding:.7rem 1rem;font:inherit;cursor:pointer}button:focus-visible{outline:3px solid #2463eb;outline-offset:3px}\n",
            "app.js": "'use strict';\nconst action=document.querySelector('#action');const status=document.querySelector('#status');action?.addEventListener('click',()=>{if(status)status.textContent='Interaction works. Replace this with your feature.';});\n",
            "README.md": "# Starter Website\n\nOpen `index.html` in a modern browser. No build step is required.\n\n## Checklist\n- [ ] Test phone/tablet/desktop layouts.\n- [ ] Test keyboard focus and button behavior.\n- [ ] Add automated browser tests before release.\n",
        },
        "browser-game": {
            "index.html": "<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Browser Game Starter</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><main><h1>Browser Game Starter</h1><p>Use arrow keys or touch the controls.</p><canvas id=\"world\" width=\"640\" height=\"360\" aria-label=\"Game world\"></canvas><div class=\"controls\"><button data-dir=\"left\">Left</button><button data-dir=\"right\">Right</button><button id=\"reset\">Reset</button></div><p id=\"status\" aria-live=\"polite\"></p></main><script src=\"game.js\"></script></body></html>\n",
            "style.css": "body{margin:0;padding:1rem;background:#101827;color:#f3f6ff;font:1rem/1.5 system-ui,sans-serif}main{max-width:680px;margin:auto}canvas{width:100%;height:auto;background:#e8f0ff;border-radius:12px;touch-action:pan-y}.controls{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem}button{min-height:44px;padding:.6rem 1rem;font:inherit}\n",
            "game.js": "'use strict';\nconst canvas=document.querySelector('#world'),ctx=canvas?.getContext('2d');let x=canvas.width/2,y=canvas.height/2;function draw(){if(!ctx)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#2367df';ctx.beginPath();ctx.arc(x,y,15,0,Math.PI*2);ctx.fill();}function move(d){x=Math.max(15,Math.min(canvas.width-15,x+d));draw();}document.querySelectorAll('[data-dir]').forEach(b=>b.addEventListener('click',()=>move(b.dataset.dir==='left'?-20:20)));document.querySelector('#reset')?.addEventListener('click',()=>{x=canvas.width/2;y=canvas.height/2;draw();});document.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')move(-10);if(e.key==='ArrowRight')move(10);});draw();\n",
            "README.md": "# Browser Game Starter\n\nOpen `index.html` in a browser. This is a tiny input/render loop starter, not a complete game engine.\n\n## Next steps\n- [ ] Add deterministic update logic.\n- [ ] Add state serialization and reset tests.\n- [ ] Test keyboard, touch, and narrow viewports.\n",
        },
        "python-cli": {
            "main.py": "def main() -> int:\n    print('Hello from your Coding Council starter project!')\n    return 0\n\n\nif __name__ == '__main__':\n    raise SystemExit(main())\n",
            "tests/test_main.py": "import unittest\nfrom main import main\n\nclass MainTests(unittest.TestCase):\n    def test_main_returns_success(self):\n        self.assertEqual(main(), 0)\n\nif __name__ == '__main__':\n    unittest.main()\n",
            "README.md": "# Python CLI Starter\n\nRun `python main.py`. Run tests with `python -m unittest discover -s tests -v`.\n\nNo third-party dependencies are required.\n",
        },
        "web-simulation": {
            "index.html": "<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Simulation Starter</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><main><h1>Simulation Starter</h1><p>Simple particle motion; change the parameters and extend the model.</p><div class=\"toolbar\"><label>Speed <input id=\"speed\" type=\"range\" min=\"0.2\" max=\"3\" step=\"0.1\" value=\"1\"></label><button id=\"toggle\">Pause</button><button id=\"reset\">Reset</button></div><canvas id=\"world\" width=\"800\" height=\"450\" aria-label=\"Particle simulation visualization\"></canvas><p id=\"status\" aria-live=\"polite\"></p></main><script src=\"simulation.js\"></script></body></html>\n",
            "style.css": "body{margin:0;padding:1rem;background:#0b1424;color:#eaf2ff;font:1rem/1.5 system-ui,sans-serif}main{max-width:900px;margin:auto}.toolbar{display:flex;align-items:center;gap:1rem;flex-wrap:wrap;margin:1rem 0}canvas{width:100%;height:auto;border:1px solid #345;background:#111f32;border-radius:12px}button{min-height:44px;padding:.6rem 1rem}\n",
            "simulation.js": "'use strict';\nconst c=document.querySelector('#world'),ctx=c?.getContext('2d'),speed=document.querySelector('#speed'),toggle=document.querySelector('#toggle'),reset=document.querySelector('#reset');let paused=false,t=0,last=0;function draw(){if(!ctx)return;ctx.clearRect(0,0,c.width,c.height);for(let i=0;i<80;i++){const x=(i*97+t*Number(speed?.value||1)*18)%c.width,y=(i*53+Math.sin(t*.02+i)*30)%c.height;ctx.fillStyle='#8bb8ff';ctx.fillRect(x,y,3,3);}}function frame(now){if(!paused)t+=(now-last)/16.67;last=now;draw();requestAnimationFrame(frame);}toggle?.addEventListener('click',()=>{paused=!paused;toggle.textContent=paused?'Resume':'Pause';});reset?.addEventListener('click',()=>{t=0;draw();});requestAnimationFrame(frame);\n",
            "README.md": "# Web Simulation Starter\n\nOpen `index.html` in a modern browser. The starter includes a responsive canvas, speed control, pause/resume, and reset.\n\nExtend it with explicit state models, deterministic updates, save/load, and performance measurements.\n",
        },
    }
    if kind not in templates:
        raise ValueError("Choose one of: website, browser-game, python-cli, web-simulation.")
    if dest.exists() and (not dest.is_dir() or any(dest.iterdir())):
        raise ValueError("Choose a new or empty destination folder; existing files will not be overwritten.")
    dest.mkdir(parents=True, exist_ok=True)
    written = []
    for rel, content in templates[kind].items():
        target = (dest / rel).resolve()
        if not is_within(target, dest) or target.exists():
            raise ValueError(f"Refusing to overwrite or escape destination: {rel}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        written.append(rel)
    return written
