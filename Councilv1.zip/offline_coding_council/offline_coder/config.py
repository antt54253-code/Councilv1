"""User-owned settings. These are stored outside any project workspace."""
from __future__ import annotations
import json
import os
from pathlib import Path

APP_DIR = Path.home() / ".offline_coding_council"
SETTINGS_PATH = APP_DIR / "settings.json"

DEFAULT_SETTINGS = {
    "model_path": "",
    "model_backend": "gguf",
    "local_server_url": "http://127.0.0.1:8080/v1",
    "local_server_model": "",
    "workspace_path": str(Path.home() / "OfflineCodingWorkspace"),
    "n_ctx": 16384,
    "n_threads": max(1, (os.cpu_count() or 4) - 1),
    "n_gpu_layers": 0,
    "max_tokens": 4096,
    "temperature": 0.2,
    "review_rounds": 1,
    "allow_self_edit": False,
    "auto_apply_approved": False,
    "autonomous_web_research": True,
    "max_context_chars": 12000,
}


def load_settings() -> dict:
    settings = DEFAULT_SETTINGS.copy()
    try:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        if SETTINGS_PATH.exists():
            loaded = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                settings.update({k: v for k, v in loaded.items() if k in settings})
    except (OSError, json.JSONDecodeError):
        pass
    return settings


def save_settings(settings: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    # Only known settings are persisted. Agents never receive a write handle to this file.
    safe = {k: settings.get(k, v) for k, v in DEFAULT_SETTINGS.items()}
    temp = SETTINGS_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(safe, indent=2), encoding="utf-8")
    os.replace(temp, SETTINGS_PATH)
