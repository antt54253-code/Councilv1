"""Offline Coding Council — local inference, four peer reviewers, human-controlled writes."""
__version__ = "0.1.0"
