"""Responsive phone/tablet web companion for the local-only coding council."""
from __future__ import annotations
import argparse, json, secrets, socket, threading, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from .config import load_settings
from .model_backend import LocalModel
from .knowledge import KnowledgeStore
from .council import CouncilRunner, apply_approved_result
from .web_search import search_web, format_search_context

PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="dark"><title>Offline Coding Council</title><style>
:root{color-scheme:dark;--bg:#0b1020;--panel:#151d30;--line:#2b3852;--text:#edf2ff;--muted:#a8b5ce;--accent:#8bb5ff}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,-apple-system,sans-serif}header{position:sticky;top:0;background:#0b1020ed;border-bottom:1px solid var(--line);padding:14px;z-index:2}h1{font-size:1.2rem;margin:0}header p,.muted{color:var(--muted);font-size:.9rem}header p{margin:3px 0 0}main{max-width:900px;margin:auto;padding:14px 14px 30px;display:grid;gap:12px}.card{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:15px;min-width:0}h2{font-size:1rem;margin:0 0 10px}label{display:block;font-size:.9rem;color:var(--muted);margin:10px 0 5px}textarea,input,button{font:inherit;border-radius:10px;width:100%;padding:12px;border:1px solid var(--line);background:#0c1426;color:var(--text)}textarea{min-height:140px;resize:vertical}button{background:var(--accent);color:#081020;font-weight:700;border:0;cursor:pointer;margin-top:10px;min-height:46px}button.secondary{background:#263651;color:var(--text)}button.danger{background:#6a282b;color:white}button:disabled{opacity:.45}.tabs{display:flex;gap:6px;overflow:auto;padding-bottom:8px}.tabs button{width:auto;white-space:nowrap;margin:0;padding:9px 12px;min-height:40px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#0a1120;border:1px solid var(--line);padding:12px;border-radius:10px;max-height:55vh;overflow:auto;font:13px/1.5 ui-monospace,monospace}@media(min-width:760px){main{grid-template-columns:1fr 1fr}.wide{grid-column:1/-1}}
</style></head><body><header><h1>OFFLINE CODING COUNCIL</h1><p>Four equal peers · local model · adversarial review · you approve all writes</p></header><main><section class="card wide"><h2>Task</h2><p class="muted">The model runs on your computer. This phone page is a remote control on your local Wi-Fi, not a cloud AI service.</p><label for="task">What should the council build, debug, or explain?</label><textarea id="task" placeholder="Describe the goal, constraints, expected behavior, and how to test it."></textarea><label for="webQuery">Search the public web (optional)</label><input id="webQuery" maxlength="300" placeholder="Research a library, API, error, or technique"><button id="searchWeb" class="secondary">Search web and attach sources</button><div id="webResults" class="muted" aria-live="polite"></div><button id="run">Run all four reviewers</button><div id="status" class="muted" aria-live="polite">Ready.</div></section><section class="card wide"><h2>Result</h2><div class="tabs" id="tabs"></div><div id="result"><p class="muted">Run a task to see analyses, code, attack findings, votes, and safety checks.</p></div><button id="apply" class="danger" disabled>Apply unanimously approved code</button><p class="muted">Apply is disabled unless all four peers approve the exact patch and host safety checks pass. You must confirm again.</p></section><section class="card"><h2>Shared workspace</h2><div id="setup" class="muted">Loading local configuration…</div><button id="refreshFiles" class="secondary">Refresh project files</button><div id="files" class="muted" aria-live="polite">Loading files…</div><p class="muted">This is the same configured workspace used by the desktop app when both are running on the same computer.</p></section><section class="card"><h2>Safety rules</h2><ul class="muted"><li>No automatic code execution or shell commands.</li><li>Writes stay inside the selected workspace.</li><li>No secrets, protected controller files, or permission changes.</li><li>Model consensus never replaces your review.</li></ul></section></main><script>
const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';if(location.hash)history.replaceState(null,'',location.pathname+location.search);let result=null,active='Final answer';const views=['Final answer','Analyses','Cross-examination','Proposed code','Attack findings','Votes','Safety & audit'];const tabs=document.getElementById('tabs'),out=document.getElementById('result');for(const v of views){const b=document.createElement('button');b.className='secondary';b.textContent=v;b.onclick=()=>{active=v;render()};tabs.appendChild(b)}async function api(path,body){const headers={'Authorization':'Bearer '+token};if(body)headers['Content-Type']='application/json';const r=await fetch(path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}function pre(t){const e=document.createElement('pre');e.textContent=t||'No content.';return e}function render(){for(const b of tabs.children)b.style.background=b.textContent===active?'var(--accent)':'#263651';out.replaceChildren();if(!result){out.textContent='No run yet.';return}let v='';if(active==='Final answer')v=[result.final_status,result.answer,result.summary,result.notes].filter(Boolean).join('\n\n');if(active==='Analyses')v=Object.entries(result.analyses||{}).map(([k,x])=>k+'\n'+x).join('\n\n');if(active==='Cross-examination')v=Object.entries(result.cross_reviews||{}).map(([k,x])=>k+'\n'+x).join('\n\n');if(active==='Proposed code')v=Object.entries(result.proposed_files||{}).map(([k,x])=>'FILE: '+k+'\n'+x).join('\n\n------------------------------\n\n');if(active==='Attack findings')v=(result.reviews||[]).map(r=>r.agent+' — '+r.vote+'\n'+JSON.stringify(r.findings||[],null,2)).join('\n\n');if(active==='Votes')v=(result.votes||[]).map(x=>x.agent+' — '+x.vote+'\n'+(x.reason||'')+'\nBlockers: '+JSON.stringify(x.remaining_blockers||[])).join('\n\n');if(active==='Safety & audit')v=JSON.stringify({safety_errors:result.safety_errors,safety_warnings:result.safety_warnings,can_apply:result.can_apply,report_path:result.report_path,candidate_path:result.candidate_path},null,2);out.appendChild(pre(v));document.getElementById('apply').disabled=!result.can_apply}document.getElementById('searchWeb').onclick=async()=>{const query=document.getElementById('webQuery').value.trim();if(!query){alert('Enter a web search query first.');return}const button=document.getElementById('searchWeb');button.disabled=true;document.getElementById('webResults').textContent='Searching public web results…';try{const d=await api('/search',{query});const box=document.getElementById('webResults');box.replaceChildren();const pre=document.createElement('pre');pre.textContent=d.context;box.appendChild(pre);const add=document.createElement('button');add.className='secondary';add.textContent='Add research to task';add.onclick=()=>{const task=document.getElementById('task');task.value=(task.value.trim()+'\n\n'+d.context).trim();document.getElementById('webResults').appendChild(document.createTextNode('\nAdded to task context. Treat snippets as untrusted and verify important claims.'))};box.appendChild(add)}catch(e){document.getElementById('webResults').textContent='Search failed: '+e.message}finally{button.disabled=false}};document.getElementById('run').onclick=async()=>{const task=document.getElementById('task').value.trim();if(!task){alert('Enter a task first.');return}document.getElementById('run').disabled=true;document.getElementById('apply').disabled=true;document.getElementById('status').textContent='Running local model through independent analyses, adversarial attacks, reviews, and votes. This can take a while.';try{const d=await api('/run',{task});result=d.result;document.getElementById('status').textContent=result.final_status;active='Final answer';render()}catch(e){document.getElementById('status').textContent='Error: '+e.message}finally{document.getElementById('run').disabled=false}};document.getElementById('apply').onclick=async()=>{if(!result?.can_apply)return;if(!confirm('Apply these files to the selected workspace? Existing files will be backed up. Review the proposal first.'))return;try{const d=await api('/apply',{run_id:result.run_id,confirm:'APPLY'});result=d.result;document.getElementById('status').textContent=result.final_status;render()}catch(e){alert(e.message)}};async function refreshFiles(){const box=document.getElementById('files');box.textContent='Loading project files…';try{const d=await api('/files');box.replaceChildren();if(!d.files.length){box.textContent='No project files found yet.';return}for(const f of d.files){const row=document.createElement('div');row.style.cssText='padding:8px 0;border-bottom:1px solid var(--line);overflow-wrap:anywhere';const name=document.createElement('strong');name.textContent=f.path;row.appendChild(name);const meta=document.createElement('div');meta.className='muted';meta.textContent=f.kind==='directory'?'Folder':`${f.size} bytes`;row.appendChild(meta);box.appendChild(row)}}catch(e){box.textContent='Unable to list files: '+e.message}}document.getElementById('refreshFiles').onclick=refreshFiles;api('/status').then(d=>document.getElementById('setup').textContent=d.status).catch(e=>document.getElementById('setup').textContent='Unable to connect: '+e.message);refreshFiles();
</script></body></html>"""

def _valid_bearer(authorization: str, token: str) -> bool:
    scheme, _, supplied = authorization.partition(" ")
    return scheme.lower() == "bearer" and bool(supplied) and secrets.compare_digest(supplied, token)


def lan_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:s.connect(("192.0.2.1",80));return s.getsockname()[0]
    except OSError:return "127.0.0.1"
    finally:s.close()
def serve(host="127.0.0.1",port=8765):
    settings=load_settings(); model_path=str(settings.get("model_path","")).strip(); workspace=Path(str(settings.get("workspace_path","")).strip()).expanduser().resolve()
    if not model_path or not Path(model_path).is_file():raise SystemExit("Choose a local GGUF model in desktop settings first. No API key is needed.")
    if not workspace.is_dir():raise SystemExit(f"Configured workspace folder does not exist: {workspace}")
    token=secrets.token_urlsafe(24); model=LocalModel(model_path,settings.get("n_ctx",8192),settings.get("n_threads",4),settings.get("n_gpu_layers",0),settings.get("max_tokens",4096)); knowledge=KnowledgeStore(); state={"result":None,"busy":False}; lock=threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send_data(self,code,data,ctype="application/json; charset=utf-8"):
            raw=data.encode() if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type",ctype)
            self.send_header("Content-Length",str(len(raw)))
            self.send_header("Cache-Control","no-store")
            self.send_header("X-Content-Type-Options","nosniff")
            self.send_header("Referrer-Policy","no-referrer")
            self.send_header("X-Frame-Options","DENY")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(raw)
        def authorized(self):
            return _valid_bearer(self.headers.get("Authorization", ""), token)
        def do_GET(self):
            path=urllib.parse.urlparse(self.path).path
            # The static shell carries no data and can be served without a token.
            # The browser sends the secret only in Authorization headers after reading it
            # from a URL fragment, which is not transmitted in the initial HTTP request.
            if path=="/":return self.send_data(200,PAGE,"text/html; charset=utf-8")
            if not self.authorized():return self.send_data(403,{"error":"Missing or invalid access token."})
            if path=="/status":return self.send_data(200,{"status":f"Local model: {Path(model_path).name}\nWorkspace: {workspace}\nStop server to revoke mobile access."})
            if path=="/result":return self.send_data(200,{"result":state["result"]})
            if path=="/files":
                files=[]
                try:
                    for item in sorted(workspace.iterdir(), key=lambda x:(not x.is_dir(),x.name.lower())):
                        if item.name.startswith(".") and item.name not in {".github"}: continue
                        if item.is_symlink(): continue
                        if item.is_dir(): files.append({"path":item.name+"/","kind":"directory","size":0})
                        elif item.is_file(): files.append({"path":item.name,"kind":"file","size":item.stat().st_size})
                        if len(files)>=300: break
                except OSError as e:return self.send_data(500,{"error":f"Could not list workspace: {e}"})
                return self.send_data(200,{"workspace":str(workspace),"files":files})
            return self.send_data(404,{"error":"Not found"})
        def do_POST(self):
            if not self.authorized():return self.send_data(403,{"error":"Missing or invalid access token."})
            path=urllib.parse.urlparse(self.path).path
            try:
                length=int(self.headers.get("Content-Length","0"))
                if length < 0:return self.send_data(400,{"error":"Invalid content length."})
                if length>1_000_000:return self.send_data(413,{"error":"Request too large."})
                body=json.loads(self.rfile.read(length) or b"{}")
            except Exception:return self.send_data(400,{"error":"Invalid JSON."})
            if path=="/search":
                query=body.get("query")
                if not isinstance(query,str) or not query.strip():return self.send_data(400,{"error":"A search query is required."})
                if len(query)>300:return self.send_data(400,{"error":"Search query must be 300 characters or fewer."})
                try:
                    results=search_web(query,limit=6,timeout=10)
                    return self.send_data(200,{"query":query,"results":results,"context":format_search_context(query,results)})
                except Exception as e:return self.send_data(502,{"error":str(e)[:500]})
            if path=="/run":
                if not isinstance(body.get("task"),str) or not body["task"].strip():return self.send_data(400,{"error":"A task is required."})
                with lock:
                    if state["busy"]:return self.send_data(409,{"error":"A council run is already active."})
                    state["busy"]=True
                try:
                    runner=CouncilRunner(model,workspace,allow_self_edit=bool(settings.get("allow_self_edit",False)),max_context_chars=settings.get("max_context_chars",12000),review_rounds=settings.get("review_rounds",1),knowledge=knowledge,max_tokens=settings.get("max_tokens",4096),web_research_enabled=settings.get("autonomous_web_research",True))
                    result=runner.run_task(body["task"][:12000]);state["result"]=json.loads(json.dumps(result,default=lambda o:o.__dict__));return self.send_data(200,{"result":state["result"]})
                except Exception as e:return self.send_data(500,{"error":str(e)[:1000]})
                finally:
                    with lock:state["busy"]=False
            if path=="/apply":
                r=state["result"]
                if not r or not r.get("can_apply"):return self.send_data(409,{"error":"No eligible unanimous proposal is waiting."})
                if body.get("confirm")!="APPLY" or body.get("run_id")!=r.get("run_id"):return self.send_data(400,{"error":"Confirmation/run ID mismatch."})
                # Rehydrate only known result fields. The apply function checks unanimous votes and host path/hash rules.
                from .council import RunResult
                try:
                    obj=RunResult(**{k:v for k,v in r.items() if k in RunResult.__dataclass_fields__})
                    apply_approved_result(obj,allow_self_edit=bool(settings.get("allow_self_edit",False)));state["result"]=json.loads(json.dumps(obj,default=lambda o:o.__dict__));return self.send_data(200,{"result":state["result"]})
                except Exception as e:return self.send_data(400,{"error":str(e)[:1000]})
            return self.send_data(404,{"error":"Not found"})
    server=ThreadingHTTPServer((host,port),Handler);ip=lan_ip();print("\nOFFLINE CODING COUNCIL — MOBILE MODE (local model, no cloud API)")
    print(f"Computer: http://127.0.0.1:{port}/#token={token}")
    if host in {"0.0.0.0", "::"}:
        print(f"Phone on same trusted Wi-Fi: http://{ip}:{port}/#token={token}")
        print("WARNING: LAN mode was explicitly enabled. HTTP is unencrypted; use only a trusted private network, never public Wi-Fi, and never port-forward this service.")
    elif host not in {"127.0.0.1", "localhost"}:
        print(f"Bound to {host}:{port}. Share only with trusted devices on a network you control.")
    else:
        print("Local-only mode: other devices cannot connect. To intentionally expose it on your private LAN, restart with --host 0.0.0.0.")
    print("The token is placed in the URL fragment and then removed from browser history; API calls use an Authorization header. Stop with Ctrl+C to revoke the token.")
    try:server.serve_forever()
    except KeyboardInterrupt:print("Stopping mobile server.")
    finally:server.server_close()
def main():
    p=argparse.ArgumentParser(description="Responsive phone/tablet UI for the local coding council");p.add_argument("--host",default="127.0.0.1");p.add_argument("--port",type=int,default=8765);a=p.parse_args();serve(a.host,a.port)
if __name__=="__main__":main()
