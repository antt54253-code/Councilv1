"""Optional real-browser smoke tests and visual snapshots for web projects.

Requires Playwright plus a local Chromium installation. The runner serves only a
throwaway snapshot on loopback, blocks browser requests to non-loopback origins,
records JavaScript/page errors, captures screenshots, and can perform a small
allow-listed set of UI actions from council.visual.json. This is useful testing,
not a security boundary or proof that arbitrary code is safe.
"""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Mapping

from .isolated_tests import _copy_workspace

VISUAL_MANIFEST = "council.visual.json"
WEB_SUFFIXES = {".html", ".htm", ".css", ".js", ".mjs", ".cjs"}


class _QuietStaticHandler(SimpleHTTPRequestHandler):
    def log_message(self, _format: str, *_args: Any) -> None:
        return


def _safe_relative(raw: str) -> Path | None:
    text = str(raw or "").replace("\\", "/")
    rel = Path(text)
    if not text or rel.is_absolute() or ".." in rel.parts or not rel.parts:
        return None
    return rel


def _read_manifest(root: Path, proposed_files: Mapping[str, str]) -> tuple[dict[str, Any] | None, str | None]:
    proposed = next((v for k, v in proposed_files.items() if k.replace("\\", "/").strip("/") == VISUAL_MANIFEST), None)
    path = root / VISUAL_MANIFEST
    if proposed is None and not path.is_file():
        return None, None
    try:
        obj = json.loads(proposed if proposed is not None else path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return None, f"Visual test manifest is invalid: {exc}"
    if not isinstance(obj, dict):
        return None, "Visual test manifest must be a JSON object."
    return obj, None


def _apply_proposals(snapshot: Path, proposed_files: Mapping[str, str]) -> str | None:
    for raw, content in proposed_files.items():
        rel = _safe_relative(raw)
        if rel is None:
            return f"Unsafe proposed path refused by visual runner: {raw}"
        target = snapshot / rel
        # Do not let proposals write through symlinks already in the copied project.
        current = snapshot
        for part in rel.parts[:-1]:
            current = current / part
            if current.is_symlink():
                return f"Symlink path refused by visual runner: {raw}"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return None


def run_visual_browser_checks(
    workspace: Path,
    proposed_files: Mapping[str, str] | None = None,
    *,
    timeout: int = 20,
    output_dir: Path | None = None,
) -> dict[str, Any]:
    """Open a local web project in headless Chromium and save a screenshot/report."""
    proposed_files = proposed_files or {}
    root = Path(workspace).expanduser().resolve()
    relevant = any(Path(name).suffix.lower() in WEB_SUFFIXES or Path(name).name == VISUAL_MANIFEST for name in proposed_files)
    if not relevant and not (root / VISUAL_MANIFEST).is_file() and not any((root / name).is_file() for name in ("index.html", "main.html", "app.html")):
        return {"status": "NOT_APPLICABLE", "summary": "No web entry page or visual-test manifest found.", "output": "", "screenshot": "", "scenarios": []}

    manifest, manifest_error = _read_manifest(root, proposed_files)
    if manifest_error:
        return {"status": "FAILED", "summary": manifest_error, "output": "", "screenshot": "", "scenarios": []}
    manifest = manifest or {}
    entry = manifest.get("entry", "index.html")
    entry_rel = _safe_relative(entry)
    if entry_rel is None or entry_rel.suffix.lower() not in {".html", ".htm"}:
        return {"status": "FAILED", "summary": "Visual entry must be a safe relative .html or .htm path.", "output": "", "screenshot": "", "scenarios": []}

    viewport = manifest.get("viewport", {})
    if not isinstance(viewport, dict):
        return {"status": "FAILED", "summary": "Visual viewport must be an object.", "output": "", "screenshot": "", "scenarios": []}
    width, height = viewport.get("width", 1280), viewport.get("height", 800)
    if not isinstance(width, int) or not isinstance(height, int) or not (320 <= width <= 1920 and 240 <= height <= 1200):
        return {"status": "FAILED", "summary": "Visual viewport bounds are invalid (width 320–1920, height 240–1200).", "output": "", "screenshot": "", "scenarios": []}
    steps = manifest.get("steps", [])
    if not isinstance(steps, list) or len(steps) > 30:
        return {"status": "FAILED", "summary": "Visual steps must be a list with no more than 30 actions.", "output": "", "screenshot": "", "scenarios": []}
    allowed_actions = {"click", "fill", "select", "press", "wait", "assert_text", "assert_visible", "assert_count"}
    for i, step in enumerate(steps):
        if not isinstance(step, dict) or step.get("action") not in allowed_actions:
            return {"status": "FAILED", "summary": f"Visual step {i + 1} uses an unsupported action.", "output": "", "screenshot": "", "scenarios": []}
        if step.get("action") != "wait" and (not isinstance(step.get("selector"), str) or not step["selector"] or len(step["selector"]) > 500):
            return {"status": "FAILED", "summary": f"Visual step {i + 1} needs a valid CSS selector.", "output": "", "screenshot": "", "scenarios": []}
        if step.get("action") == "wait" and (not isinstance(step.get("milliseconds", 100), int) or not 0 <= step.get("milliseconds", 100) <= 3000):
            return {"status": "FAILED", "summary": f"Visual step {i + 1} wait must be 0–3000 ms.", "output": "", "screenshot": "", "scenarios": []}

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"status": "SKIPPED", "summary": "Visual browser checks need the optional Playwright package and a local Chromium browser. Install the visual extra and browser explicitly; nothing was downloaded automatically.", "output": "", "screenshot": "", "scenarios": []}

    out_root = Path(output_dir) if output_dir else root / ".council" / "visual-runs"
    try:
        out_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {"status": "SKIPPED", "summary": f"Cannot create visual artifact folder: {exc}", "output": "", "screenshot": "", "scenarios": []}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    screenshot_path = out_root / f"visual-{stamp}.png"
    report_path = out_root / f"visual-{stamp}.json"

    import tempfile
    try:
        with tempfile.TemporaryDirectory(prefix="coding-council-visual-") as td:
            snapshot = Path(td) / "workspace"
            snapshot.mkdir()
            _copy_workspace(root, snapshot)
            path_error = _apply_proposals(snapshot, proposed_files)
            if path_error:
                return {"status": "FAILED", "summary": path_error, "output": "", "screenshot": "", "scenarios": []}
            entry_path = snapshot / entry_rel
            if not entry_path.is_file() or entry_path.is_symlink():
                # Convenience fallback for common entry-page names when no manifest was supplied.
                if not manifest and entry == "index.html":
                    alternative = next((snapshot / name for name in ("main.html", "app.html") if (snapshot / name).is_file()), None)
                    if alternative:
                        entry_path = alternative
                    else:
                        return {"status": "FAILED", "summary": f"Visual entry page not found: {entry}", "output": "", "screenshot": "", "scenarios": []}
                else:
                    return {"status": "FAILED", "summary": f"Visual entry page not found: {entry}", "output": "", "screenshot": "", "scenarios": []}

            handler = lambda *args, **kwargs: _QuietStaticHandler(*args, directory=str(snapshot), **kwargs)
            server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
            server.daemon_threads = True
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f"http://127.0.0.1:{server.server_address[1]}"
            relative_entry = entry_path.relative_to(snapshot).as_posix()
            console_errors: list[str] = []
            page_errors: list[str] = []
            blocked_requests: list[str] = []
            action_results: list[dict[str, Any]] = []
            browser = None
            try:
                with sync_playwright() as playwright:
                    executable = shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
                    launch_options: dict[str, Any] = {"headless": True, "timeout": timeout * 1000}
                    if executable:
                        launch_options["executable_path"] = executable
                    browser = playwright.chromium.launch(**launch_options)
                    context = browser.new_context(viewport={"width": width, "height": height}, service_workers="block")
                    page = context.new_page()
                    allowed_origin = f"http://127.0.0.1:{server.server_address[1]}"
                    def guard_route(route):
                        parsed = urllib.parse.urlparse(route.request.url)
                        if parsed.scheme in {"data", "blob", "about"}:
                            route.continue_()
                        elif parsed.scheme == "http" and parsed.netloc == f"127.0.0.1:{server.server_address[1]}":
                            route.continue_()
                        else:
                            blocked_requests.append(route.request.url[:500])
                            route.abort()
                    page.route("**/*", guard_route)
                    page.on("pageerror", lambda error: page_errors.append(str(error)[:1000]))
                    page.on("console", lambda message: console_errors.append(message.text[:1000]) if message.type == "error" else None)
                    response = page.goto(f"{base_url}/{urllib.parse.quote(relative_entry)}", wait_until="domcontentloaded", timeout=timeout * 1000)
                    if response is None or not response.ok:
                        raise RuntimeError(f"Entry page failed to load (HTTP {response.status if response else 'no response'}).")
                    page.wait_for_timeout(150)
                    for i, step in enumerate(steps):
                        action = step["action"]
                        selector = step.get("selector", "")
                        locator = page.locator(selector) if selector else None
                        try:
                            if action == "click":
                                locator.first.click(timeout=3000)
                            elif action == "fill":
                                locator.first.fill(str(step.get("value", ""))[:2000], timeout=3000)
                            elif action == "select":
                                locator.first.select_option(str(step.get("value", "")), timeout=3000)
                            elif action == "press":
                                locator.first.press(str(step.get("key", "Enter"))[:30], timeout=3000)
                            elif action == "wait":
                                page.wait_for_timeout(step.get("milliseconds", 100))
                            elif action == "assert_text":
                                expected = str(step.get("contains", ""))[:500]
                                actual = locator.first.inner_text(timeout=3000)
                                if expected not in actual:
                                    raise AssertionError(f"Expected text {expected!r} not found in {actual[:300]!r}")
                            elif action == "assert_visible":
                                if not locator.first.is_visible(timeout=3000):
                                    raise AssertionError(f"Element is not visible: {selector}")
                            elif action == "assert_count":
                                expected_count = step.get("count")
                                if not isinstance(expected_count, int) or expected_count < 0 or expected_count > 10000:
                                    raise ValueError("assert_count requires an integer count from 0 to 10000")
                                actual_count = locator.count()
                                if actual_count != expected_count:
                                    raise AssertionError(f"Expected {expected_count} matches for {selector}, got {actual_count}")
                            action_results.append({"step": i + 1, "action": action, "status": "PASSED"})
                        except Exception as exc:
                            action_results.append({"step": i + 1, "action": action, "status": "FAILED", "error": str(exc)[:1000]})
                            break
                    page.screenshot(path=str(screenshot_path), full_page=True, animations="disabled", timeout=timeout * 1000)
                    page_info = page.evaluate("""() => ({title: document.title, url: location.href, viewport: {width: innerWidth, height: innerHeight}, document: {width: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight}, bodyText: (document.body?.innerText || '').slice(0, 4000), visibleElements: document.querySelectorAll('body *').length})""")
                    context.close()
                    browser.close()
                    browser = None
            finally:
                if browser is not None:
                    try: browser.close()
                    except Exception: pass
                server.shutdown()
                server.server_close()

            failed_steps = [x for x in action_results if x["status"] == "FAILED"]
            failures = page_errors + console_errors + [x.get("error", "") for x in failed_steps]
            status = "FAILED" if failures else "PASSED"
            summary = f"Rendered {entry_path.relative_to(snapshot).as_posix()} at {width}×{height}; {len(action_results)}/{len(steps)} configured UI actions passed; {len(page_errors)} page exceptions and {len(console_errors)} console errors."
            report = {
                "status": status, "summary": summary, "entry": str(entry), "viewport": {"width": width, "height": height},
                "page": page_info, "console_errors": console_errors[:50], "page_errors": page_errors[:50],
                "blocked_external_requests": blocked_requests[:100], "actions": action_results,
                "screenshot": str(screenshot_path), "limitations": "Browser smoke/interaction checks are not proof of correctness or a hardened security sandbox. External network requests were blocked."
            }
            report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
            output = json.dumps(report, indent=2, ensure_ascii=False)[:16000]
            return {"status": status, "summary": summary, "output": output, "screenshot": str(screenshot_path), "report": str(report_path), "scenarios": action_results, "page": page_info}
    except Exception as exc:
        message = str(exc)
        unavailable = any(marker in message for marker in ("Executable doesn't exist", "browserType.launch", "ERR_BLOCKED_BY_ADMINISTRATOR", "BrowserType.launch"))
        status = "SKIPPED" if unavailable else "FAILED"
        summary = ("Visual browser runtime is unavailable or blocked by local browser policy; no screenshot was produced." if unavailable else f"Visual browser run failed: {message}")
        return {"status": status, "summary": summary, "output": message[:4000], "screenshot": "", "scenarios": []}
