"""Bounded, read-only workspace scanner."""
from __future__ import annotations
from pathlib import Path
from .safety import IGNORED_DIRS, TEXT_SUFFIXES, is_secret_path, is_within

PRIORITY_NAMES = ["readme", "pyproject", "package.json", "Cargo.toml", "go.mod", "requirements", "main", "app", "index"]


def _priority(path: Path) -> tuple[int, int, str]:
    name = path.name.lower()
    order = 0
    for i, term in enumerate(PRIORITY_NAMES):
        if term in name:
            order = i + 1
            break
    suffix_order = 0 if path.suffix.lower() in {".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go", ".java", ".cs", ".cpp", ".c"} else 1
    return (0 if order else 1, order or suffix_order, name)


def collect_workspace_context(workspace: Path, max_chars: int = 24000, max_files: int = 90, max_scan_files: int = 20000, max_scan_dirs: int = 8000) -> str:
    root = workspace.expanduser().resolve()
    if not root.exists() or not root.is_dir():
        return "[No valid workspace selected. The task may still be answered conceptually.]"
    candidates: list[Path] = []
    scanned_files = 0
    scanned_dirs = 0
    scan_truncated = False
    for base, dirs, files in __import__("os").walk(root, followlinks=False):
        scanned_dirs += 1
        if scanned_dirs > max_scan_dirs:
            scan_truncated = True
            break
        base_path = Path(base)
        dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS and d != ".council" and not (base_path / d).is_symlink())
        for name in sorted(files):
            scanned_files += 1
            if scanned_files > max_scan_files:
                scan_truncated = True
                dirs[:] = []
                break
            p = base_path / name
            if p.is_symlink() or not is_within(p, root):
                continue
            rel = p.relative_to(root).as_posix()
            if is_secret_path(rel):
                continue
            if p.suffix.lower() in TEXT_SUFFIXES or name.lower() in {"makefile", "dockerfile", ".gitignore", ".editorconfig"}:
                try:
                    if p.stat().st_size <= 160_000:
                        candidates.append(p)
                except OSError:
                    pass
    candidates.sort(key=_priority)
    chunks: list[str] = []
    used = 0
    for path in candidates[:max_files]:
        try:
            data = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = path.relative_to(root).as_posix()
        header = f"\n===== FILE: {rel} =====\n"
        allowance = max_chars - used - len(header)
        if allowance <= 0:
            break
        if len(data) > allowance:
            data = data[:allowance] + "\n...[truncated to fit context]..."
        block = header + data
        chunks.append(block)
        used += len(block)
        if used >= max_chars:
            break
    if not chunks:
        empty = "[Workspace contains no readable source/text files, or it is currently empty.]"
        return empty + ("\n[Workspace scan stopped at its configured safety limit; context may be incomplete.]" if scan_truncated else "")
    context = "\n".join(chunks)
    if scan_truncated:
        context += "\n\n[Workspace scan stopped at its configured safety limit; context may be incomplete.]"
    return context
