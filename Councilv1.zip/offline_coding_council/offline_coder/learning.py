"""Human-confirmed coding experiences for retrieval and optional local fine-tuning."""
from __future__ import annotations
from contextlib import contextmanager
import hashlib, json, re, sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .config import APP_DIR

DB_PATH = APP_DIR / "learning.sqlite3"
_SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    re.compile(r"(?i)(api[_-]?key|password|secret|token)\s*[:=]\s*[^\s,;]{8,}"),
]

class LearningStore:
    """Stores only examples explicitly confirmed by the user as successful."""
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS examples (
                id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT NOT NULL, answer TEXT NOT NULL,
                feedback TEXT NOT NULL DEFAULT '', digest TEXT NOT NULL UNIQUE,
                confirmed_at TEXT NOT NULL, source_run_id TEXT NOT NULL DEFAULT ''
            )""")

    @contextmanager
    def _connect(self):
        db=sqlite3.connect(self.db_path, timeout=5.0); db.row_factory=sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _contains_secret(text: str) -> bool:
        return any(p.search(text) for p in _SECRET_PATTERNS)

    def add_confirmed(self, task: str, answer: str, feedback: str = '', source_run_id: str = '') -> int:
        task=(task or '').strip(); answer=(answer or '').strip(); feedback=(feedback or '').strip()
        if not task or not answer: raise ValueError('A non-empty task and answer are required.')
        if len(task)>12000 or len(answer)>30000 or len(feedback)>2000: raise ValueError('Example exceeds size limits.')
        combined='\n'.join((task,answer,feedback))
        if self._contains_secret(combined): raise ValueError('Possible secret/token detected. Remove it before saving this example.')
        digest=hashlib.sha256(combined.encode('utf-8')).hexdigest()
        with self._connect() as db:
            cur=db.execute('INSERT OR IGNORE INTO examples(task,answer,feedback,digest,confirmed_at,source_run_id) VALUES(?,?,?,?,?,?)',
                (task,answer,feedback,digest,datetime.now(timezone.utc).isoformat(),source_run_id[:128]))
            if cur.rowcount==0: raise ValueError('This exact training example is already saved.')
            return int(cur.lastrowid)

    def list_examples(self) -> list[dict[str, Any]]:
        with self._connect() as db: return [dict(r) for r in db.execute('SELECT id,task,feedback,digest,confirmed_at,source_run_id FROM examples ORDER BY id DESC')]

    def relevant_examples(self, query: str, limit: int=2) -> list[dict[str,str]]:
        terms=set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_+-]{2,}",query.lower()))
        if not terms: return []
        with self._connect() as db: rows=db.execute('SELECT task,answer,feedback FROM examples').fetchall()
        ranked=[]
        for r in rows:
            hay=(r['task']+' '+r['answer']+' '+r['feedback']).lower()
            score=sum(min(3,hay.count(w)) for w in terms)
            if score: ranked.append((score,{'task':r['task'],'answer':r['answer'][:7000],'feedback':r['feedback']}))
        ranked.sort(key=lambda x:x[0],reverse=True)
        return [x for _,x in ranked[:max(0,min(5,limit))]]

    def export_jsonl(self, path: Path) -> int:
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
        with self._connect() as db: rows=db.execute('SELECT task,answer,feedback FROM examples ORDER BY id').fetchall()
        with path.open('w',encoding='utf-8',newline='\n') as f:
            for r in rows:
                user=r['task'] + ("\n\nUser-confirmed feedback: "+r['feedback'] if r['feedback'] else '')
                f.write(json.dumps({'messages':[{'role':'system','content':'You are a careful coding assistant. Follow the user request, explain uncertainty, and do not claim tests ran without evidence.'},{'role':'user','content':user},{'role':'assistant','content':r['answer']}]},ensure_ascii=False)+'\n')
        return len(rows)
