"""In-process local GGUF inference. No network calls or API server are used."""
from __future__ import annotations
from pathlib import Path


class LocalModelError(RuntimeError):
    pass


class LocalModel:
    def __init__(self, model_path: str, n_ctx: int = 8192, n_threads: int = 4,
                 n_gpu_layers: int = 0, max_tokens: int = 4096, temperature: float = 0.2):
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise LocalModelError(f"Model file not found: {path}\nChoose a local .gguf model file first.")
        if path.suffix.lower() != ".gguf":
            raise LocalModelError("This build expects a GGUF model file (.gguf).")
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise LocalModelError(
                "The local inference library is not installed. Install it with:\n"
                "  python -m pip install llama-cpp-python\n\n"
                "No API key or remote AI service is required."
            ) from exc
        self.max_tokens = int(max_tokens)
        self.temperature = float(temperature)
        try:
            self._llm = Llama(
                model_path=str(path),
                n_ctx=max(2048, int(n_ctx)),
                n_threads=max(1, int(n_threads)),
                n_gpu_layers=int(n_gpu_layers),
                verbose=False,
            )
        except Exception as exc:
            raise LocalModelError(
                f"Could not load the model. The file may be incompatible or too large for your RAM/VRAM.\n{exc}"
            ) from exc
        self.model_path = str(path)

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None) -> str:
        cap = max(64, int(max_tokens or self.max_tokens))
        temp = self.temperature if temperature is None else float(temperature)
        try:
            result = self._llm.create_chat_completion(
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                max_tokens=cap,
                temperature=temp,
                top_p=0.9,
                repeat_penalty=1.08,
            )
            content = result["choices"][0]["message"].get("content", "")
            if isinstance(content, str) and content.strip():
                return content.strip()
            raise LocalModelError("The local model returned an empty answer.")
        except LocalModelError:
            raise
        except Exception as exc:
            raise LocalModelError(f"Local model generation failed: {exc}") from exc


class LocalServerModel:
    """Verified OpenAI-compatible model served on this computer (loopback only).

    This adapter deliberately refuses non-loopback hosts so a configuration typo cannot
    silently turn the local-first app into a remote inference client.
    """
    def __init__(self, base_url: str = "http://127.0.0.1:8080/v1", model: str = "",
                 max_tokens: int = 4096, temperature: float = 0.2, timeout: int = 180):
        import json
        from urllib.parse import urlparse
        parsed = urlparse(str(base_url).strip().rstrip("/"))
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise LocalModelError("Local server mode only accepts loopback hosts: http://127.0.0.1, http://localhost, or http://[::1] endpoints. HTTPS and remote hosts are refused.")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise LocalModelError("The local server URL must not contain credentials, a query string, or a fragment.")
        self.base_url = str(base_url).strip().rstrip("/")
        self.max_tokens = int(max_tokens)
        self.temperature = float(temperature)
        self.timeout = max(5, min(int(timeout), 600))
        self.model = str(model or "").strip()
        try:
            payload = self._request("/models", method="GET")
        except Exception as exc:
            raise LocalModelError(f"Could not verify the local model server at {self.base_url}. Start a compatible local server and try again. Details: {exc}") from exc
        entries = payload.get("data", []) if isinstance(payload, dict) else []
        ids = [str(item.get("id", "")) for item in entries if isinstance(item, dict) and item.get("id")]
        if not ids:
            raise LocalModelError("The server responded, but /models did not list any usable model IDs. The backend could not be verified.")
        if self.model and self.model not in ids:
            raise LocalModelError(f"Configured model '{self.model}' was not listed by the local server. Available model IDs: {', '.join(ids[:10])}")
        self.model = self.model or ids[0]
        self.model_path = f"local-server:{self.base_url}/{self.model}"

    def _request(self, path: str, method: str = "POST", body: dict | None = None) -> dict:
        import json
        from urllib.request import Request, build_opener, HTTPRedirectHandler, ProxyHandler
        from urllib.error import HTTPError, URLError
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = Request(self.base_url + path, data=data, method=method,
                      headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            opener = build_opener(ProxyHandler({}), NoRedirect())
            with opener.open(req, timeout=self.timeout) as response:
                raw = response.read(8_000_000).decode("utf-8", errors="replace")
        except HTTPError as exc:
            detail = exc.read(4000).decode("utf-8", errors="replace")
            raise LocalModelError(f"Local model server returned HTTP {exc.code}: {detail}") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise LocalModelError(f"Local model server connection failed: {exc}") from exc
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise LocalModelError("Local model server returned invalid JSON.") from exc
        if not isinstance(result, dict):
            raise LocalModelError("Local model server returned an unexpected response shape.")
        return result

    def generate(self, system: str, user: str, max_tokens: int | None = None,
                 temperature: float | None = None) -> str:
        payload = self._request("/chat/completions", body={
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "max_tokens": max(64, int(max_tokens or self.max_tokens)),
            "temperature": self.temperature if temperature is None else float(temperature),
            "top_p": 0.9,
        })
        choices = payload.get("choices", [])
        content = choices[0].get("message", {}).get("content") if choices and isinstance(choices[0], dict) else None
        if not isinstance(content, str) or not content.strip():
            raise LocalModelError("The verified local server returned an empty or unsupported chat completion.")
        return content.strip()
