from __future__ import annotations
import argparse
from pathlib import Path
from .config import load_settings, save_settings
from .model_backend import LocalModel, LocalServerModel
from .council import CouncilRunner, apply_approved_result
from .knowledge import KnowledgeStore


def main():
    defaults = load_settings()
    parser = argparse.ArgumentParser(description="Offline four-peer coding council (no cloud API).")
    parser.add_argument("--model", default=defaults.get("model_path", ""), help="Path to a local .gguf model file (GGUF backend)")
    parser.add_argument("--backend", choices=["gguf", "local-server"], default=defaults.get("model_backend", "gguf"), help="Use an in-process GGUF model or a verified loopback OpenAI-compatible server")
    parser.add_argument("--endpoint", default=defaults.get("local_server_url", "http://127.0.0.1:8080/v1"), help="Loopback-only local server base URL ending in /v1")
    parser.add_argument("--served-model", default=defaults.get("local_server_model", ""), help="Optional exact model ID listed by the local server")
    parser.add_argument("--workspace", default=defaults.get("workspace_path", ""), help="Only folder the council may read/write")
    parser.add_argument("--task", required=True, help="What you want the council to do")
    parser.add_argument("--apply", action="store_true", help="Explicitly authorize applying a proposal if and only if all four peers unanimously approve")
    parser.add_argument("--ctx", type=int, default=int(defaults.get("n_ctx", 16384)))
    parser.add_argument("--threads", type=int, default=int(defaults.get("n_threads", 4)))
    parser.add_argument("--gpu-layers", type=int, default=int(defaults.get("n_gpu_layers", 0)))
    parser.add_argument("--tokens", type=int, default=int(defaults.get("max_tokens", 4096)))
    parser.add_argument("--revision-rounds", type=int, choices=[0, 1, 2], default=int(defaults.get("review_rounds", 1)))
    args = parser.parse_args()
    if args.backend == "gguf" and not args.model:
        parser.error("Choose a local .gguf model using --model PATH, or use --backend local-server with a local server.")
    if not args.workspace:
        parser.error("Choose a workspace using --workspace PATH.")
    workspace = Path(args.workspace).expanduser().resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    print("Loading and verifying local model backend. Optional autonomous web research uses the internet when enabled.")
    if args.backend == "local-server":
        model = LocalServerModel(args.endpoint, args.served_model, max_tokens=args.tokens)
    else:
        model = LocalModel(args.model, n_ctx=args.ctx, n_threads=args.threads, n_gpu_layers=args.gpu_layers, max_tokens=args.tokens)
    runner = CouncilRunner(model, workspace, allow_self_edit=bool(defaults.get("allow_self_edit", False)),
                           review_rounds=args.revision_rounds, knowledge=KnowledgeStore(),
                           logger=lambda msg: print("[COUNCIL] " + msg), max_tokens=args.tokens,
                           web_research_enabled=defaults.get("autonomous_web_research", True))
    result = runner.run_task(args.task)
    print("\n=== ANSWER ===\n" + (result.answer or result.summary))
    print("\n=== STATUS ===\n" + result.final_status)
    if result.proposed_files:
        print("\n=== PROPOSED FILES ===")
        for name in result.proposed_files:
            print(" - " + name)
    if result.safety_errors:
        print("\n=== SAFETY ERRORS ===\n- " + "\n- ".join(result.safety_errors))
    if result.safety_warnings:
        print("\n=== RISK WARNINGS ===\n- " + "\n- ".join(result.safety_warnings))
    print(f"\nAudit report: {result.report_path}")
    if args.apply:
        if result.can_apply:
            answer = input("All four peers approved. Type APPLY to authorize these exact file changes: ").strip()
            if answer == "APPLY":
                backup = apply_approved_result(result, allow_self_edit=bool(defaults.get("allow_self_edit", False)))
                print("Applied. Backups: " + backup)
            else:
                print("Not applied. User approval was not given.")
        else:
            print("Not applied: unanimous peer approval and host checks are required.")
    elif result.can_apply:
        print("The proposal is eligible, but not applied. Re-run with --apply for an explicit confirmation prompt, or use the desktop GUI.")


if __name__ == "__main__":
    main()
