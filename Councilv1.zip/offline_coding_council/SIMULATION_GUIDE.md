# Coding Council: test and simulation guide

The council now performs supported checks on the candidate snapshot before peer review. Python candidates are compiled and their discovered `unittest` suite is run. JavaScript/Node candidates receive syntax checks and discovered `node:test` suites. If a `council.simulations.json` file exists, configured Python/Node smoke scenarios run too. Failure output is treated as untrusted diagnostics and can be sent through the bounded repair loop.

## Example

Create `council.simulations.json` at the root of the project:

```json
{
  "scenarios": [
    {
      "name": "Application startup smoke test",
      "runtime": "python",
      "script": "main.py",
      "args": ["--help"],
      "expect_exit_code": 0,
      "expect_output_contains": "usage",
      "timeout_seconds": 10
    }
  ]
}
```

Use an entry point that is safe to run in a disposable environment. A scenario is a real process execution, not a mathematical prediction. Keep it bounded and deterministic, and avoid scripts that need credentials, network access, or external services.

## Real-browser visual simulation

For web projects, the desktop council can open a disposable project snapshot in headless Chromium, capture a screenshot, record JavaScript/page errors, block requests to non-local origins, and optionally run a short list of UI actions/assertions. This is a real browser render, not an image guessed by the model.

Install the optional runner explicitly:

```bash
pip install -e ".[visual]"
python -m playwright install chromium
```

The app will not install packages or browser binaries automatically. If a compatible local Chromium is already installed, the runner can use it.

Create `council.visual.json` at the project root:

```json
{
  "entry": "index.html",
  "viewport": { "width": 1280, "height": 800 },
  "steps": [
    { "action": "click", "selector": "#start" },
    { "action": "assert_visible", "selector": "#status" },
    { "action": "assert_text", "selector": "#status", "contains": "Running" },
    { "action": "fill", "selector": "#name", "value": "Test user" },
    { "action": "wait", "milliseconds": 250 }
  ]
}
```

Supported actions are `click`, `fill`, `select`, `press`, `wait`, `assert_text`, `assert_visible`, and `assert_count`. Each action uses a CSS selector except `wait`. A screenshot and JSON report are saved under `.council/visual-runs/`. You can also press **Visual simulate project…** in the desktop app to render the current workspace manually.

## Safety and limitations

- Python/Node simulations run in disposable Docker containers with networking disabled and resource limits. Browser simulation uses a temporary copy, a local static server, and blocks requests outside that local origin. These are defense-in-depth measures, not a formal security guarantee.
- The runner never downloads Docker images, packages, or browser binaries automatically. Third-party dependencies may be missing; the runner reports that rather than claiming success.
- Tests run against a disposable snapshot containing workspace source and proposed files. Visual screenshots/reports are saved separately under `.council/visual-runs/`; the real app files are not modified by the simulation itself.
- Browser interaction tests cover only the steps you configure. A screenshot and clean console are a smoke check, not proof of correct behavior. Mobile device, database/API integration, and Unity/Godot/Unreal tests need their own harnesses and runtimes.
- Passing tests do not prove a program is bug-free. Review output and exercise important real-world workflows before release.
