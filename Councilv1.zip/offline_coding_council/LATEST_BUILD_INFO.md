# Latest Coding Council Source Bundle

This archive is the clean source package prepared from the newest available iPhone Shared Workspace Edition in this conversation on 2026-10-13. It preserves the phone companion and desktop application, including the shared-workspace read-only file listing.

## Validation performed

- Python tests: 78 passed; 4 subtests passed.
- Universal browser app and browser logic checks passed.
- iPhone app JavaScript syntax check passed.
- Mobile companion JavaScript/auth/localhost-default checks passed.

Generated caches (`__pycache__`, `.pytest_cache`, compiled Python files) and temporary test artifacts were excluded.

This is the latest bundle available in this conversation, not a live pull from a GitHub repository. If the GitHub repository has newer commits, its latest code must be checked separately.
