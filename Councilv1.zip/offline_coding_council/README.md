# Offline Coding Council

A local-first coding assistant project built around **four equal AI peers**. It does not require a cloud AI account, API key, paid inference service, or an AI API server. The model can be loaded directly into this Python process via `llama-cpp-python` from a `.gguf` file, or connected to a separately started OpenAI-compatible local server bound to loopback. The server backend is verified against `/v1/models` and refuses non-loopback hosts.

## What it does

- **Peer A — Architect:** requirements, design, maintainability, edge cases.
- **Peer B — Correctness Auditor:** logic, contracts, dependencies, test strategy.
- **Peer C — Security & Reliability Auditor:** trust boundaries, privacy, security, failure modes.
- **Peer D — Independent Verifier:** adversarial review, alternate explanations, integration risks.
- All four independently analyze the same task, cross-examine each other's analyses, inspect one exact candidate, see all review reports, and cast a final vote.
- The candidate-drafter role rotates. It does **not** have extra voting power. A proposal is eligible to apply only if all four final votes say `APPROVE` and the host's safety/static checks pass.
- The AI never gets a direct write handle. You must inspect and explicitly approve Apply. Existing files are backed up first.
- Workspace reads/writes are restricted to one user-selected folder. The scanner excludes common dependency/build folders, symlinks, and likely credentials. It refuses path traversal, protected `.council` files, private-key patterns, unsupported binary files, Python syntax errors, and invalid JSON.
- Generated code is **not executed automatically**. The application does not run arbitrary shell commands, tests, downloads, or installs on the model's behalf.
- A local source notebook allows you to import documentation or code references. New sources are unverified and ignored until you inspect their origin/content and explicitly mark them verified. Matching excerpts are then supplied to the agents with title, provenance, and a content hash.
- Every run saves a JSON audit report and a separate candidate snapshot under the selected workspace's `.council/` folder.


## GitHub setup

- Start with a **private repository** while this project is experimental. The included `.gitignore` excludes model weights, common secret files, local databases, caches, and virtual environments. Check `git status` and inspect every file before pushing; ignore rules cannot remove a secret that was already committed.
- GitHub Actions CI runs the Python tests, bytecode compilation, and inline JavaScript/HTML checks for the universal browser app, iPhone app, and desktop phone companion on pushes and pull requests.
- The Pages workflow deploys the universal browser app at the site root and the iPhone-specific app under `/iphone-app/` on matching pushes to `main`. Enable **Settings → Pages → Build and deployment → Source: GitHub Actions**. Availability of Pages for a private repository depends on GitHub's current plan and repository settings; if unavailable, keep the source private and use a separate deployment repository containing only the public-safe iPhone app files, or another static HTTPS host.
- Require a human to review pull requests that change approval gates, workspace restrictions, source scanning, ZIP import, or preview sandboxing. AI review is not enough to approve safety-boundary changes.
- The browser edition still downloads its runtime, ZIP decoder (on ZIP import), and model weights from external hosts. GitHub Pages hosts the app files; it does not make inference cloud-based or fully offline.

## Honest limitations

This project is the **agent system and safety workflow**, not a magical new foundation model. Coding ability depends heavily on the local model you download and your computer's hardware. Four agents here are four different review roles prompting the same local model—not four separately trained frontier-scale brains. The outputs are not guaranteed to be correct; the review process lowers risk but cannot replace human review and real tests. See `models/RECOMMENDED_MODEL.md` for the recommended open-weight coding model and why training from scratch is not the right first step.

Unattended desktop writes now fail closed unless unanimous review and host safety checks pass **and** actual isolated runtime tests report `PASSED`. `SKIPPED`, `NO_TESTS`, and missing test reports block autonomous writes. Manual Apply still requires the user to review and confirm. A passing test suite is useful evidence, not proof of correctness.

“Learning from sources” means verified retrieval: the system stores documentation with provenance and includes relevant excerpts in later prompts. It does **not** retrain or alter the model's neural-network weights automatically. That keeps learning inspectable, reversible, and less likely to turn malicious or incorrect web content into hidden model behavior.

The app's safety-critical controller/policy files can be proposed for manual editing only; the automatic Apply path blocks these files even when self-editing is enabled. This prevents the agent from silently rewriting the rules that constrain its own authority. The source of this application is not a perfect security sandbox; use a dedicated workspace and back up important projects.


## Project Lab features

The desktop app includes a **Search web…** action that retrieves a small number of public DuckDuckGo search results and lets you append source URLs and snippets to the council task. The phone companion exposes the same search through the authenticated local host. The standalone browser app uses Wikipedia’s public search API (CORS-enabled) and can open a broader Google search in another tab; browser security prevents reliable automated ingestion from arbitrary search-engine pages. Search snippets are untrusted leads, not verified facts or instructions. The tool searches results only—it does not automatically crawl every result page. Verify important claims against primary/official sources.

The desktop app includes a bounded, read-only **Analyze whole project** report (file types, manifests, likely entry points, test paths, TODO markers, Git status, and heuristic security/accessibility/performance hints), an editable acceptance-checklist compiler, a local append-only task history, a backup restore workflow, and four starter templates (`website`, `browser-game`, `web-simulation`, `python-cli`). Starter templates only write into a new or empty destination and never execute code. Newly created backups include a manifest so rollback can restore overwritten files and remove files that were newly created by that change.

The universal browser app adds a **Project Lab** for a source-file inventory, draft acceptance checklist, and local task history export. Its generated website/game preview can be resized to phone (375 px), tablet (768 px), desktop (1280 px), or fit-screen widths. The browser history is stored in that browser's local storage and does not sync across devices. The inventory/checklist/security/accessibility hints use heuristics and are not a substitute for language-aware analysis or runtime testing.

## Complex task quality and autonomous research

For a better outcome, state the goal, constraints, what must not change, how success will be measured, and the expected deliverable. Use answer mode for conceptual/research questions and build mode for code changes. The council generates a structured task plan/acceptance contract, has four role prompts independently analyze the request, cross-examines their reasoning, and synthesizes answer-only tasks. When autonomous web research is enabled, desktop first searches public result snippets and can ask for up to two focused follow-up searches based on uncertainty; browser research is limited to Wikipedia snippets. Relevant primary/official documentation is preferred for versioned technical facts; Wikipedia is ranked above unclassified personal/community sources but is not treated as primary evidence.

The source tree, answers, model, and review process have limits: the four peers are all role prompts over one chosen model, not independent model families; snippets are not full-page verification; context limits can still truncate/overload large tasks; and no model-based consensus proves correctness. For hard work, choose a model that can handle the language/framework and fit your hardware, inspect the plan, and require actual tests in the target runtime. The current audit records what was and was not verified.

## Feature status and limits

- **Available now:** manual public web search plus autonomous pre-task research (desktop/phone/CLI use DuckDuckGo HTML snippets; browser edition automatically searches Wikipedia and can open a broader search tab); source ranking labels primary/official documentation above Wikipedia, and Wikipedia above unclassified community/personal sources; website ZIP/folder/limited direct URL digestion; four adversarial review roles; user-verified reference shelf and lessons; browser visual preview; manual viewport sizing; Python isolated checks when Docker and the exact image are already installed; project inventory; acceptance checklist; local task history; starter templates; backup rollback for new-format backups; static security/accessibility/performance hints.
- **Still needs separate implementation/validation:** genuinely independent models per peer; parallel multi-agent execution (the single local model is intentionally serialized); full Playwright browser test suite; game-engine-native testing for Unity/Godot/Unreal; automatic CVE database matching; microphone/voice workflow; cloud/device-to-device sync; continuous background health monitoring; generic plugin loading; safe multi-branch competing-solution orchestration; visual element-to-source debugging; one-click production deployment. These are not implied by the current buttons or audit results.
- **No magic self-training:** verified lessons and task history improve retrieval/context, not the model weights. Training remains an explicit separate process.
- **No fabricated test claims:** browser viewport presets are manual visual checks. The browser edition still does not execute generated code as a real unit/browser test suite.

## Requirements

- Python 3.10+ recommended.
- A local GGUF instruction/code model.
- Enough RAM/VRAM for that model and context window.
- `llama-cpp-python` (the model inference runtime). This is a local software dependency, **not an external API**.

## Setup

1. Install Python 3.10 or newer.
2. Create a virtual environment in this folder:

   **Windows PowerShell**
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

3. Download a compatible `.gguf` model from a model publisher you trust. Check the model license and hardware requirements. For example, the `ggml-org` Qwen GGUF collection publishes models intended for `llama.cpp`; see links below. Smaller quantizations typically need less memory but may be less capable.
4. Start the app:

   - Windows: double-click `run_windows.bat`.
   - macOS/Linux: `./run_macos_linux.sh`.
   - Or run `python main.py`.
5. Choose the `.gguf` file and a project workspace. Start with a separate test folder rather than an important project.
6. Describe a task in the box and run the council. Read the final answer, code, peer reviews, votes, and audit tab.
7. Only if all four peers unanimously approve will Apply become available. Inspect the files, then click Apply and confirm. Backups are written to `<workspace>/.council/backups/`.

For optional PDF knowledge import, install `python -m pip install pypdf`. PDFs must contain extractable text; no OCR is performed.

## Local model backends

- **GGUF mode (default):** loads a `.gguf` file through `llama-cpp-python`.
- **Local server mode:** use an OpenAI-compatible server running on this same computer, such as a compatible `llama.cpp` server. In the desktop app select `local-server`, set the base URL (default `http://127.0.0.1:8080/v1`), and optionally specify a model ID. The app checks `/v1/models` before using it. Only `localhost`, `127.0.0.1`, and `::1` over plain HTTP are accepted; remote endpoints and embedded credentials are refused. Start and configure the server yourself; the app does not download a model or launch a server automatically. Model compatibility still depends on the server/runtime version.

## Verification and repair loop

When a proposed Python or JavaScript file changes, the council can run supported checks inside a disposable Docker container **only if the required image is already installed locally**. Python checks compile the snapshot and run discovered `unittest` tests. Node checks run syntax validation and discovered built-in `node:test` suites. Containers have no network, bounded CPU/memory/processes, and no automatic image/dependency download. Failed checks are fed back into the configured revision loop; a later revision must go through validation and all peer reviews again. Missing Docker/images, missing tests, unsupported languages, browser behavior, frameworks needing absent dependencies, and engine-specific projects are reported as unverified rather than passed. This is not a formal sandbox or proof of correctness.

## Suggested model sizes

- **Lower-memory computer:** a 1.5B–3B coder model may run, but quality is limited.
- **Everyday development machine:** a 7B–14B coder/instruct model in a modest quantization is a reasonable starting point; RAM needs vary by quantization and context.
- **High-memory workstation:** larger 20B–30B+ models may reason and code better, but need substantially more memory and can be much slower.

These are broad starting points, not hardware guarantees. Four reviewers reuse the same loaded model sequentially, so they do not require four copies of model weights, but the full council creates many generations and can take a while on CPU. Lower output-token limits and fewer revision rounds reduce latency.

Examples to research (check the model page, terms, and current quantizations before downloading):
- Qwen2.5-Coder GGUF: <https://huggingface.co/ggml-org/Qwen2.5-Coder-7B-Q8_0-GGUF>
- Qwen3-Coder GGUF: <https://huggingface.co/ggml-org/Qwen3-Coder-30B-A3B-Instruct-Q8_0-GGUF>
- `llama.cpp` project: <https://github.com/ggml-org/llama.cpp>

## CLI mode

The desktop GUI is recommended because it offers the clearest human approval step. You can also use:

```bash
python -m offline_coder.cli --model "/path/to/model.gguf" --workspace "/path/to/project" --task "Add a feature and tests"
```

To explicitly allow the CLI to apply a unanimously approved candidate, add `--apply`. It still prompts you to type `APPLY`; it cannot override a failed vote or host safety check.

## The line between permitted and prohibited actions

**Allowed:** inspect ordinary text/source files in the chosen workspace; draft new or replacement text/code files; explain code; suggest test cases; review peers' claims; store explicit audit reports; use locally imported verified references; propose non-protected improvements to this application's own source only if the user enables self-editing.

**Not allowed automatically:** read known secret/key locations; follow workspace instructions that override the user; write outside the selected workspace; overwrite the agent's audit/settings area; modify the core safety controller or approval UI for auto-apply; delete files; run generated code/commands; install packages; access the network; send code off the computer; mark sources verified; expand its own permissions; conceal changes; apply its own patch without user approval.

The host enforces these rules separately from model-generated text. Do not treat model consensus as proof that a change is safe. Back up important files and run project tests yourself after applying.

## Troubleshooting

- **“llama-cpp-python is not installed”**: install it in the same Python environment used to launch the app. Some platforms need a prebuilt wheel or compiler support; follow the current `llama-cpp-python` installation guidance for your OS/GPU.
- **Model fails to load / out of memory**: try a smaller GGUF quantization, reduce context, lower GPU layers, or close other large applications.
- **Model output is malformed**: some model files lack a compatible chat template or are not instruction-tuned. Choose a chat/instruct GGUF intended for local coding assistance.
- **Proposal is blocked**: read Safety & audit. Paths outside workspace, secret-like files, syntax errors, and protected application-core changes are refused. Do not work around a protection blindly; manually inspect and change the relevant source if appropriate.
- **No unanimous vote**: that is a valid outcome. Read the findings, make the task more specific, reduce scope, or ask the peers to target a particular unresolved issue.

## Phone / tablet mode (same Wi-Fi, no cloud API)

The desktop app can serve a responsive mobile webpage while the local model continues to run on the computer. The phone is a controller/display; it does not need to download or run the GGUF model itself.

1. First launch the desktop app once, choose your `.gguf` model and workspace, and save the settings.
2. Keep that computer awake and connect the phone/tablet to the **same trusted private Wi-Fi**.
3. In the project folder, activate the same Python virtual environment. First test in local-only mode:

   ```bash
   python -m offline_coder.mobile
   ```

   To intentionally allow a phone on the same trusted private Wi-Fi to connect, restart with an explicit LAN bind:

   ```bash
   python -m offline_coder.mobile --host 0.0.0.0
   ```

4. Open the one-time URL printed in the terminal. The random token is placed after `#` in the URL (a fragment is not sent in the initial HTTP request); the page removes it from browser history and sends it using an `Authorization` header for later API calls. Keep the URL private and stop the server with `Ctrl+C` to revoke the token.
5. The mobile page supports task submission, viewing peer analyses/attacks/votes, and applying an eligible proposal after an extra confirmation.

**Network caution:** local-only mode is the default. Explicit LAN mode still uses unencrypted HTTP; bearer headers are readable to a network observer on an untrusted network. Only use a trusted private network, never public Wi-Fi, and do not port-forward the service to the internet. For sensitive repositories, prefer desktop-only mode until HTTPS or a VPN-secured path is configured. The mobile page is not an independent offline app: the host computer must be running. Inference remains local on the host.

## Stronger adversarial reviews

All four peer lenses now explicitly try to falsify the candidate, look for concrete failure paths, devise boundary inputs and regression tests, and distinguish confirmed code defects from plausible risks. Reviewers see the same exact candidate and then see each other's findings before voting. They are still role prompts using the same selected local model, not four independently trained models; model consensus is not proof of correctness.

## iPhone-only edition (no computer or AI API)

A browser-first app is included in [`iphone-app/`](iphone-app/). It runs inference inside Safari using Transformers.js; after you publish the static page over HTTPS, the iPhone can run it without a computer, API key, paid AI service, or cloud inference endpoint. Initial internet access is still needed to fetch the JavaScript runtime and model weights. Available model sizes are 0.5B (best compatibility), 1.5B (larger), and 3B (experimental on phone hardware); none should be presented as equivalent to a frontier-scale cloud assistant.

The mobile edition accepts plain-English requests and can scaffold websites, browser games, simulations/visualizers, mobile-app source, APIs/backends, libraries, and bug fixes. Choose prototype, polished MVP, or thorough project depth. It first creates a file manifest and then generates files one-by-one to reduce single-response truncation. It performs four independent adversarial review passes, checks a subset of HTML/JSON/CSS/project-path issues locally, repairs selected files when credible issues are found, and requires evidence-based final votes. Projects can be downloaded as a ZIP preserving folders, along with an audit report and run notes. Browser projects can be opened in a restricted iframe preview. A local reference shelf saves excerpts you mark as reviewed and includes them in future prompts; it does not automatically verify sources or retrain model weights.

For setup and honest limitations, see [`iphone-app/README.md`](iphone-app/README.md).


## Additional iPhone-only capabilities (deep-audit update)

- Upload individual source files or a ZIP project for audit. ZIP import has entry-count, compressed-size, per-file and total-context limits; unsafe paths, dependency folders, sensitive filenames and binary files are skipped. The ZIP decompressor is loaded from a CDN only when a ZIP is selected, so that operation needs internet access even though AI inference remains local.
- Define up to three extra specialist auditor roles per run. They are additional prompted reviewers using the same model, not separately trained AI models; they join the peer review and final vote.
- Save manually verified engineering lessons in local browser storage. These lessons are retrieved as future task context. Export is a starter JSONL dataset, not automatic model-weight training; genuine fine-tuning needs curated examples and a separate training environment.
- The download helper is explicitly defined for proposal, audit, and lesson exports.


## User-confirmed self-improvement and optional local fine-tuning

The council now has two deliberately separate learning layers:

1. **Retrieval-based learning (normal operation):** after you independently test a successful result, choose **Learn from a successful run**. The task, generated answer/files, and your optional feedback are saved locally in `~/.offline_coding_council/learning.sqlite3`. Relevant examples can be retrieved in future prompts. The app does not promote unverified or failed runs automatically. Examples are still untrusted reference material and can become stale.
2. **Actual model-weight fine-tuning (optional):** export confirmed examples to JSONL and run `tools/train_lora.py` against a local Hugging Face model directory. This produces a LoRA adapter; it does not overwrite the source model. The current GGUF inference model cannot be fine-tuned directly by this script. Training needs a separate compatible Hugging Face base-model directory, optional dependencies in `requirements-training.txt`, sufficient RAM/VRAM, and at least 20 usable reviewed examples. More diverse examples are strongly recommended; small datasets can worsen results.

Example command (after installing the optional dependencies and obtaining a compatible local Hugging Face model):

```bash
python tools/train_lora.py --model "/path/to/local-hf-model" --dataset "/path/to/council-training.jsonl" --output "/path/to/new-lora-output" --epochs 1
```

The script uses a held-out validation split and trains the assistant answer tokens, not the user prompt tokens. It does not download a model automatically (`local_files_only=True`). It is an experimental starter trainer, not a production training pipeline. Evaluate the adapter on separate held-out tasks and keep backups. The iPhone browser edition can collect and export user-confirmed examples, but **cannot train the model weights on the iPhone**; fine-tuning must run on compatible desktop/workstation hardware.

## Correctness and verification

The council uses a host-enforced approval gate in addition to peer votes: every known peer must submit a structured review and final vote, and any material `BLOCKER`, `HIGH`, or `MEDIUM` review finding prevents approval. The gate is checked again immediately before applying a proposal. This is deliberately conservative. Unanimity is not proof of correctness; arbitrary generated code is not automatically executed, and project-specific tests must still be run in a suitably isolated environment. See `AUDIT.md` for prioritized reliability improvements.


## Universal phone + computer HTML (not GitHub-only)

`CodingCouncil_Universal.html` is a single responsive HTML file intended for modern phone and desktop browsers. It has no relative asset dependencies. It uses an HTTPS-hosted browser runtime and model weights for first-time setup; AI inference stays in the browser, without an AI API endpoint. Some browsers restrict module imports or storage for `file://` pages, so the most reliable option is to serve the file from any HTTPS static host. GitHub Pages is optional; Netlify, Cloudflare Pages, or another static HTTPS host can be used instead. Browser localStorage is device/browser-specific and does not automatically sync between phone and computer.

The universal browser edition supports individual text-based documents, a website source folder, a website ZIP, and a public HTTPS website URL. URL crawling is limited and browser-tested using a mocked site; live-site CORS, redirects, and browser policy vary. URL import attempts a same-origin crawl of up to 25 HTML pages/resources (including linked same-origin scripts/stylesheets) with per-resource and total-character limits. It uses direct browser fetches only—no proxy—and therefore works only when the target site permits CORS reads and does not redirect; many production sites block this. If URL import fails, download the site source as a ZIP and import that instead. The URL importer rejects obvious localhost/private/IP-literal hosts, uses no credentials, does not follow redirects, and never crawls cross-origin links; these controls are defense-in-depth, not a security certification. Bundle ingestion is bounded to 300 supported text files, 250,000 total extracted characters, 1 MB per file, 10 MB compressed ZIP, and 20 MB expanded ZIP. It performs multi-pass local-model analysis, strips script/style blocks from HTML before text extraction, and skips dependency/build folders, binary files, and secret-like paths. It creates an architecture digest and partial source inventory; it does not retain the full source tree as a live editable workspace. To edit a specific site, also load relevant source files into project input. iPhone browsers often cannot select a whole folder, so use a ZIP there. PDF/OCR is not included in the browser edition. The digest does not automatically become trusted and does not change model weights.

Autonomous web research is enabled by default in desktop/CLI/phone-host runs and by a checked toggle in the universal browser app. Before peer analysis, the host makes a short sanitized query from relevant tasks, retrieves at most six snippets, labels source domains, and attaches the results to the council context. Tasks that look trivial or explicitly request no web are skipped; a search failure does not stop the coding task. This sends the short query to an external search provider (DuckDuckGo for desktop/CLI/phone host; Wikipedia API for browser edition), so disable the toggle for private tasks. The provider returns snippets rather than verified full-page contents. Source ranking is a heuristic: relevant official/primary documentation is preferred for exact APIs and current implementation behavior; Wikipedia is treated as a useful established secondary source and ranks above unclassified/personal/community claims, but it is not guaranteed true or current.

The browser edition has an **Autonomous repair** toggle. When enabled, it allows an extra bounded in-memory repair pass without pausing for permission between edits; it does not write directly to local files. Export the reviewed project ZIP to use those edits. In the desktop app, **Autonomous edits: ON/OFF** is a separate explicit opt-in: when ON, future proposals are applied without a per-run confirmation only if all four peers approve, host safety checks pass, and the proposal is confined to the chosen workspace. Existing files are backed up and generated code is never run automatically. Keep it OFF if you want to approve each write.

## Automatic Python smoke checks (desktop edition)

When a proposed patch includes Python files, the desktop council now checks whether Docker and the local `python:3.12-slim` image are available. If available, it copies the workspace plus candidate patch into a disposable container with network disabled, a read-only container root, dropped Linux capabilities, a non-root user, memory/CPU/process limits, and a timeout. It runs Python compilation and `unittest` discovery. A failing run blocks approval and feeds the failure back into revision. If Docker/image is absent, the result is explicitly **SKIPPED** and is not treated as a pass. This is a useful containment layer, not a formal sandbox certification; inspect test code and dependencies. The browser edition does static checks and a restricted preview, not arbitrary code execution or unit-test execution.

See [`START_HERE.md`](START_HERE.md) for routes that do not require GitHub.


## Web search and source handling

- Desktop: `Search web…` queries the public DuckDuckGo HTML search page without an API key. Results are capped, time-limited, source-linked snippets. Search can fail if the provider changes markup, blocks requests, or the device is offline.
- Phone companion: authenticated `/search` requests are executed by the desktop host and use the same bounded search function. The companion host needs internet access.
- Universal browser app: manually searches Wikipedia through its public CORS-enabled API, automatically searches Wikipedia before relevant tasks when the toggle is enabled, and can open a broader search in a new tab. It does not proxy arbitrary web search engines. Desktop/CLI/phone-host autonomous research uses the fixed DuckDuckGo public HTML endpoint and does not fetch arbitrary result URLs.
- Search results are untrusted data. They are not executed and should never override project instructions or safety policy. Snippets may be incomplete or stale; the council should prefer official documentation, cite URLs, and state when claims were not independently verified.

## Real-browser visual simulation (desktop)

The desktop app has a **Visual simulate project…** action and can also automatically run a headless Chromium smoke test when a proposed change affects a web project. It captures a real screenshot, records browser JavaScript/page exceptions, blocks non-local browser requests, and can run configured click/fill/select/press/wait/assert steps. Install the optional browser runner with `pip install -e ".[visual]"` and `python -m playwright install chromium`; no package or browser is installed automatically. Configure `council.visual.json` in the workspace to define the entry HTML file, viewport, and deterministic interaction assertions. The screenshot and JSON report are stored under `.council/visual-runs/`. This is a real browser run, but only tests the paths you configure; it is not a universal visual/game engine emulator. See `SIMULATION_GUIDE.md` for a full example.

## Isolated project simulations (Python / Node)

In addition to discovered unit tests, the council can run explicitly configured smoke or end-to-end scenarios inside disposable Docker containers with networking disabled. Add a `council.simulations.json` file at the root of the selected workspace:

```json
{
  "scenarios": [
    {
      "name": "CLI help output",
      "runtime": "python",
      "script": "main.py",
      "args": ["--help"],
      "expect_exit_code": 0,
      "expect_output_contains": "usage",
      "timeout_seconds": 10
    },
    {
      "name": "Node smoke scenario",
      "runtime": "node",
      "script": "scripts/smoke.mjs",
      "args": [],
      "expect_exit_code": 0,
      "expect_output_contains": "SIMULATION_OK",
      "timeout_seconds": 10
    }
  ]
}
```

Supported runtimes are `python` (`.py`) and `node` (`.js`, `.mjs`, `.cjs`). Scripts and arguments are passed as an argument vector, never through a shell. The manifest is capped at 10 scenarios; each timeout is 1–30 seconds. Each scenario runs with no network, a read-only container root, limited memory/CPU/processes, and only the disposable workspace snapshot mounted. The runner uses `python:3.12-slim` or `node:22-alpine` **only when that image is already installed locally**; it never pulls images or installs project dependencies. Therefore scenarios requiring third-party dependencies will fail or be skipped unless those dependencies are available in the chosen runtime image/workspace. Existing `node_modules` and other ignored folders are deliberately excluded from snapshots.

These are command-line smoke/integration simulations, not a universal browser or game-engine emulator. Browser UI end-to-end tests need a browser automation runtime (for example, Playwright) and must be explicitly configured and available; Unity/Unreal/game simulations need their own installed engine and project-specific runner. A missing simulation or test suite is not proof that behavior works. Failed simulations are fed into the bounded repair loop; skipped/no-test results are reported and do not qualify as successful runtime verification for unattended application.


## Shared mobile workspace

The phone companion lists files and folders from the configured workspace. On the same host computer, it accesses the same directory configured in the desktop app; this is not cloud sync and does not sync browser-only data from the Universal HTML app. The host computer and mobile server must remain running, and remote access should be limited to a trusted private Wi-Fi network.
