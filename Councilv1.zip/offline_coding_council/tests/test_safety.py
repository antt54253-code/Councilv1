import json
import tempfile
import unittest
from pathlib import Path

from offline_coder.safety import validate_proposed_files, apply_files, sha256_text
from offline_coder.council import _json_object


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_accepts_safe_python_and_json(self):
        files = {"src/hello.py": "def hello():\n    return 'hello'\n", "settings.json": json.dumps({"enabled": True})}
        result = validate_proposed_files(self.root, files)
        self.assertTrue(result.ok, result.errors)
        self.assertEqual(set(result.hashes_before), set(files))

    def test_blocks_path_traversal(self):
        result = validate_proposed_files(self.root, {"../outside.py": "print('no')"})
        self.assertFalse(result.ok)
        self.assertTrue(any("unsafe path" in e.lower() for e in result.errors))

    def test_blocks_noncanonical_path_aliases(self):
        for name in (r"src\nested.py", "src//nested.py", "./nested.py", " nested.py"):
            with self.subTest(name=name):
                result = validate_proposed_files(self.root, {name: "value = 1\n"})
                self.assertFalse(result.ok, f"non-canonical path should be rejected: {name!r}")
                self.assertTrue(any("non-canonical path" in e.lower() for e in result.errors))

    def test_path_validation_writer_targets_are_identical(self):
        result = validate_proposed_files(self.root, {"src/nested.py": "value = 1\n"})
        self.assertTrue(result.ok, result.errors)
        self.assertIn("src/nested.py", result.hashes_before)

    def test_blocks_env_files_and_private_key_material(self):
        env = validate_proposed_files(self.root, {".env": "TOKEN=not-real"})
        self.assertFalse(env.ok)
        env_child = validate_proposed_files(self.root, {".env/generated.py": "TOKEN = 'placeholder'"})
        self.assertFalse(env_child.ok, "secret-like .env directories must not be writable either")
        key = validate_proposed_files(self.root, {"keys.txt": "-----BEGIN PRIVATE KEY-----\nsecret\n-----END PRIVATE KEY-----"})
        self.assertFalse(key.ok)

    def test_blocks_invalid_python_and_json(self):
        py = validate_proposed_files(self.root, {"bad.py": "def broken(:\n    pass"})
        js = validate_proposed_files(self.root, {"bad.json": "{broken"})
        self.assertFalse(py.ok)
        self.assertFalse(js.ok)

    def test_apply_checks_stale_hashes_and_backs_up(self):
        path = self.root / "hello.py"
        path.write_text("old = True\n", encoding="utf-8")
        expected = {"hello.py": sha256_text("old = True\n")}
        backup = apply_files(self.root, {"hello.py": "new = True\n"}, expected)
        self.assertEqual(path.read_text(encoding="utf-8"), "new = True\n")
        self.assertEqual((backup / "hello.py").read_text(encoding="utf-8"), "old = True\n")
        stale = {"hello.py": sha256_text("some other content")}
        with self.assertRaises(ValueError):
            apply_files(self.root, {"hello.py": "another = True\n"}, stale)

    def test_json_parser_accepts_fenced_and_embedded_json(self):
        self.assertEqual(_json_object('```json\n{"vote":"APPROVE"}\n```'), {"vote": "APPROVE"})
        self.assertEqual(_json_object('Here: {"files": {"x.py": "print(1)"}} end'), {"files": {"x.py": "print(1)"}})
        self.assertIsNone(_json_object("not json"))


if __name__ == "__main__":
    unittest.main()
