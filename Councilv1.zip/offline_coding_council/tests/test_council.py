import json
import tempfile
import unittest
from pathlib import Path

from offline_coder.council import CouncilRunner, apply_approved_result


class StubModel:
    """Deterministic fake used to test the orchestration without an AI model or network."""
    def generate(self, system, user, max_tokens=None, temperature=None):
        if "Work independently before being shown" in user:
            return "Requirements: implement a tiny function. Use one file and test syntax."
        if "Return ONLY a JSON object with this schema" in user:
            return json.dumps({
                "summary": "Add a hello function.",
                "user_facing_answer": "I propose adding a small Python hello function.",
                "notes": ["No code has been executed."],
                "files": {"hello.py": "def hello():\n    return 'hello'\n"},
            })
        if "ALL FOUR INDEPENDENT ANALYSES" in user:
            return "Peer critique: the approach is consistent; ensure valid syntax."
        if '"findings"' in user and "CANDIDATE SUMMARY" in user:
            return json.dumps({"vote": "APPROVE", "findings": [], "strengths": ["Small and clear."], "confidence": 0.9})
        if "ALL FOUR REVIEW REPORTS" in user:
            return json.dumps({"vote": "APPROVE", "remaining_blockers": [], "reason": "Reviewed the other peer reports; no blockers remain."})
        return "Generic peer note."


class CouncilTests(unittest.TestCase):
    def test_autonomous_apply_requires_actual_runtime_test_pass(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        base = dict(run_id="x", task="t", workspace=".", can_apply=True, proposed_files={"a.py": "pass"})
        result = RunResult(**base, test_report={"status": "SKIPPED", "summary": "Docker unavailable"})
        self.assertFalse(can_autonomously_apply(result))
        result.test_report = {"status": "NO_TESTS", "summary": "No tests discovered"}
        self.assertFalse(can_autonomously_apply(result))
        result.test_report = {"status": "PASSED", "summary": "Tests passed", "output": "UNITTEST_DISCOVERY: tests found"}
        self.assertTrue(can_autonomously_apply(result))

    def test_autonomous_apply_rejects_empty_candidate(self):
        from offline_coder.council import RunResult, can_autonomously_apply
        result = RunResult(run_id="x", task="t", workspace=".", can_apply=True, proposed_files={}, test_report={"status": "PASSED", "output": "UNITTEST_DISCOVERY: tests found"})
        self.assertFalse(can_autonomously_apply(result))
    def test_answer_only_task_gets_final_synthesis_not_only_proposer_draft(self):
        class AnswerOnlyModel(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Write the final answer to the user." in user:
                    return "Final synthesized answer: compare the evidence, state limits, and give the direct conclusion."
                if "Return ONLY a JSON object with this schema" in user:
                    return json.dumps({"summary": "Initial answer draft", "user_facing_answer": "First-draft answer", "notes": [], "files": {}})
                return super().generate(system, user, max_tokens, temperature)

        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(AnswerOnlyModel(), Path(temp), review_rounds=0, web_research_enabled=False, logger=lambda _: None).run_task("Explain why testing matters for complex software systems.")
        self.assertEqual(result.answer, "Final synthesized answer: compare the evidence, state limits, and give the direct conclusion.")
        self.assertEqual(result.final_status, "Advice completed — no file changes proposed.")
        self.assertIn("acceptance_criteria", result.task_plan)

    def test_followup_research_uses_gaps_and_records_research_trace(self):
        from unittest.mock import patch
        class ResearchPlannerModel(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "Decide whether targeted follow-up web searches" in user:
                    return json.dumps({"queries": ["React official documentation current API", "React official migration guide"]})
                return super().generate(system, user, max_tokens, temperature)

        initial = [{"title":"Initial page", "url":"https://react.dev/learn", "host":"react.dev", "snippet":"Initial result", "credibility_tier":1, "credibility_label":"Primary/official documentation", "credibility_reason":"Official"}]
        follow = [{"title":"Migration guide", "url":"https://react.dev/blog", "host":"react.dev", "snippet":"Follow-up result", "credibility_tier":1, "credibility_label":"Primary/official documentation", "credibility_reason":"Official"}]
        with tempfile.TemporaryDirectory() as temp, patch("offline_coder.council.search_web", side_effect=[initial, follow, follow]) as search:
            result = CouncilRunner(ResearchPlannerModel(), Path(temp), review_rounds=0, logger=lambda _: None, web_research_enabled=True).run_task("Build a website with the latest React APIs and verify version-specific behavior.")
        self.assertEqual(search.call_count, 3)  # one initial query plus two bounded targeted searches
        self.assertIn("queries", result.web_research)
        self.assertTrue(any(item.get("stage") == "follow_up" for item in result.web_research.get("iterations", [])))
        self.assertTrue(any(item.get("url") == "https://react.dev/blog" for item in result.web_research.get("sources", [])))

    def test_research_context_is_not_dropped_when_workspace_context_is_large(self):
        with tempfile.TemporaryDirectory() as temp:
            runner = CouncilRunner(StubModel(), Path(temp), max_context_chars=6000, web_research_enabled=False)
            context = runner._compose_context("WORKSPACE_CONTEXT\n" + ("x" * 20000), "IMPORTANT_WEB_SOURCE https://docs.python.org/3/", "")
        self.assertIn("IMPORTANT_WEB_SOURCE", context)
        self.assertLessEqual(len(context), 6200)

    def test_four_peers_must_unanimously_vote_before_user_can_apply(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply, result.final_status)
            self.assertEqual(len(result.votes), 4)
            self.assertTrue(all(v["vote"] == "APPROVE" for v in result.votes))
            self.assertFalse((root / "hello.py").exists(), "council must not write files before explicit apply")
            backup = apply_approved_result(result)
            self.assertTrue((root / "hello.py").exists())
            self.assertIn("hello", (root / "hello.py").read_text(encoding="utf-8"))
            self.assertTrue(Path(backup).exists())

    def test_autonomous_web_research_is_attached_before_peer_analysis(self):
        from unittest.mock import patch
        class CapturingStub(StubModel):
            prompts = []
            def generate(self, system, user, max_tokens=None, temperature=None):
                self.prompts.append(user)
                return super().generate(system, user, max_tokens, temperature)
        model = CapturingStub()
        sources = [{"title":"React official docs", "url":"https://react.dev/learn", "host":"react.dev", "snippet":"Official React docs", "credibility_tier":1, "credibility_label":"Primary/official documentation", "credibility_reason":"Official docs"}]
        with tempfile.TemporaryDirectory() as temp, patch("offline_coder.council.search_web", return_value=sources) as search:
            result = CouncilRunner(model, Path(temp), review_rounds=0, logger=lambda _: None, web_research_enabled=True).run_task("Build a website using the latest React APIs and document setup.")
        search.assert_called_once()
        self.assertEqual(result.web_research["status"], "completed")
        self.assertTrue(any("AUTONOMOUS WEB RESEARCH" in prompt and "https://react.dev/learn" in prompt for prompt in model.prompts))

    def test_autonomous_web_research_failure_does_not_abort_task(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp, patch("offline_coder.council.search_web", side_effect=RuntimeError("provider unavailable")):
            result = CouncilRunner(StubModel(), Path(temp), review_rounds=0, logger=lambda _: None, web_research_enabled=True).run_task("Build a website using the latest React APIs and document setup.")
        self.assertEqual(result.web_research["status"], "failed")
        self.assertIn("provider unavailable", result.web_research["error"])
        self.assertTrue(result.final_status)

    def test_non_unanimous_vote_cannot_apply(self):
        class DissentingStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user and "Peer D" in user:
                    return json.dumps({"vote": "REJECT", "remaining_blockers": ["test blocker"], "reason": "Need more evidence."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(DissentingStub(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertFalse(result.can_apply)
            self.assertFalse((Path(temp) / "hello.py").exists())

    def test_approve_vote_with_remaining_blocker_cannot_apply(self):
        class BlockerStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user:
                    return json.dumps({"vote": "APPROVE", "remaining_blockers": ["Still needs a test"], "reason": "Concern remains."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(BlockerStub(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertFalse(result.can_apply, "an APPROVE label must not override remaining blockers")
            self.assertFalse((root / "hello.py").exists())
            with self.assertRaises(ValueError):
                apply_approved_result(result)


    def test_high_severity_review_finding_blocks_even_if_all_final_votes_approve(self):
        class FindingStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if '"findings"' in user and "CANDIDATE SUMMARY" in user:
                    return json.dumps({
                        "vote": "APPROVE",
                        "findings": [{"severity": "HIGH", "file": "hello.py", "detail": "The implementation lacks required error handling.", "suggested_fix": "Handle the error case."}],
                        "strengths": [], "confidence": 0.99,
                    })
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            result = CouncilRunner(FindingStub(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertFalse(result.can_apply, "final votes must not erase a material review finding")
            self.assertTrue(any("unresolved HIGH finding" in e for e in result.safety_errors))

    def test_apply_rechecks_reviews_and_known_peer_identities(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(StubModel(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertTrue(result.can_apply)
            result.reviews = []
            with self.assertRaisesRegex(ValueError, "Independent approval gate"):
                apply_approved_result(result)
            self.assertFalse((root / "hello.py").exists())

    def test_failed_isolated_python_checks_block_approval(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.council.run_project_checks", return_value={"status": "FAILED", "summary": "Unit test failed", "output": "AssertionError"}):
                result = CouncilRunner(StubModel(), Path(temp), review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
        self.assertFalse(result.can_apply)
        self.assertEqual(result.test_report["status"], "FAILED")
        self.assertTrue(any("Isolated project checks failed" in x for x in result.safety_errors))

    def test_missing_remaining_blockers_field_fails_closed(self):
        class MissingBlockersStub(StubModel):
            def generate(self, system, user, max_tokens=None, temperature=None):
                if "ALL FOUR REVIEW REPORTS" in user:
                    return json.dumps({"vote": "APPROVE", "reason": "I forgot to report blocker status."})
                return super().generate(system, user, max_tokens, temperature)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = CouncilRunner(MissingBlockersStub(), root, review_rounds=0, logger=lambda _: None).run_task("Add a hello function.")
            self.assertFalse(result.can_apply, "missing blocker data must not be interpreted as an empty blocker list")
            with self.assertRaises(ValueError):
                apply_approved_result(result)



if __name__ == "__main__":
    unittest.main()
