import tempfile
import unittest
from pathlib import Path
from offline_coder.workspace import collect_workspace_context


class WorkspaceScanTests(unittest.TestCase):
    def test_scan_limits_are_reported_in_context(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for i in range(8):
                (root / f"file_{i}.py").write_text(f"value = {i}\n", encoding="utf-8")
            context = collect_workspace_context(root, max_chars=10000, max_files=90, max_scan_files=2, max_scan_dirs=20)
        self.assertIn("safety limit", context)
        self.assertLessEqual(context.count("===== FILE:"), 2)

    def test_skips_secret_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "app.py").write_text("print('ok')", encoding="utf-8")
            (root / ".env").mkdir()
            (root / ".env" / "local.py").write_text("token='do-not-read'", encoding="utf-8")
            context = collect_workspace_context(root)
        self.assertIn("app.py", context)
        self.assertNotIn("do-not-read", context)


if __name__ == "__main__":
    unittest.main()
