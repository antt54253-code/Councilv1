import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder import config


class ConfigTests(unittest.TestCase):
    def test_autonomous_web_research_defaults_on(self):
        self.assertTrue(config.DEFAULT_SETTINGS["autonomous_web_research"])

    def test_autonomous_apply_defaults_off(self):
        self.assertFalse(config.DEFAULT_SETTINGS["auto_apply_approved"])

    def test_autonomous_apply_preference_persists(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with patch.object(config, "APP_DIR", root), patch.object(config, "SETTINGS_PATH", root / "settings.json"):
                settings = config.DEFAULT_SETTINGS.copy()
                settings["auto_apply_approved"] = True
                config.save_settings(settings)
                loaded = config.load_settings()
                self.assertTrue(loaded["auto_apply_approved"])
                self.assertTrue((root / "settings.json").exists())
