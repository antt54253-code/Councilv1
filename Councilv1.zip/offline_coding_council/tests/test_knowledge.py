import tempfile
import unittest
from pathlib import Path
from offline_coder.knowledge import KnowledgeStore


class KnowledgeTests(unittest.TestCase):
    def test_only_user_verified_sources_are_retrieved(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db = root / "knowledge.sqlite3"
            doc = root / "python_notes.md"
            doc.write_text("Python dictionaries preserve insertion order in supported versions. Use dict.get for optional keys.", encoding="utf-8")
            store = KnowledgeStore(db)
            source_id = store.add_file(doc, "Python dictionary notes", "Hand-checked local documentation", verified=False)
            self.assertEqual(store.relevant_sources("Python dictionary insertion order"), [])
            store.verify_source(source_id)
            results = store.relevant_sources("Python dictionary insertion order")
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0]["title"], "Python dictionary notes")
            self.assertTrue(results[0]["sha256"])


if __name__ == "__main__":
    unittest.main()
