import json
import tempfile
import unittest
from pathlib import Path
from offline_coder.learning import LearningStore

class LearningTests(unittest.TestCase):
    def test_only_explicitly_confirmed_examples_are_stored_and_retrieved(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = LearningStore(Path(tmp) / 'learn.sqlite3')
            item_id = store.add_confirmed('Fix Python dictionary sorting', 'Use sorted(mapping.items())', 'I ran the regression test.', 'run-1')
            self.assertGreater(item_id, 0)
            self.assertEqual(len(store.relevant_examples('Python dictionary sorting')), 1)
            self.assertEqual(store.list_examples()[0]['source_run_id'], 'run-1')

    def test_duplicate_training_examples_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = LearningStore(Path(tmp) / 'learn.sqlite3')
            store.add_confirmed('Task', 'Solution')
            with self.assertRaises(ValueError):
                store.add_confirmed('Task', 'Solution')

    def test_possible_secret_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = LearningStore(Path(tmp) / 'learn.sqlite3')
            with self.assertRaises(ValueError):
                store.add_confirmed('Use API', 'api_key = abcdefghijklmnop')

    def test_jsonl_export_is_real_task_answer_pair(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); store = LearningStore(root / 'learn.sqlite3')
            store.add_confirmed('Build a test', 'def test(): pass', 'Verified locally')
            target = root / 'training.jsonl'
            self.assertEqual(store.export_jsonl(target), 1)
            row = json.loads(target.read_text(encoding='utf-8').strip())
            self.assertEqual(row['messages'][1]['role'], 'user')
            self.assertIn('Build a test', row['messages'][1]['content'])
            self.assertIn('def test()', row['messages'][2]['content'])

if __name__ == '__main__': unittest.main()
