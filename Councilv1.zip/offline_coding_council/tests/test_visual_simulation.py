import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.visual_simulation import run_visual_browser_checks, _safe_relative


class VisualSimulationTests(unittest.TestCase):
    def test_no_web_entry_or_manifest_is_not_applicable(self):
        with tempfile.TemporaryDirectory() as temp:
            report = run_visual_browser_checks(Path(temp), {})
        self.assertEqual(report["status"], "NOT_APPLICABLE")

    def test_rejects_manifest_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            (root / "council.visual.json").write_text(json.dumps({"entry": "../outside.html"}), encoding="utf-8")
            report = run_visual_browser_checks(root, {})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("safe relative", report["summary"])

    def test_rejects_unknown_action_before_launch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            manifest = {"entry": "index.html", "steps": [{"action": "execute_shell", "selector": "body"}]}
            report = run_visual_browser_checks(root, {"council.visual.json": json.dumps(manifest)})
        self.assertEqual(report["status"], "FAILED")
        self.assertIn("unsupported action", report["summary"])

    def test_safe_relative_rejects_parent_paths_and_absolute_paths(self):
        self.assertIsNone(_safe_relative("../secret.html"))
        self.assertIsNone(_safe_relative("/tmp/secret.html"))
        self.assertEqual(_safe_relative("src/index.html"), Path("src/index.html"))

    def test_missing_playwright_reports_skipped(self):
        import builtins
        real_import = builtins.__import__
        def guarded_import(name, *args, **kwargs):
            if name == "playwright.sync_api":
                raise ImportError("simulated missing Playwright")
            return real_import(name, *args, **kwargs)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")
            with patch("builtins.__import__", side_effect=guarded_import):
                report = run_visual_browser_checks(root, {})
        self.assertEqual(report["status"], "SKIPPED")
        self.assertIn("Playwright", report["summary"])


if __name__ == "__main__":
    unittest.main()
