import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from offline_coder.isolated_tests import run_isolated_python_checks, run_isolated_node_checks, run_project_checks, run_project_simulations, _copy_workspace


class IsolatedTestRunnerTests(unittest.TestCase):
    def test_non_python_proposal_is_not_applicable(self):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"index.html": "<h1>Hello</h1>"})
        self.assertEqual(result["status"], "NOT_APPLICABLE")

    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_missing_docker_skips_without_running_code(self, _which):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "print('hello')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])


    def test_workspace_snapshot_excludes_secret_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            dest = Path(temp) / "snapshot"
            root.mkdir(); dest.mkdir()
            (root / ".env").write_text("API_TOKEN=example-secret", encoding="utf-8")
            (root / "credentials.json").write_text('{"password":"example"}', encoding="utf-8")
            (root / "secrets").mkdir()
            (root / "secrets" / "prod.py").write_text("token='example'", encoding="utf-8")
            (root / "app.py").write_text("def main(): return True", encoding="utf-8")
            _copy_workspace(root, dest)
            self.assertTrue((dest / "app.py").exists())
            self.assertFalse((dest / ".env").exists())
            self.assertFalse((dest / "credentials.json").exists())
            self.assertFalse((dest / "secrets" / "prod.py").exists())


    def test_workspace_snapshot_bounds_entry_traversal(self):
        import offline_coder.isolated_tests as isolated
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "source"
            dest = Path(temp) / "snapshot"
            root.mkdir(); dest.mkdir()
            (root / "a.txt").write_text("a", encoding="utf-8")
            (root / "b.txt").write_text("b", encoding="utf-8")
            with patch.object(isolated, "MAX_COPY_FILES", 1):
                with self.assertRaisesRegex(ValueError, "automatic tests were skipped"):
                    _copy_workspace(root, dest)

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_missing_local_image_does_not_pull_or_execute(self, _which, run):
        run.return_value.returncode = 1
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "print('hello')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.args[0][1:3], ["image", "inspect"])

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_available_image_runs_with_network_disabled_and_limits(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: tests found\nRan 1 test", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "PASSED")
        args = run.call_args.args[0]
        self.assertIn("--network", args)
        self.assertEqual(args[args.index("--network") + 1], "none")
        self.assertIn("--read-only", args)
        self.assertIn("--memory", args)
        self.assertIn("--pids-limit", args)

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_empty_unittest_suite_is_not_reported_as_passed(self, _which, run):
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "PYTHON_COMPILE: PASS\nUNITTEST_DISCOVERY: no unittest tests discovered", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_python_checks(Path(temp), {"hello.py": "def hello(): return 'hi'"})
        self.assertEqual(result["status"], "NO_TESTS")
        self.assertIn("no unittest tests were discovered", result["summary"])


    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_node_check_skips_without_docker(self, _which):
        with tempfile.TemporaryDirectory() as temp:
            result = run_isolated_node_checks(Path(temp), {"app.js": "console.log('hi')"})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])

    def test_simulation_runner_is_not_applicable_without_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            result = run_project_simulations(Path(temp), {})
        self.assertEqual(result["status"], "NOT_APPLICABLE")

    def test_simulation_manifest_rejects_path_traversal(self):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"name": "bad", "runtime": "python", "script": "../outside.py"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("unsafe", result["summary"].lower())

    @patch("offline_coder.isolated_tests.subprocess.run")
    @patch("offline_coder.isolated_tests.shutil.which", return_value="/usr/bin/docker")
    def test_simulation_runs_script_in_offline_container_and_checks_output(self, _which, run):
        import json
        inspect = type("Result", (), {"returncode": 0, "stdout": "[]", "stderr": ""})()
        executed = type("Result", (), {"returncode": 0, "stdout": "SIMULATION_OK", "stderr": ""})()
        run.side_effect = [inspect, executed]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("print('SIMULATION_OK')", encoding="utf-8")
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"name": "smoke", "runtime": "python", "script": "main.py", "expect_output_contains": "SIMULATION_OK"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["scenarios"][0]["status"], "PASSED")
        args = run.call_args.args[0]
        self.assertIn("--network", args)
        self.assertEqual(args[args.index("--network") + 1], "none")
        self.assertIn("--read-only", args)

    @patch("offline_coder.isolated_tests.shutil.which", return_value=None)
    def test_simulation_skips_without_docker(self, _which):
        import json
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "main.py").write_text("print('ok')", encoding="utf-8")
            (root / "council.simulations.json").write_text(json.dumps({"scenarios": [{"runtime": "python", "script": "main.py"}]}), encoding="utf-8")
            result = run_project_simulations(root, {})
        self.assertEqual(result["status"], "SKIPPED")
        self.assertIn("not executed", result["summary"])

    def test_project_checks_run_visual_browser_check_for_html_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.isolated_tests.run_project_simulations", return_value={"status": "NOT_APPLICABLE", "summary": "none", "output": ""}), \
                 patch("offline_coder.visual_simulation.run_visual_browser_checks", return_value={"status": "PASSED", "summary": "rendered", "output": "", "screenshot": "shot.png"}) as visual:
                result = run_project_checks(Path(temp), {"index.html": "<h1>hi</h1>"})
        self.assertEqual(result["status"], "PASSED")
        self.assertIn("visual", result["checks"])
        visual.assert_called_once()

    def test_project_check_aggregates_runtime_statuses(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch("offline_coder.isolated_tests.run_isolated_python_checks", return_value={"status": "PASSED", "summary": "python passed", "output": ""}), \
                 patch("offline_coder.isolated_tests.run_isolated_node_checks", return_value={"status": "FAILED", "summary": "node failed", "output": "failure"}):
                result = run_project_checks(Path(temp), {"app.py": "", "app.js": ""})
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("python", result["checks"])
        self.assertIn("node", result["checks"])


if __name__ == "__main__":
    unittest.main()
