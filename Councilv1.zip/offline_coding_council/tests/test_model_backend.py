import unittest
from unittest.mock import patch

from offline_coder.model_backend import LocalModelError, LocalServerModel


class LocalServerModelTests(unittest.TestCase):
    @patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "qwen-local"}]})
    def test_verifies_server_and_discovers_model_id(self, request):
        model = LocalServerModel("http://127.0.0.1:8080/v1")
        self.assertEqual(model.model, "qwen-local")
        self.assertEqual(model.model_path, "local-server:http://127.0.0.1:8080/v1/qwen-local")
        request.assert_called_once_with("/models", method="GET")

    def test_refuses_non_loopback_server(self):
        with self.assertRaisesRegex(LocalModelError, "loopback"):
            LocalServerModel("http://example.com:8080/v1")

    def test_refuses_unknown_requested_model(self):
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "available"}]}):
            with self.assertRaisesRegex(LocalModelError, "was not listed"):
                LocalServerModel("http://localhost:8080/v1", model="missing")

    @patch.object(LocalServerModel, "_request", return_value={"choices": [{"message": {"content": "fixed code"}}]})
    def test_generate_uses_chat_completions_and_returns_content(self, request):
        with patch.object(LocalServerModel, "_request", return_value={"data": [{"id": "qwen-local"}]}) as verify:
            model = LocalServerModel("http://127.0.0.1:8080/v1")
        self.assertEqual(model.generate("system", "user"), "fixed code")
        args, kwargs = request.call_args
        self.assertEqual(args[0], "/chat/completions")
        self.assertEqual(kwargs["body"]["model"], "qwen-local")
        self.assertEqual(kwargs["body"]["messages"][0]["role"], "system")


if __name__ == "__main__":
    unittest.main()
