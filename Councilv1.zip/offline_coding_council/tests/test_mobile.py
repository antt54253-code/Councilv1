import unittest
from unittest.mock import patch
import sys

from offline_coder.mobile import PAGE, _valid_bearer, main


class MobileSecurityTests(unittest.TestCase):
    def test_bearer_validation_is_scheme_and_secret_specific(self):
        self.assertTrue(_valid_bearer("Bearer secret-token", "secret-token"))
        self.assertFalse(_valid_bearer("bearer secret-token", "secret-token-x"))
        self.assertFalse(_valid_bearer("Basic secret-token", "secret-token"))
        self.assertFalse(_valid_bearer("Bearer ", "secret-token"))

    def test_page_uses_fragment_then_authorization_header_not_query_token(self):
        self.assertIn("new URLSearchParams(location.hash.slice(1))", PAGE)
        self.assertIn("history.replaceState(null,'',location.pathname+location.search)", PAGE)
        self.assertIn("headers={'Authorization':'Bearer '+token}", PAGE)
        self.assertNotIn("fetch(path+'?token=", PAGE)

    def test_mobile_page_includes_authenticated_web_search(self):
        self.assertIn("api('/search',{query})", PAGE)
        self.assertIn("Search the public web", PAGE)

    def test_mobile_server_defaults_to_localhost(self):
        with patch.object(sys, "argv", ["offline-council-mobile"]), patch("offline_coder.mobile.serve") as serve:
            main()
        serve.assert_called_once_with("127.0.0.1", 8765)


if __name__ == "__main__":
    unittest.main()
