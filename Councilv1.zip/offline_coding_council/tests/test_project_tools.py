import json
import tempfile
import unittest
from pathlib import Path
from offline_coder.project_tools import analyze_project, format_project_report, compile_acceptance_checklist, TaskJournal, restore_backup, create_starter_template
from offline_coder.safety import apply_files, sha256_text


class ProjectToolsTests(unittest.TestCase):
    def test_project_inventory_detects_manifests_entries_tests_and_todos(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "README.md").write_text("Project", encoding="utf-8")
            (root / "package.json").write_text('{"name":"demo"}', encoding="utf-8")
            (root / "index.js").write_text("// TODO: handle failures\n", encoding="utf-8")
            (root / "tests").mkdir(); (root / "tests" / "test_app.py").write_text("assert True", encoding="utf-8")
            (root / ".env").write_text("SECRET=do-not-show", encoding="utf-8")
            report = analyze_project(root)
            markdown = format_project_report(report)
        self.assertIn("package.json", report["manifests"])
        self.assertIn("index.js", report["entry_points"])
        self.assertTrue(report["test_paths"])
        self.assertTrue(report["todos"])
        self.assertNotIn("do-not-show", markdown)

    def test_checklist_handles_empty_and_deduplicates(self):
        with self.assertRaises(ValueError):
            compile_acceptance_checklist("  ")
        checklist = compile_acceptance_checklist("Build a website.\n- Build a website.\n- Add a login form.")
        self.assertEqual(checklist.count("Build a website."), 1)
        self.assertIn("Add a login form", checklist)
        self.assertIn("Verification plan", checklist)

    def test_task_journal_round_trip(self):
        with tempfile.TemporaryDirectory() as temp:
            journal = TaskJournal(Path(temp))
            journal.record("Add a button", "Passed review", "Small patch", "run-1", "report.json")
            items = journal.list_recent()
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["run_id"], "run-1")
        self.assertEqual(items[0]["task"], "Add a button")

    def test_rollback_restores_overwritten_and_removes_created_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old = root / "existing.txt"; old.write_text("old", encoding="utf-8")
            proposed = {"existing.txt": "new", "created.txt": "created"}
            hashes = {"existing.txt": sha256_text("old"), "created.txt": None}
            backup = apply_files(root, proposed, hashes)
            self.assertEqual(old.read_text(encoding="utf-8"), "new")
            self.assertTrue((root / "created.txt").exists())
            restored = restore_backup(root, backup)
            self.assertEqual(old.read_text(encoding="utf-8"), "old")
            self.assertFalse((root / "created.txt").exists())
            self.assertEqual(set(restored), {"existing.txt", "created.txt"})
            self.assertTrue((root / ".council" / "backups").is_dir())

    def test_static_report_adds_advisory_security_and_accessibility_flags(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "index.html").write_text('<img src="x.png"><input><script>el.innerHTML = input</script>', encoding="utf-8")
            report = analyze_project(root)
            markdown = format_project_report(report)
        self.assertTrue(report["accessibility_flags"])
        self.assertTrue(report["security_flags"])
        self.assertIn("not vulnerability-checked", markdown)

    def test_starter_templates_create_files_without_overwriting(self):
        with tempfile.TemporaryDirectory() as temp:
            dest = Path(temp) / "new-site"
            created = create_starter_template(dest, "website")
            self.assertIn("index.html", created)
            self.assertTrue((dest / "index.html").is_file())
            with self.assertRaises(ValueError):
                create_starter_template(dest, "python-cli")

    def test_template_rejects_unknown_kind(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                create_starter_template(Path(temp) / "site", "unknown")

    def test_rollback_rejects_outside_backup(self):
        with tempfile.TemporaryDirectory() as temp, tempfile.TemporaryDirectory() as outside:
            root = Path(temp); invalid = Path(outside)
            with self.assertRaises(ValueError):
                restore_backup(root, invalid)


if __name__ == "__main__":
    unittest.main()
