# Contributing

1. Open an issue describing the bug, expected behavior, and reproduction steps.
2. Create a branch and make the smallest focused change possible.
3. Add or update tests for behavior changes.
4. Run `python -m pytest -q`, `python -m compileall -q main.py offline_coder tests`, and `python tools/check_iphone_js.py`.
5. Open a pull request and explain limitations and any checks that were not run.

Changes to approval gates, workspace access, source scanning, preview isolation, ZIP import, or other safety boundaries require explicit human review. Do not merge safety-critical changes based only on an AI council vote.
