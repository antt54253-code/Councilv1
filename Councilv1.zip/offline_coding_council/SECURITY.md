# Security policy

This is an experimental local-first coding assistant, not a security-certified product.

## Reporting a vulnerability

Please do not publish secrets, access tokens, private source code, or exploit details in a public issue. For a private repository, contact the repository owner through GitHub's private reporting/contact options. If this repository is made public later, enable GitHub private vulnerability reporting before inviting external reports.

## Safe-use boundaries

- Do not upload secrets, credentials, private keys, or sensitive production data to the app or repository.
- Review generated code and run tests in a disposable environment before using it in a real project.
- Do not treat AI approval as proof of correctness or security.
- The browser app downloads its runtime and model weights from external hosts. It is not air-gapped.
- The browser preview is not a certified sandbox. Only preview code you are willing to inspect.
- Keep the repository private while the project is experimental. Do not commit model weights, API keys, personal data, or user projects.

## Supported versions

Only the latest repository version is currently maintained. No security response SLA is promised for this prototype.
