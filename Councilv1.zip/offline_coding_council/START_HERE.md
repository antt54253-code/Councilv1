# Start Here — Local Coding Council

This project is **not GitHub-only**. Choose the route that matches how you want to use it.

## Option A — One responsive HTML file (phone + computer)

Open `CodingCouncil_Universal.html` in a modern browser. It uses the same responsive interface on phones, tablets, and computers. For best compatibility, serve it over HTTPS using any static host (GitHub Pages, Netlify, Cloudflare Pages, or another HTTPS static host); none of those services performs AI inference. You can also try opening it as a local file, but some browser security settings may block module imports or persistent storage when opened as `file://`.

- The first run needs internet to download the browser runtime and model weights. Inference then runs locally in the browser; no AI API key is used.
- This is a small local model, not frontier-scale cloud AI. Performance depends on device memory and browser support. For genuinely complex reasoning, multi-file coding, or research synthesis, use the largest browser model your device can load; where possible, prefer the desktop edition with a capable 7B–14B+ instruction/coder GGUF and enough RAM/VRAM. The 0.5B browser option is mainly a compatibility choice, not a strong complex-task model.
- It accepts source files and ZIP projects. In the knowledge shelf, paste a public HTTPS URL and click **Fetch and digest website URL** to attempt a limited same-origin crawl, or use **Digest full website bundle** to import a website ZIP or a whole source folder (computer browsers only). URL crawling requires the site to permit browser CORS reads and not redirect; if it fails, use the ZIP option. It performs multi-pass digestion of up to 300 text files / 250,000 characters and produces an architecture digest plus a partial file inventory. On iPhone, upload a ZIP because folder selection is usually unavailable. The full source tree is not stored as a live editing workspace; import relevant source files into the project input when you want code changes.
- The digest is a model-generated summary, not verified truth. Read it and mark it reviewed before saving it to the knowledge shelf.
- Browser data is stored separately by browser/device; it does not automatically sync between phone and computer. Export and transfer data if you need the same knowledge on both.
- **Autonomous repair: ON/OFF** allows one extra bounded repair pass without asking between revisions; it changes only the in-memory candidate, not your device files. Export the ZIP to use the result. The browser version performs static checks and offers a restricted preview, but does not run arbitrary generated code or project unit tests.

## Option B — Full desktop version

- Windows: double-click `run_windows.bat` after installing Python and the listed dependencies.
- macOS/Linux: run `./run_macos_linux.sh` after installing Python and the listed dependencies.
- The desktop app uses a local GGUF model via `llama-cpp-python`; select the model and the project folder in the app. See `models/RECOMMENDED_MODEL.md` for the model recommendation and hardware caveats.
- The **Autonomous edits: ON/OFF** button is an explicit opt-in. Unattended file writes now require unanimous peer approval, passing host safety checks, and an actual isolated runtime test report marked PASSED. If tests are skipped, missing, or no tests are discovered, autonomous writes are blocked; manual review and approval remain available. Backups are created and generated code is not executed automatically after generation.
- For isolated Python/Node checks and configured smoke simulations, install Docker and have the required images (`python:3.12-slim` and/or `node:22-alpine`) already available locally. The council will not automatically pull images or install dependencies. It uses a temporary project copy, disabled container networking, read-only container root, and resource limits. To simulate a CLI or service flow, add a root-level `council.simulations.json`; see `SIMULATION_GUIDE.md` for the manifest schema and example. If Docker/image is unavailable, checks are marked SKIPPED rather than falsely passed. A successful compile with no discovered tests is marked NO_TESTS, not PASSED.
- This is defense in depth, not a formal guarantee that arbitrary tests are harmless. Review any test code before execution.

## Option C — Phone controls a desktop model (shared workspace)

The phone companion now includes a read-only file/folder listing for the configured workspace. It uses the same workspace folder as the desktop app when both run on the same computer, so changes applied by either interface are visible in that folder. This is shared access to the filesystem, not cloud synchronization: the host computer must be on, the mobile server must be running, and the phone must be on the same trusted Wi-Fi. It does not synchronize browser-only projects from the Universal HTML app.

Run `python -m offline_coder.mobile` for local-only mode by default. To intentionally let a phone on the same trusted private Wi-Fi connect, restart with `python -m offline_coder.mobile --host 0.0.0.0`. The desktop computer must remain on and run the model. LAN mode still uses unencrypted HTTP; never use it on public Wi-Fi or port-forward it to the internet. Read the network/security notes in `README.md` first.

## Feeding it information

In the browser edition, select text-based source/documentation files in the knowledge shelf and choose **Digest selected information with the local model**. Inspect the digest, correct it, then explicitly mark it reviewed and save. PDF/OCR is not supported in this browser edition. The desktop edition supports text source imports and optional PDF text extraction when `pypdf` is installed. Imported information is treated as untrusted reference material, not instructions.

## GitHub is optional

GitHub is useful for version history and automated CI, but it is not required to run the desktop app or the universal HTML app. You may keep the ZIP on your computer, host the HTML on another HTTPS static host, or run the desktop edition locally.


## New Project Lab controls

**Desktop app:** choose a workspace, then use `Analyze whole project`, `Acceptance checklist`, `Task history`, `Restore backup…`, or `Create starter template…`. The project analysis is read-only. The checklist is a draft. Restore requires a backup manifest and confirms before modifying files. Older backups created before manifests were added are not eligible for automatic rollback.

Starter template types: `website`, `browser-game`, `web-simulation`, and `python-cli`. Choose a new or empty folder; the tool refuses to overwrite files.

**Universal phone/computer app:** in Project Lab, compile an acceptance checklist, inventory imported source files, view recent local task history, or export it. After generating a website/game, open the sandboxed preview and choose Phone, Tablet, Desktop, or Fit Screen. These are manual viewport checks, not automated browser tests. Local browser history does not sync between devices.


## Complex questions and automatic research

- In the universal app, set **Task mode** to **Answer / research a question** for explanations, comparisons, research, and difficult conceptual questions. Use **Build / modify / audit code** when the goal is to generate or change a project. Auto-detect is convenient but can misclassify ambiguous requests.
- Desktop runs create a structured task plan, compare peer analyses, ask for a limited number of targeted follow-up searches when uncertainty warrants them, then synthesize answer-only tasks. The browser edition has a similar answer-only flow but relies on the selected compact model and Wikipedia snippets.
- A careful workflow improves odds; it does not make the council infallible. Inspect acceptance criteria, sources, open questions, test status, and proposed changes. The four peers use one underlying model, so their agreement is not independent proof. Unattended writes are intentionally stricter than manually approved writes.

## Optional internet research

- **Desktop app:** autonomous research is enabled by default for tasks that appear to benefit from search. It uses a sanitized query, attaches bounded source snippets, and may run up to two targeted follow-up searches after first-pass peer analyses. You can disable it in settings for private work. Click **Search web…** for manual research, review the source-linked snippets, and choose whether to append them to the task before running the council.
- **Phone companion:** enter a query in **Search the public web**; the desktop host performs the search and returns source-linked snippets.
- **Universal browser app:** the **Automatically research relevant tasks** option searches Wikipedia at the beginning of a relevant task. For answer mode, peers may ask the local model to suggest up to two targeted follow-up Wikipedia queries. It does not fetch each article's full text; search results are snippets, not full-page verification. You can also use **Web research · Internet search** manually or open broader web search in a new tab and paste useful excerpts yourself.

Search requires internet access. Search results are untrusted leads and can be incomplete or stale; verify important claims against official documentation or primary sources. The council does not automatically fetch and validate every result page.


## Local model server option

You can keep using a local `.gguf` file, or select `local-server` in the desktop app and point it at a model server on this same computer (default `http://127.0.0.1:8080/v1`). The app verifies `/v1/models` and only accepts loopback hosts. Start the compatible server yourself; this option does not install models or start a server for you.

## Autonomous repair and verification

Set one or two revision rounds to let the council revise a candidate after host checks or supported isolated tests fail. The revision is not trusted automatically: it must pass validation and all four final peer votes again. Python and JavaScript/Node checks use preinstalled Docker images only, with networking disabled. No tests discovered, missing Docker/images, or unsupported runtime checks are not reported as passing. Configured Python/Node smoke scenarios can assert exit codes and output. Browser UI, mobile browser behavior, databases, APIs, and game-engine projects still need their own installed, project-specific end-to-end runners; the generic runner does not emulate those environments.


## Visual simulation for websites and browser games

To enable real headless Chromium rendering, install the optional dependency and browser explicitly:

```bash
pip install -e ".[visual]"
python -m playwright install chromium
```

Then choose **Visual simulate project…** in the desktop app. The council saves a screenshot and browser error report under `.council/visual-runs/`. For repeatable UI actions, add `council.visual.json` as described in `SIMULATION_GUIDE.md`. If the browser runtime is unavailable or blocked by local policy, the run is reported as skipped rather than passed.
