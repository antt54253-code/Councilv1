#!/usr/bin/env python3
"""Optional local LoRA fine-tuning for Hugging Face causal LMs using reviewed JSONL.

This is separate from normal council operation. It loads only a local Hugging Face model
directory and uses local_files_only=True; it does not download models or datasets.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--model',required=True,help='Local Hugging Face model directory (not a GGUF file).')
    ap.add_argument('--dataset',required=True,help='JSONL exported by the council; each line must contain messages.')
    ap.add_argument('--output',required=True,help='New output directory for the LoRA adapter.')
    ap.add_argument('--epochs',type=float,default=1.0)
    ap.add_argument('--batch-size',type=int,default=1)
    ap.add_argument('--grad-accum',type=int,default=8)
    ap.add_argument('--max-length',type=int,default=2048)
    args=ap.parse_args()
    model_path=Path(args.model).expanduser().resolve(); data_path=Path(args.dataset).expanduser().resolve(); out=Path(args.output).expanduser().resolve()
    if not model_path.is_dir(): ap.error('--model must be a local Hugging Face model directory; GGUF models cannot be fine-tuned by this script.')
    if not data_path.is_file(): ap.error('Dataset file does not exist.')
    if out.exists() and any(out.iterdir()): ap.error('Output directory must be new or empty; refusing to overwrite an existing training output.')
    if not 0.1 <= args.epochs <= 5: ap.error('--epochs must be between 0.1 and 5 to limit accidental overtraining.')
    if not 1 <= args.batch_size <= 8 or not 1 <= args.grad_accum <= 128: ap.error('Batch or accumulation setting is outside safe configured bounds.')
    rows=[]
    for n,line in enumerate(data_path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try: obj=json.loads(line)
        except json.JSONDecodeError as exc: ap.error(f'Invalid JSON on line {n}: {exc}')
        msgs=obj.get('messages') if isinstance(obj,dict) else None
        if not isinstance(msgs,list) or not any(isinstance(m,dict) and m.get('role')=='user' for m in msgs) or not any(isinstance(m,dict) and m.get('role')=='assistant' for m in msgs):
            ap.error(f'Line {n} must have a messages array with user and assistant entries.')
        if len(line)>100000: ap.error(f'Line {n} is too large (100 KB max).')
        rows.append(msgs)
    if len(rows)<20:
        ap.error(f'Only {len(rows)} examples found. At least 20 reviewed examples are required to reserve a small validation set; substantially more diverse examples are usually needed for useful results.')
    try:
        import torch
        from datasets import Dataset
        from peft import LoraConfig, get_peft_model, TaskType
        from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments
    except ImportError as exc:
        print('Training dependencies missing. Install with: python -m pip install -r requirements-training.txt',file=sys.stderr); return 2
    tokenizer=AutoTokenizer.from_pretrained(str(model_path),local_files_only=True)
    if tokenizer.pad_token is None: tokenizer.pad_token=tokenizer.eos_token
    model=AutoModelForCausalLM.from_pretrained(str(model_path),local_files_only=True,torch_dtype='auto')
    lora=LoraConfig(task_type=TaskType.CAUSAL_LM,r=8,lora_alpha=16,lora_dropout=0.05,target_modules='all-linear')
    model=get_peft_model(model,lora)
    records=[]
    for msgs in rows:
        clean=[]
        for m in msgs:
            if isinstance(m,dict) and m.get('role') in {'system','user','assistant'} and isinstance(m.get('content'),str):
                clean.append({'role':m['role'],'content':m['content'][:30000]})
        if not clean or clean[-1]['role']!='assistant':
            continue
        try:
            if hasattr(tokenizer,'apply_chat_template') and tokenizer.chat_template:
                full_ids=tokenizer.apply_chat_template(clean,tokenize=True,add_generation_prompt=False)
                prefix_ids=tokenizer.apply_chat_template(clean[:-1],tokenize=True,add_generation_prompt=True)
            else:
                prefix_text='\n'.join(f"{m['role'].upper()}: {m['content']}" for m in clean[:-1])+'\nASSISTANT:'
                full_text='\n'.join(f"{m['role'].upper()}: {m['content']}" for m in clean)+tokenizer.eos_token
                prefix_ids=tokenizer(prefix_text,add_special_tokens=True)['input_ids']
                full_ids=tokenizer(full_text,add_special_tokens=True)['input_ids']
            # Mask prompt tokens so the loss focuses on the target assistant answer.
            common=0
            while common<min(len(prefix_ids),len(full_ids)) and prefix_ids[common]==full_ids[common]: common+=1
            if common==0 or len(full_ids)<=common: continue
            full_ids=full_ids[:args.max_length]
            labels=[-100]*min(common,len(full_ids))+full_ids[min(common,len(full_ids)):]
            if not any(x!=-100 for x in labels): continue
            records.append({'input_ids':full_ids,'attention_mask':[1]*len(full_ids),'labels':labels})
        except Exception as exc:
            print(f'Skipping one malformed/template-incompatible example: {exc}',file=sys.stderr)
    if len(records)<20:
        ap.error(f'Only {len(records)} usable examples after tokenization; need at least 20.')
    from datasets import Dataset
    ds=Dataset.from_list(records).train_test_split(test_size=max(1,round(len(records)*0.1)),seed=42)
    class AssistantOnlyCollator:
        def __call__(self, features):
            width=max(len(f['input_ids']) for f in features)
            pad_id=tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id
            return {
                'input_ids':torch.tensor([f['input_ids']+[pad_id]*(width-len(f['input_ids'])) for f in features],dtype=torch.long),
                'attention_mask':torch.tensor([f['attention_mask']+[0]*(width-len(f['attention_mask'])) for f in features],dtype=torch.long),
                'labels':torch.tensor([f['labels']+[-100]*(width-len(f['labels'])) for f in features],dtype=torch.long),
            }
    out.mkdir(parents=True,exist_ok=True)
    training=TrainingArguments(output_dir=str(out/'checkpoints'),num_train_epochs=args.epochs,per_device_train_batch_size=args.batch_size,per_device_eval_batch_size=1,gradient_accumulation_steps=args.grad_accum,learning_rate=1e-4,logging_steps=5,save_strategy='epoch',eval_strategy='epoch',load_best_model_at_end=True,metric_for_best_model='eval_loss',greater_is_better=False,report_to=[],fp16=bool(torch.cuda.is_available()),use_cpu=not torch.cuda.is_available(),remove_unused_columns=False)
    trainer=Trainer(model=model,args=training,train_dataset=ds['train'],eval_dataset=ds['test'],data_collator=AssistantOnlyCollator())
    trainer.train()
    model.save_pretrained(out/'adapter'); tokenizer.save_pretrained(out/'adapter')
    print(f'LoRA adapter saved to: {out / "adapter"}')
    print('This is an experimental adapter. Evaluate on held-out tasks and keep the original model/adapter backup; fine-tuning can make performance worse.')
    return 0

if __name__=='__main__': raise SystemExit(main())
