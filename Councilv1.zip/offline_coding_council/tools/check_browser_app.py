"""Static checks for the standalone responsive browser app (standard library + Node.js)."""
from __future__ import annotations
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / "CodingCouncil_Universal.html"


class DocumentChecks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[str] = []
        self.label_targets: list[str] = []
        self.iframes: list[dict[str, str | None]] = []
        self.script_count = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        values = dict(attrs)
        if values.get("id") is not None:
            self.ids.append(str(values["id"]))
        if tag == "label" and values.get("for"):
            self.label_targets.append(str(values["for"]))
        if tag == "iframe":
            self.iframes.append(values)
        if tag == "script":
            self.script_count += 1


def main() -> int:
    if not HTML_PATH.is_file():
        raise SystemExit(f"Missing browser app: {HTML_PATH}")
    html = HTML_PATH.read_text(encoding="utf-8")
    check = DocumentChecks()
    check.feed(html)
    duplicates = sorted({value for value in check.ids if check.ids.count(value) > 1})
    missing_labels = sorted(set(check.label_targets) - set(check.ids))
    if duplicates:
        raise SystemExit("Duplicate HTML id(s): " + ", ".join(duplicates))
    if missing_labels:
        raise SystemExit("Label target(s) missing from HTML: " + ", ".join(missing_labels))
    scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", html, re.I | re.S)
    if len(scripts) != 1:
        raise SystemExit(f"Expected one inline application script, found {len(scripts)}")
    dom_refs = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", scripts[0]))
    missing_dom_refs = sorted(dom_refs - set(check.ids))
    if missing_dom_refs:
        raise SystemExit("JavaScript references missing DOM id(s): " + ", ".join(missing_dom_refs))
    if len(check.iframes) != 1 or check.iframes[0].get("sandbox") != "allow-scripts":
        raise SystemExit("Expected exactly one preview iframe sandboxed with allow-scripts only.")

    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as stream:
        stream.write(scripts[0])
        stream.flush()
        try:
            subprocess.run(["node", "--check", stream.name], check=True, capture_output=True, text=True)
        except FileNotFoundError:
            raise SystemExit("Node.js is required for the universal browser-app syntax check.")
        except subprocess.CalledProcessError as exc:
            raise SystemExit(exc.stderr or exc.stdout or "Universal app JavaScript syntax check failed.")

    # Guard against regression of the URL-only workflow and the resource-size limit.
    required_fragments = {
        "URL-only import can reach the digest routine": "!selected.length&&!pendingUrlSources.length",
        "URL fetch hands resources to digestion": "await digestWebsiteBundle();",
        "URL resources use the streaming byte cap": "readWebsiteResponseLimited(response,1024*1024)",
        "URL import omits credentials": "credentials:'omit'",
        "URL import refuses redirects": "redirect:'error'",
        "URL import has per-resource timeout": "setTimeout(()=>controller.abort(),12000)",
        "URL import has overall crawl deadline": "Date.now()+90000",
        "ZIP parser is at reviewed patch version": "fflate@0.8.3",
        "Result renderer exists (previously this was a missing runtime function)": "function renderResult(result)",
        "Answer-only mode is available": 'option value="answer"',
        "Autonomous follow-up research is wired": "async function gatherBrowserFollowupResearch",
        "Generated project manifests require acceptance criteria": '"acceptance_criteria"',
        "Browser search query sanitizer is present": "function safeResearchQuery(task)",
    }
    missing = [label for label, needle in required_fragments.items() if needle not in html]
    if missing:
        raise SystemExit("Browser import regression guard failed: " + "; ".join(missing))

    try:
        logic = subprocess.run(["node", str(ROOT / "tools" / "check_browser_logic.mjs")], check=True, capture_output=True, text=True, timeout=20)
    except subprocess.TimeoutExpired:
        raise SystemExit("Universal browser logic harness timed out.")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.stderr or exc.stdout or "Universal browser logic checks failed.")

    print(f"Universal browser app: JavaScript syntax OK; {len(check.ids)} IDs unique; labels resolve; preview sandbox OK; URL import and runtime-reference guards OK.")
    print(logic.stdout.strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
