// Lightweight Node-based integration harness for the inline browser app.
// It supplies a minimal DOM only to exercise deterministic helpers and result rendering;
// it is not a replacement for a real browser/model/network end-to-end test.
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

class MockElement {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase(); this.children = []; this.style = {};
    this.className = ''; this.value = ''; this.checked = false; this.disabled = false;
    this.files = []; this.dataset = {}; this.listeners = {}; this.attributes = {};
    this._text = ''; this.hidden = false; this.href = ''; this.target = ''; this.rel = '';
  }
  set textContent(value) { this._text = String(value ?? ''); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent).join(''); }
  append(...nodes) { this._text = ''; this.children.push(...nodes); }
  appendChild(node) { this.append(node); return node; }
  replaceChildren(...nodes) { this._text = ''; this.children = [...nodes]; }
  addEventListener(name, callback) { this.listeners[name] = callback; }
  remove() { this.removed = true; }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  click() { this.listeners.click?.({ target: this }); }
}
const elements = new Map();
const documentMock = {
  getElementById(id) { if (!elements.has(id)) elements.set(id, new MockElement('div')); return elements.get(id); },
  createElement(tag) { return new MockElement(tag); },
  querySelectorAll() { return []; },
  body: new MockElement('body'),
};
Object.defineProperty(globalThis, 'document', { value: documentMock, configurable: true });
Object.defineProperty(globalThis, 'window', { value: { indexedDB: {} }, configurable: true });
Object.defineProperty(globalThis, 'navigator', { value: { gpu: null }, configurable: true });
Object.defineProperty(globalThis, 'localStorage', { value: { getItem() { return null; }, setItem() {}, removeItem() {} }, configurable: true });
globalThis.alert = () => {};
globalThis.confirm = () => false;
globalThis.prompt = () => '';

const htmlPath = new URL('../CodingCouncil_Universal.html', import.meta.url);
const html = readFileSync(htmlPath, 'utf8');
const script = html.match(/<script type="module">([\s\S]*?)<\/script>/i)?.[1];
if (!script) throw new Error('Universal app inline module script not found.');
const source = script + '\n;globalThis.__codingCouncilTestHooks = {renderResult, resolveTaskMode, shouldAutoResearchTask, safeResearchQuery, formatWikipediaContext};\n';
const dataUrl = 'data:text/javascript;base64,' + Buffer.from(source).toString('base64');
await import(dataUrl);
const hooks = globalThis.__codingCouncilTestHooks;
function assert(condition, message) { if (!condition) throw new Error(message); }

assert(hooks.resolveTaskMode('What are the trade-offs between two database architectures?', 'auto') === 'answer', 'Auto mode should classify a conceptual question as answer-only.');
assert(hooks.resolveTaskMode('Build a responsive website with working form validation.', 'auto') === 'build', 'Auto mode should classify an imperative build task as build mode.');
assert(hooks.resolveTaskMode('Explain how this works.', 'build') === 'build', 'Explicit build mode must override auto-detection.');
assert(hooks.shouldAutoResearchTask('What is the difference between two cryptographic approaches?') === true, 'Substantive factual questions should trigger research.');
assert(hooks.shouldAutoResearchTask('Research the latest version, but do not search the internet.') === false, 'Explicit no-web instruction must disable autonomous research.');
const query = hooks.safeResearchQuery('Find API docs, API_KEY=topsecret, email jane.doe@example.com, phone 415-555-0133, path /Users/alex/work/site, Windows C:\\Users\\alex\\private\\app.py, Bearer abcdefghijklmnop');
for (const secret of ['topsecret', 'jane.doe@example.com', '415-555-0133', '/Users/alex/work/site', 'C:\\Users\\alex\\private\\app.py', 'abcdefghijklmnop']) assert(!query.includes(secret), 'Search query leaked sensitive pattern: ' + secret);
const context = hooks.formatWikipediaContext([{ title: 'Example', snippet: 'A short snippet', url: 'https://en.wikipedia.org/wiki/Example', query: 'example', label: 'Established encyclopedia', tier: 2 }], ['example']);
assert(context.includes('snippets only') && context.includes('https://en.wikipedia.org/wiki/Example'), 'Research context should disclose snippet limitations and preserve source URLs.');
hooks.renderResult({ mode: 'answer', taskMode: 'answer', status: 'ANSWER COMPLETE', task: 'Explain something', answer: 'Evidence\n\nLimitations', draft: { summary: 'Evidence\n\nLimitations' }, taskPlan: { objective: 'Explain', verification_strategy: ['Check facts'] }, analyses: [{ agent: 'Peer A', text: 'Independent analysis' }], crossReviews: [{ agent: 'Peer A', text: 'Challenge' }], finalFiles: {}, findings: [], votes: [], webResearch: { enabled: true, status: 'completed', queries: ['example'], scope: 'Wikipedia snippets only', results: [{ title: 'Example', snippet: 'Snippet', url: 'https://en.wikipedia.org/wiki/Example' }] } });
assert(elements.get('decision').textContent.includes('Evidence') && elements.get('decision').textContent.includes('ANSWER COMPLETE'), 'Result renderer should display the final answer and status.');
assert(elements.get('peerResults').textContent.includes('Independent analysis') && elements.get('peerResults').textContent.includes('Cross-review'), 'Result renderer should display peer analysis and cross-review.');
assert(elements.get('generatedFiles').textContent.includes('Answer-only mode generated no project files'), 'Answer-only tasks should not pretend files were generated.');
assert(elements.get('exportReport').disabled === false, 'The audit report should be enabled for answer-only results.');
console.log('Universal browser logic: 9 checks passed (mode selection, research gating/redaction/context, answer renderer, peer renderer, answer-only file state, report export).');
