# Coding Council feature status — 2026-10-12

This document distinguishes implemented features from ideas that still need engineering work. “Implemented” means code exists in this repository; it does not mean every runtime/platform has been independently validated.

## Implemented in the current build

- [x] Four adversarial review roles around the selected local model, with a deterministic host approval gate.
- [x] Whole-site source import through ZIP/folder selection, plus a bounded direct HTTPS same-origin URL crawl when CORS permits.
- [x] Knowledge shelf with explicit user verification; confirmed lessons and training-data export.
- [x] Browser sandboxed preview for generated HTML projects.
- [x] Manual responsive preview widths: 375 px, 768 px, 1280 px, and fit-screen.
- [x] Bounded project inventory: file extensions, likely entry points, dependency manifests, likely test paths, README files, TODO markers, and read-only Git status.
- [x] Heuristic security/accessibility/performance flags. These can miss issues and produce false positives.
- [x] Acceptance checklist draft generator with generic verification checklist.
- [x] Desktop append-only task journal and browser local task history/export.
- [x] Starter templates: website, browser game, web simulation, Python CLI.
- [x] Manifest-backed rollback for new-format desktop backups, including deletion of files created by the applied change.
- [x] Desktop isolated Python compile/unittest checks if Docker and `python:3.12-slim` are already installed locally; otherwise reports SKIPPED.
- [x] Explicit autonomous editing toggle; desktop unattended writes require unanimous peer approval, host safety checks, and an actual isolated runtime test report marked PASSED. Missing/skipped/no-tests reports block autonomous writes; manual approval remains available. Browser autonomous mode only revises the in-memory candidate.
- [x] Isolated Python runner reports `NO_TESTS` instead of falsely treating an empty unittest suite as a successful test run.


- [x] Structured desktop task plan with ordered subtasks, acceptance criteria, assumptions/open questions, and a verification strategy (model-generated and still needs review).
- [x] Desktop answer-only synthesis across peer analyses/reviews rather than simply returning the rotating proposer answer.
- [x] Bounded iterative web research: up to two targeted follow-up searches based on peer uncertainties (desktop DuckDuckGo snippets; browser Wikipedia snippets only).
- [x] Browser task mode (auto/answer/build), answer-only synthesis/source display, and a working result renderer guarded by a DOM-stub regression harness.
- [x] Research context budget reserved explicitly when the workspace context is large.
- [x] Search-query best-effort redaction for common secrets and common OS-specific paths; untrusted snippets and query egress are disclosed.
- [x] Canonical generated-path validation to ensure checked paths match actual write paths across operating systems.

## Partially implemented / advisory only

- [~] Project architecture understanding: inventory plus model context/digest, not a full language-server-grade symbol/dependency graph.
- [~] Testing: Python checks in optional Docker; browser preview is a manual smoke check, not an automated Playwright suite.
- [~] Self-improvement: retrieval of user-verified lessons and examples, not automatic model-weight learning.
- [~] Competing ideas: the model can reason about alternatives, but there is no automatic multi-branch/worktree tournament yet.
- [~] Specialist reviewers: custom role prompts are supported, but reviewers may share one model and its blind spots.

- [x] Optional public web research: desktop DuckDuckGo result snippets, authenticated phone companion search, and browser Wikipedia search with source URLs; snippets are explicitly marked untrusted.

## Not implemented yet

- [ ] Genuinely independent selectable model per peer and calibrated disagreement metrics.
- [ ] Verify compatibility of Qwen3-Coder-Next GGUF with the project's current `llama-cpp-python` backend on supported hardware; model recommendation is documented but not runtime-validated.
- [ ] Parallel workers with isolated worktrees and conflict-aware merge coordinator.
- [ ] Automated Playwright/browser acceptance tests and screenshot-diff regression testing.
- [ ] General-purpose browser search backend for the standalone HTML edition; current autonomous browser research uses Wikipedia snippets plus an external full-search tab because browser CORS prevents reliable ingestion from arbitrary search engines. The desktop research follow-up is bounded to two extra searches, not an open-ended agent loop.
- [ ] Native Unity/Godot/Unreal project inspection and engine-specific tests.
- [ ] Automatic vulnerability database/CVE matching and software bill of materials.
- [ ] Voice input/output and microphone workflow.
- [ ] Authenticated cross-device sync service.
- [ ] Continuous background project health monitor.
- [ ] Generic plugin runtime with explicit capability permissions.
- [ ] Visual element-to-source debugging with DOM/source maps.
- [ ] Safe automatic framework migrations with database migration rehearsal.
- [ ] Production deployment and rollback automation.
- [ ] Automatic full performance profiling and accessibility conformance testing.

## Validation caveats

Current verification after the latest deep pass: 59 Python unit tests passed; Python compileall, universal browser syntax/DOM-stub checks (9 assertions), phone companion checks, iPhone syntax, workflow YAML parsing, and ZIP integrity passed. These are local regression/static checks, not proof that complex tasks work with a real model. The standard-library/unit test suite and static JavaScript checks run locally. In the current execution environment, attempts to navigate Chromium to both `http://127.0.0.1` and `file://` were blocked by an environment policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), so live headless-browser interaction tests could not be completed here. No physical phone test, live public-site crawl, real Docker-container run, native game-engine run, or independent penetration test is claimed.


## Autonomous web research and source ranking — 2026-10-12

- **Implemented:** Desktop, phone-host, and CLI council runs perform bounded pre-task DuckDuckGo research when enabled (default ON), using a sanitized query capped at 180 characters and up to six snippets. Universal browser app has an ON-by-default checkbox and searches Wikipedia before relevant tasks. Simple tasks and explicit no-web/offline-only requests are skipped. Search failures are recorded and the council continues without web evidence.
- **Implemented:** Search results receive transparent source categories. Relevant official/primary docs and standards rank highest for exact technical claims; Wikipedia is an established secondary source ranked above unclassified personal/community content; unknown domains remain unverified. The prompt asks peers to cite URLs, check recency/version fit, corroborate key claims, and ignore instructions in page content.
- **Limitations:** Desktop/CLI/phone host receive search-result snippets, not verified full pages. Browser edition auto-searches Wikipedia only because browser cross-origin rules prevent reliable arbitrary search-engine access. Domain tiering is heuristic and does not prove accuracy. Queries leave the device for the selected external search provider; turn off autonomous research for confidential tasks.


## Recent reliability upgrade

- Added a verified loopback-only OpenAI-compatible local server backend alongside in-process GGUF inference. The adapter checks the model list before use and refuses remote hosts.
- Added isolated JavaScript syntax checks and Node built-in test execution using `node:22-alpine` only when already installed. Existing Python isolated checks remain.
- Added project check aggregation; failed checks can enter the existing bounded repair/re-review loop. Every revised candidate must pass host validation and unanimous peer review again.
- Strict autonomous application requires an actual supported test run to pass. Static-only checks, absent tests, unavailable Docker/images, and unsupported runtimes are not treated as behavioral proof.
- Remaining limitations: no universal Playwright/browser runner, no automatic dependency install, no Unity/Godot/Unreal runtime runner, and no guarantee of correctness.


## Project simulation and end-to-end smoke scenarios (2026-10-13)

- [x] Added opt-in `council.simulations.json` scenarios for Python and Node CLI/service entry scripts. Each scenario can assert exit code and expected output and has a bounded timeout.
- [x] Simulations run on the disposable proposed-code snapshot in preinstalled Docker images only, with networking disabled, read-only container root, CPU/memory/process limits, and no shell command strings.
- [x] Simulation failures are included in the aggregated runtime report and trigger the existing bounded repair loop; missing Docker/images are reported as SKIPPED.
- [x] Added regression tests for path traversal, no-manifest behavior, successful simulated output, and unavailable Docker.
- [ ] Full browser interaction tests (Playwright), real mobile-device tests, database/API integration harnesses, and Unity/Godot/Unreal simulation are not included.
- [ ] Third-party project dependencies are not installed automatically; scenarios must work with the preinstalled image and copied workspace.
- See `SIMULATION_GUIDE.md` for usage and limitations.


## Real-browser visual simulation (2026-10-13)

- [x] Added an optional Playwright/Chromium runner for disposable web-project snapshots.
- [x] Captures screenshots, page exceptions, console errors, basic page metadata, and blocked external requests.
- [x] Supports deterministic UI actions/assertions through root `council.visual.json`.
- [x] Added a desktop **Visual simulate project…** action and automatic visual checks for web-facing candidate changes when applicable.
- [x] Missing/blocked browser runtime reports SKIPPED; no browser or dependency is downloaded automatically.
- [ ] Browser success path not verified in this restricted build environment because Chromium navigation is blocked by local browser policy. Unit tests cover validation and graceful skip behavior; run a real local smoke test on the target computer.
- [ ] This does not provide a universal emulator for native apps, phones, or Unity/Godot/Unreal projects.
